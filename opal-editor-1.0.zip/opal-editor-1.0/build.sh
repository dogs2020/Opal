#!/bin/bash
# Opalエディタのビルドスクリプト

# Opalコンパイラのパスを確認
OPAL_COMPILER=$(which opalc)
if [ -z "$OPAL_COMPILER" ]; then
    echo "エラー: Opalコンパイラが見つかりません"
    echo "Opalコンパイラをインストールするか、PATHに追加してください"
    exit 1
fi

# ソースディレクトリ
SRC_DIR="src"

# 出力ディレクトリ
BIN_DIR="bin"

# メインファイル
MAIN_FILE="$SRC_DIR/opal_editor.opal"

# 依存ファイル
DEPS=(
    "$SRC_DIR/ui_components.opal"
    "$SRC_DIR/text_edit.opal"
    "$SRC_DIR/syntax_highlight.opal"
    "$SRC_DIR/file_operations.opal"
    "$SRC_DIR/compiler_integration.opal"
    "$SRC_DIR/run_functionality.opal"
    "$SRC_DIR/main_integration.opal"
)

# コンパイル
echo "Opalエディタをコンパイルしています..."
$OPAL_COMPILER $MAIN_FILE ${DEPS[@]} -o $BIN_DIR/opal-editor --entry-point first

if [ $? -eq 0 ]; then
    echo "コンパイル成功: $BIN_DIR/opal-editor"
    chmod +x $BIN_DIR/opal-editor
else
    echo "コンパイルエラー"
    exit 1
fi

echo "ビルド完了"
