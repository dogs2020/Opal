#!/bin/bash
# Opalエディタの実行スクリプト

# バイナリの存在確認
if [ ! -f "bin/opal-editor" ]; then
    echo "エラー: Opalエディタがコンパイルされていません"
    echo "最初に ./build.sh を実行してください"
    exit 1
fi

# エディタの実行
./bin/opal-editor "$@"
