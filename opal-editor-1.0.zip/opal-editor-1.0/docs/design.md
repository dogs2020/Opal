# Opalエディタアプリケーション設計書

## 1. 概要

このドキュメントでは、Opal言語で実装されるテキストエディタアプリケーションの設計について説明します。このエディタは特にOpalプログラムの編集と実行を容易にすることを目的としています。

## 2. アーキテクチャ

エディタアプリケーションは以下のモジュールで構成されます：

### 2.1 コアモジュール

```
module OpalEditor then
    // メインエントリーポイント
    function first() -> Integer then
        // エディタの初期化と実行
    end
end
```

### 2.2 UIモジュール

```
module OpalEditor.UI then
    // ウィンドウ管理
    class Window then
        // ウィンドウの作成と管理
    end
    
    // テキスト表示領域
    class TextArea then
        // テキスト表示と編集機能
    end
    
    // メニューとツールバー
    class Menu then
        // メニュー項目の管理
    end
    
    class Toolbar then
        // ツールバーボタンの管理
    end
    
    // ステータスバー
    class StatusBar then
        // ステータス情報の表示
    end
end
```

### 2.3 テキスト編集モジュール

```
module OpalEditor.TextEdit then
    // バッファ管理
    class Buffer then
        // テキストバッファの管理
    end
    
    // カーソル管理
    class Cursor then
        // カーソル位置の管理
    end
    
    // 選択範囲管理
    class Selection then
        // テキスト選択範囲の管理
    end
    
    // 編集操作
    class EditOperations then
        // カット、コピー、ペーストなどの操作
    end
    
    // 履歴管理（Undo/Redo）
    class History then
        // 編集履歴の管理
    end
end
```

### 2.4 構文ハイライトモジュール

```
module OpalEditor.Syntax then
    // トークン管理
    class Token then
        // 構文トークンの定義
    end
    
    // Opal言語のハイライター
    class OpalHighlighter then
        // Opal言語の構文ハイライト
    end
    
    // ハイライト適用
    class HighlightApplier then
        // ハイライト情報の適用
    end
end
```

### 2.5 ファイル操作モジュール

```
module OpalEditor.FileOps then
    // ファイル読み込み
    class FileReader then
        // ファイルの読み込み機能
    end
    
    // ファイル保存
    class FileWriter then
        // ファイルの保存機能
    end
    
    // ファイル管理
    class FileManager then
        // 開いているファイルの管理
    end
end
```

### 2.6 コンパイラ統合モジュール

```
module OpalEditor.Compiler then
    // コンパイラ呼び出し
    class CompilerInvoker then
        // Opalコンパイラの呼び出し
    end
    
    // エラー管理
    class ErrorManager then
        // コンパイルエラーの管理と表示
    end
    
    // 実行管理
    class ExecutionManager then
        // コンパイル済みプログラムの実行
    end
end
```

### 2.7 設定モジュール

```
module OpalEditor.Config then
    // 設定管理
    class Settings then
        // エディタ設定の管理
    end
    
    // テーマ管理
    class Theme then
        // エディタテーマの管理
    end
end
```

## 3. データフロー

1. ユーザーがエディタを起動
2. エディタがUIを初期化
3. ユーザーがファイルを開くか新規作成
4. テキスト編集操作の実行
5. 構文ハイライトの適用
6. ファイルの保存
7. コンパイルと実行

## 4. 主要機能

### 4.1 基本編集機能
- テキスト入力と編集
- カット、コピー、ペースト
- Undo/Redo
- 検索と置換

### 4.2 Opal特化機能
- Opal言語の構文ハイライト
- コンパイルエラーのインライン表示
- ワンクリックでのコンパイルと実行
- コンパイルオプションの設定

### 4.3 ファイル管理
- 複数ファイルの同時編集（タブ）
- 自動保存
- ファイル変更の検出

### 4.4 UI機能
- カスタマイズ可能なテーマ
- ステータスバーでの情報表示
- ショートカットキーのサポート

## 5. 実装計画

1. 基本UIフレームワークの実装
2. テキスト編集機能の実装
3. ファイル操作機能の実装
4. 構文ハイライト機能の実装
5. コンパイラ統合機能の実装
6. 設定管理機能の実装
7. テストと最適化

## 6. 技術的考慮事項

- Opalの純粋な実装を維持
- 外部依存関係を最小限に抑える
- パフォーマンスの最適化（大きなファイルの編集）
- クロスプラットフォーム対応

## 7. 将来の拡張性

- プラグインシステム
- デバッガ統合
- コード補完
- リファクタリングツール
