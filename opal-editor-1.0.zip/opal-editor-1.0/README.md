# Opalエディタ

Opal言語用の統合開発環境です。

## 特徴

- Opal言語の構文ハイライト
- コードの編集機能
- ファイル操作
- コンパイルと実行の統合
- 使いやすいインターフェース

## インストール方法

1. このパッケージを任意のディレクトリに解凍します
2. `bin`ディレクトリ内の実行ファイルを使用して起動します

## 使用方法

詳細な使用方法については、`docs/manual.md`を参照してください。

## サンプルプログラム

`examples`ディレクトリにサンプルプログラムがあります。

## ライセンス

MIT License

## 連絡先

- メール: support@opal-lang.org
- ウェブサイト: https://opal-lang.org
- GitHub: https://github.com/opal-lang/opal-editor
