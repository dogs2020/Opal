#!/bin/bash
# Opal言語のビルドと実行スクリプト

# 引数チェック
if [ $# -lt 1 ]; then
    echo "使用方法: $0 <Opalソースファイル>"
    exit 1
fi

# 入力ファイルと出力ファイルの設定
INPUT_FILE=$1
FILENAME=$(basename "$INPUT_FILE")
BASENAME="${FILENAME%.*}"
OUTPUT_FILE="${BASENAME}.js"

# スクリプトのディレクトリを取得
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
BOOTSTRAP_DIR="$SCRIPT_DIR/bootstrap"

echo "Opalコンパイラを実行中..."
python3 "$BOOTSTRAP_DIR/bootstrap.py" "$INPUT_FILE" "$OUTPUT_FILE"

if [ $? -ne 0 ]; then
    echo "コンパイルに失敗しました。"
    exit 1
fi

echo "コンパイル成功: $INPUT_FILE -> $OUTPUT_FILE"
echo "プログラムを実行中..."

# JavaScriptエンジンでコンパイル結果を実行
# Node.jsがインストールされていれば使用
if command -v node &> /dev/null; then
    node "$OUTPUT_FILE"
else
    echo "警告: Node.jsが見つかりません。コンパイルされたJavaScriptを実行するにはNode.jsをインストールしてください。"
    echo "コンパイルされたファイル: $OUTPUT_FILE"
fi

exit 0
