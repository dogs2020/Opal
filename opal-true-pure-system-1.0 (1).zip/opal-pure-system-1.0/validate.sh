#!/bin/bash
# Opal 100% Pure System 検証スクリプト

echo "Validating 100% Pure Opal System..."
echo "----------------------------------"

# 検証スクリプトの実行
./bin/validate

# 結果の確認
if [ $? -eq 0 ]; then
    echo "Validation successful! The system is 100% self-hosting."
else
    echo "Validation failed. The system is not fully self-hosting yet."
    exit 1
fi
