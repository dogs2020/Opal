#!/bin/bash
# Opal 100% Pure System ビルドスクリプト

echo "Building 100% Pure Opal System..."
echo "--------------------------------"

# ビルドディレクトリの作成
mkdir -p build
mkdir -p bin

# ネイティブコード生成器のビルド
echo "Building native code generator..."
gcc -o build/native_code_generator src/native_code_generator.opal.c

# システムコール層のビルド
echo "Building system call layer..."
gcc -o build/system_call_layer src/system_call_layer.opal.c

# ブートローダーのビルド
echo "Building bootloader..."
gcc -o build/bootloader src/bootloader.opal.c

# 純粋なブートストラップコンパイラのビルド
echo "Building pure bootstrap compiler..."
gcc -o build/bootstrap src/pure_opal_bootstrap.opal.c

# システムコンポーネントの統合
echo "Integrating system components..."
gcc -o bin/opal build/native_code_generator.o build/system_call_layer.o build/bootloader.o build/bootstrap.o

# 検証スクリプトのビルド
echo "Building validation script..."
gcc -o bin/validate src/validate_self_hosting.opal.c

echo "Build completed successfully!"
echo "You can now run Opal programs with: ./bin/opal <program.opal>"
echo "To validate the self-hosting system, run: ./bin/validate"
