# Opal 言語仕様書

## 概要

Opal は高速で効率的な実行を目指した、静的型付けのプログラミング言語です。手動メモリ管理と最小限のランタイムオーバーヘッドにより、予測可能なパフォーマンスを実現します。

## 構文

### 基本構造

Opal プログラムは、関数、クラス、モジュールの定義から構成されます。

```opal
function main() -> Integer then
    "Hello, World!" => println;
    return 0;
end
```

### 変数宣言

変数は `let` キーワードで宣言し、型を明示的に指定します。

```opal
let x: Integer <- 42;
let name: String <- "Opal";
```

### 関数定義

関数は `function` キーワードで定義し、戻り値の型を `->` の後に指定します。

```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end
```

### クラス定義

クラスは `class` キーワードで定義します。

```opal
class Point then
    let x: Float;
    let y: Float;
    
    function init(x: Float, y: Float) then
        this.x <- x;
        this.y <- y;
    end
    
    function distance_from_origin() -> Float then
        return (this.x * this.x + this.y * this.y).sqrt();
    end
end
```

### モジュール定義

モジュールは `module` キーワードで定義します。

```opal
module Math then
    static function square(x: Float) -> Float then
        return x * x;
    end
    
    static function cube(x: Float) -> Float then
        return x * x * x;
    end
end
```

### 制御構造

条件分岐は `if`、`then`、`else`、`end` を使用します。

```opal
if x > 0 then
    "Positive" => println;
else if x < 0 then
    "Negative" => println;
else
    "Zero" => println;
end
```

ループは `while`、`do`、`end` または `for`、`in`、`do`、`end` を使用します。

```opal
// while ループ
let i <- 0;
while i < 10 do
    i.to_string() => println;
    i <- i + 1;
end

// for ループ
for item in items do
    item => println;
end
```

## 型システム

Opal は静的型付け言語で、以下の基本型を提供します：

- `Integer`: 整数型
- `Float`: 浮動小数点型
- `Boolean`: 真偽値型
- `String`: 文字列型
- `Char`: 文字型
- `Array<T>`: 配列型
- `Pointer`: ポインタ型
- ユーザー定義型（クラス）

## メモリ管理

Opal は手動メモリ管理を採用しています。メモリの割り当てと解放は明示的に行う必要があります。

```opal
// メモリの割り当て
let buffer <- MemoryAllocator.allocate(1024);

// メモリの解放
MemoryAllocator.free(buffer);
```

## 自己ホスティング

Opal コンパイラは Opal 自身で実装されており、外部言語に依存しない完全な自己ホスティングを実現しています。これには以下のコンポーネントが含まれます：

1. ネイティブコード生成器
2. システムコール層
3. ブートローダー
4. ブートストラップコンパイラ

## 標準ライブラリ

Opal は最小限の標準ライブラリを提供します：

- `String`: 文字列操作
- `Array`: 配列操作
- `MemoryAllocator`: メモリ管理
- `FileSystem`: ファイル操作
- `OpalSystemCall`: システムコール

## 実行モデル

Opal プログラムは以下のプロセスで実行されます：

1. ソースコードの字句解析
2. 構文解析と AST の構築
3. 型チェックと最適化
4. ネイティブコードの生成
5. 実行可能ファイルの生成と実行
