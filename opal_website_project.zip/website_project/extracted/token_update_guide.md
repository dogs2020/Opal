# トークン定義とキーワードマップの更新ガイド

## 概要

Opal言語の変数宣言キーワードを「let」から「nc」に統一するにあたり、トークン定義とキーワードマップの更新が必要です。このドキュメントでは、コンパイラの各コンポーネントで必要な更新について説明します。

## レキサーのトークン定義

レキサーのトークン定義では、以下のように「LET」トークンを「NC」トークンに変更する必要があります：

```opal
// 変更前
let LET: Integer <- 10;

// 変更後
nc NC: Integer <- 10;
```

## キーワードマップの更新

キーワードマップでは、「let」キーワードを「nc」に変更する必要があります：

```opal
// 変更前
this.keywords.put("let", TokenType.LET);

// 変更後
this.keywords.put("nc", TokenType.NC);
```

## パーサーの更新

パーサーでは、変数宣言を処理する部分を更新する必要があります：

```opal
// 変更前
function parse_variable_declaration() -> AST.VariableDeclarationNode then
    // 「let」キーワードを消費
    this.consume(TokenType.LET, "Expected 'let' keyword.");
    // ...
end

// 変更後
function parse_variable_declaration() -> AST.VariableDeclarationNode then
    // 「nc」キーワードを消費
    this.consume(TokenType.NC, "Expected 'nc' keyword.");
    // ...
end
```

## エラーメッセージの更新

エラーメッセージも「let」から「nc」に更新する必要があります：

```opal
// 変更前
"Expected 'let' keyword at the beginning of variable declaration."

// 変更後
"Expected 'nc' keyword at the beginning of variable declaration."
```

## AST（抽象構文木）ノードの更新

AST関連のコードでも、変数宣言ノードの処理を更新する必要があります：

```opal
// 変更前
function visit_variable_declaration(node: AST.VariableDeclarationNode) -> Void then
    // 「let」宣言の処理
    // ...
end

// 変更後
function visit_variable_declaration(node: AST.VariableDeclarationNode) -> Void then
    // 「nc」宣言の処理
    // ...
end
```

## コード生成部分の更新

コード生成部分でも、変数宣言に関する処理を更新する必要があります：

```opal
// 変更前
function generate_variable_declaration(node: AST.VariableDeclarationNode) -> Void then
    // 「let」宣言のコード生成
    // ...
end

// 変更後
function generate_variable_declaration(node: AST.VariableDeclarationNode) -> Void then
    // 「nc」宣言のコード生成
    // ...
end
```

## テストケースの更新

テストケースも「let」から「nc」に更新する必要があります：

```opal
// 変更前
function test_variable_declaration() -> Void then
    nc source <- "let x: Integer = 42;";
    // ...
end

// 変更後
function test_variable_declaration() -> Void then
    nc source <- "nc x: Integer = 42;";
    // ...
end
```

## 更新が必要なファイル

以下のファイルでトークン定義とキーワードマップの更新が必要です：

1. `/home/ubuntu/opal-project/pure-system/opal-first-pure-system-1.0/src/lexer.opal`
2. `/home/ubuntu/opal-project/pure-system/opal-first-pure-system-1.0/src/parser.opal`
3. `/home/ubuntu/opal-project/pure-system/opal-first-pure-system-1.0/src/compiler.opal`
4. `/home/ubuntu/opal-project/bootstrap_compiler/lexer.opal`
5. `/home/ubuntu/opal-project/bootstrap_compiler/parser.opal`

## 注意点

1. すべての「let」キーワードを「nc」に変更する際は、変数名や文字列リテラル内の「let」は変更しないよう注意してください。
2. エラーメッセージやコメント内の「let」も適切に「nc」に更新してください。
3. 更新後は必ずテストを実行し、すべての機能が正常に動作することを確認してください。
