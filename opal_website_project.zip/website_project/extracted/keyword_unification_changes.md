# Opal言語の「let」から「nc」へのキーワード統一 - 変更ドキュメント

## 概要

Opal言語の変数宣言キーワードを「let」から「nc」（not changeable）に統一するための変更を実施しました。この文書では、実施した変更の詳細と影響範囲について説明します。

## 変更の背景

Opal言語の初期設計では、変数宣言に「let」キーワードを使用していましたが、実際の実装では「nc」（not changeable）キーワードが使用されていました。この不一致により、言語仕様書、サンプルコード、実装の間で混乱が生じていました。

「nc」は「not changeable」の略であり、変数が不変（immutable）であることを明示するという言語設計の哲学をより適切に反映しています。そのため、言語全体で「nc」キーワードに統一することが決定されました。

## 変更内容

### 1. レキサー（lexer.opal）の更新

- トークン定義を「LET」から「NC」に変更
- キーワードマップのエントリを「let」から「nc」に変更
- 関連するエラーメッセージとコメントを更新

```opal
// 変更前
let LET: Integer <- 10;
this.keywords.put("let", TokenType.LET);

// 変更後
nc NC: Integer <- 10;
this.keywords.put("nc", TokenType.NC);
```

### 2. パーサー（parser.opal）の更新

- すべてのクラスフィールド宣言を「let」から「nc」に変更
- 変数宣言の解析ロジックを「TokenType.LET」から「TokenType.NC」に更新
- 関連するエラーメッセージとコメントを更新

```opal
// 変更前
function declaration() -> Stmt then
    try {
        if this.match(TokenType.LET) then
            return this.var_declaration();
        end
        // ...
    }
end

// 変更後
function declaration() -> Stmt then
    try {
        if this.match(TokenType.NC) then
            return this.var_declaration();
        end
        // ...
    }
end
```

### 3. 言語仕様書（language_specification.md）の更新

- キーワード一覧を更新し、「let」を「nc」に変更
- 変数宣言の構文定義を更新
- サンプルコードを更新
- 文法定義を更新

```markdown
// 変更前
variable_declaration = "let" identifier [":" type] ["=" | "<-" expression] ";";

// 変更後
variable_declaration = "nc" identifier [":" type] ["=" | "<-" expression] ";";
```

### 4. サンプルコード（hello_world.opal, fibonacci.opal, quicksort.opal）の更新

- すべてのサンプルコードの変数宣言を「let」から「nc」に変更

```opal
// 変更前
let x: Integer = 42;

// 変更後
nc x: Integer = 42;
```

### 5. 追加ドキュメントの作成

- 「nc」キーワードの意味と使用法に関するガイド（nc_keyword_guide.md）
- トークン定義とキーワードマップの更新ガイド（token_update_guide.md）

### 6. テストケースの作成

- 基本的な「nc」キーワードの使用をテストするケース（test_nc_keyword.opal）
- エッジケースをテストするケース（test_nc_keyword_edge_cases.opal）
- テスト実行スクリプト（run_tests.sh）

## 影響範囲

この変更は以下のコンポーネントに影響します：

1. **コンパイラ**：レキサー、パーサー、コード生成器
2. **ドキュメント**：言語仕様書、ユーザーガイド、APIリファレンス
3. **サンプルコード**：すべてのサンプルプログラム
4. **テストケース**：既存のテストケース

## 後方互換性

この変更は後方互換性を破壊します。「let」キーワードを使用する既存のOpalプログラムは、「nc」キーワードを使用するように更新する必要があります。

## 移行ガイド

既存のOpalプログラムを更新するには：

1. すべての「let」キーワードを「nc」に置き換える
2. 変数名や文字列リテラル内の「let」は変更しない
3. 更新後のプログラムをコンパイルして、エラーがないことを確認する

## 今後の課題

1. ブートストラップコンパイラの更新
2. 標準ライブラリの更新
3. 開発ツール（エディタプラグイン、構文ハイライターなど）の更新
4. 教育資料とチュートリアルの更新

## まとめ

Opal言語の変数宣言キーワードを「let」から「nc」に統一することで、言語の一貫性と明確さが向上しました。「nc」（not changeable）というキーワードは、変数が不変であるというOpal言語の設計哲学をより適切に反映しています。

この変更により、言語仕様書、実装、サンプルコードの間の不一致が解消され、Opal言語の学習と使用がより直感的になりました。
