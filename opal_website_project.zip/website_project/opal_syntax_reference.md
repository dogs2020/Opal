# Opal言語の正確な構文情報

## 出力演算子
- `->` : 出力後に改行を行わない
  - 例: `OpalSystemCall.("Hello, ") -> out;`
- `=>` : 出力後に改行を行う
  - 例: `OpalSystemCall.("Hello, World!") => out;`

## 代入演算子
- `<-` : 変数への代入に使用
  - 例: `nc value <- 10;`

## モジュール定義
```opal
module ModuleName then
    // モジュールの内容
end
```

## 関数定義
```opal
function functionName(param1: Type, param2: Type) -> ReturnType then
    // 関数の内容
end
```

## 定数宣言
- `nc` キーワードを使用
  - 例: `nc pi <- 3.14159;`

## 条件分岐
```opal
if condition then
    // 条件が真の場合の処理
else then
    // 条件が偽の場合の処理
end
```

## ループ
```opal
for (nc i <- 0; i < 10; i <- i + 1) then
    // 繰り返し処理
end
```

## Hello Worldの例
```opal
module HelloWorld then
    function first() -> Void then
        OpalSystemCall.("Hello, World!") -> out;
        // 改行の場合は => を使用
    end
end
```
