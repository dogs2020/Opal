// 言語比較ページのJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // 言語選択の変更イベント
    const languageSelect = document.getElementById('language-select');
    const languageDescription = document.getElementById('language-description');
    
    if (languageSelect && languageDescription) {
        languageSelect.addEventListener('change', function() {
            const selectedLanguage = this.value;
            updateLanguageDescription(selectedLanguage);
        });
    }
    
    // 比較表示ボタンのイベント
    const compareBtn = document.getElementById('compare-btn');
    const comparisonArea = document.getElementById('comparison-area');
    
    if (compareBtn && comparisonArea) {
        compareBtn.addEventListener('click', function() {
            showComparison();
        });
    }
    
    // 言語の説明を更新する関数
    function updateLanguageDescription(language) {
        let description = '';
        
        switch(language) {
            case 'opal':
                description = `
                    <h5>Opal</h5>
                    <p>Opal（オパール）は高速で効率的なプログラミング言語として設計されています。手動メモリ管理と最小限のランタイムオーバーヘッドを特徴とし、SwiftやC++よりも高速な実行速度を目指しています。</p>
                    <p>特徴:</p>
                    <ul>
                        <li>静的型付け</li>
                        <li>手動メモリ管理</li>
                        <li>関数型プログラミングの要素</li>
                        <li>最小限のランタイムオーバーヘッド</li>
                        <li>自己ホスティングコンパイラ</li>
                    </ul>
                    <p>サンプルコード:</p>
                    <pre><code class="language-opal">function first() -> Integer then
    println("Hello, World!");
    return 0;
end</code></pre>
                `;
                break;
            case 'cpp':
                description = `
                    <h5>C++</h5>
                    <p>C++は高性能なシステムプログラミング言語で、ハードウェアに近いレベルでの制御が可能です。多くのオペレーティングシステム、ゲームエンジン、ハイパフォーマンスソフトウェアで使用されています。</p>
                    <p>特徴:</p>
                    <ul>
                        <li>静的型付け</li>
                        <li>手動メモリ管理（スマートポインタもサポート）</li>
                        <li>オブジェクト指向プログラミング</li>
                        <li>テンプレートによるジェネリックプログラミング</li>
                        <li>高度な最適化が可能</li>
                    </ul>
                    <p>サンプルコード:</p>
                    <pre><code class="language-cpp">#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}</code></pre>
                `;
                break;
            case 'python':
                description = `
                    <h5>Python</h5>
                    <p>Pythonは読みやすく書きやすい高水準言語で、データ分析、機械学習、ウェブ開発など幅広い分野で使用されています。生産性を重視した設計が特徴です。</p>
                    <p>特徴:</p>
                    <ul>
                        <li>動的型付け</li>
                        <li>自動メモリ管理（ガベージコレクション）</li>
                        <li>インタープリタ型言語</li>
                        <li>豊富なライブラリエコシステム</li>
                        <li>読みやすい構文</li>
                    </ul>
                    <p>サンプルコード:</p>
                    <pre><code class="language-python">def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()</code></pre>
                `;
                break;
            case 'swift':
                description = `
                    <h5>Swift</h5>
                    <p>SwiftはAppleが開発したモダンなプログラミング言語で、iOS、macOS、watchOS、tvOSアプリケーション開発に使用されます。安全性と表現力を重視しています。</p>
                    <p>特徴:</p>
                    <ul>
                        <li>静的型付け（型推論あり）</li>
                        <li>自動メモリ管理（ARC）</li>
                        <li>値型と参照型の明確な区別</li>
                        <li>オプショナル型による安全性</li>
                        <li>プロトコル指向プログラミング</li>
                    </ul>
                    <p>サンプルコード:</p>
                    <pre><code class="language-swift">func main() {
    print("Hello, World!")
}

main()</code></pre>
                `;
                break;
            case 'javascript':
                description = `
                    <h5>JavaScript</h5>
                    <p>JavaScriptはウェブブラウザで動作するスクリプト言語として開発され、現在はNode.jsなどのランタイムを通じてサーバーサイドでも使用されています。</p>
                    <p>特徴:</p>
                    <ul>
                        <li>動的型付け</li>
                        <li>自動メモリ管理（ガベージコレクション）</li>
                        <li>プロトタイプベースのオブジェクト指向</li>
                        <li>非同期プログラミング（Promise, async/await）</li>
                        <li>関数型プログラミングの要素</li>
                    </ul>
                    <p>サンプルコード:</p>
                    <pre><code class="language-javascript">function main() {
    console.log("Hello, World!");
}

main();</code></pre>
                `;
                break;
            default:
                description = '<p>左側のフォームから言語を選択すると、ここに詳細な説明が表示されます。</p>';
        }
        
        languageDescription.innerHTML = description;
        
        // シンタックスハイライトを適用
        if (Prism) {
            Prism.highlightAll();
        }
    }
    
    // 比較を表示する関数
    function showComparison() {
        // 選択された言語を取得
        const selectedLanguages = [];
        
        document.querySelectorAll('input[type="checkbox"]:checked').forEach(checkbox => {
            selectedLanguages.push(checkbox.value);
        });
        
        // 比較エリアを表示
        comparisonArea.style.display = 'block';
        
        // 比較テーブルを更新
        updateComparisonTable(selectedLanguages);
        
        // 比較グラフを描画
        drawComparisonCharts(selectedLanguages);
        
        // 共有URLを更新
        document.getElementById('comparison-share-url').value = `https://mymkyoko.manus.space/language_comparison.html?langs=${selectedLanguages.join(',')}`;
    }
    
    // 比較テーブルを更新する関数
    function updateComparisonTable(languages) {
        // 言語の特性データ
        const languageData = {
            'opal': {
                typing: '静的型付け',
                memory: '手動メモリ管理',
                paradigm: '命令型、関数型',
                performance: '非常に高速',
                ecosystem: '発展途上',
                learning: '中程度',
                usage: 'システムプログラミング、高性能アプリケーション'
            },
            'cpp': {
                typing: '静的型付け',
                memory: '手動メモリ管理（スマートポインタあり）',
                paradigm: '命令型、オブジェクト指向、ジェネリック',
                performance: '非常に高速',
                ecosystem: '成熟',
                learning: '難しい',
                usage: 'システムプログラミング、ゲーム開発、ハイパフォーマンスアプリケーション'
            },
            'python': {
                typing: '動的型付け（型ヒントあり）',
                memory: 'ガベージコレクション',
                paradigm: '命令型、オブジェクト指向、関数型',
                performance: '低速～中程度',
                ecosystem: '非常に豊富',
                learning: '簡単',
                usage: 'データ分析、機械学習、ウェブ開発、スクリプティング'
            },
            'swift': {
                typing: '静的型付け（型推論あり）',
                memory: 'ARC（自動参照カウント）',
                paradigm: '命令型、オブジェクト指向、プロトコル指向',
                performance: '高速',
                ecosystem: '成長中（主にAppleプラットフォーム）',
                learning: '中程度',
                usage: 'iOS/macOSアプリ開発、サーバーサイド開発'
            },
            'javascript': {
                typing: '動的型付け（TypeScriptで静的型付けも可能）',
                memory: 'ガベージコレクション',
                paradigm: '命令型、オブジェクト指向（プロトタイプベース）、関数型',
                performance: '中程度',
                ecosystem: '非常に豊富',
                learning: '比較的簡単',
                usage: 'ウェブフロントエンド、サーバーサイド開発、モバイルアプリ'
            }
        };
        
        // テーブルヘッダーを作成
        const tableHead = document.getElementById('comparison-table-head');
        let headerRow = '<tr><th>特性</th>';
        
        languages.forEach(lang => {
            headerRow += `<th>${lang.charAt(0).toUpperCase() + lang.slice(1)}</th>`;
        });
        
        headerRow += '</tr>';
        tableHead.innerHTML = headerRow;
        
        // テーブルボディを作成
        const tableBody = document.getElementById('comparison-table-body');
        tableBody.innerHTML = '';
        
        // 各特性の行を作成
        const features = [
            { id: 'typing', name: '型システム' },
            { id: 'memory', name: 'メモリ管理' },
            { id: 'paradigm', name: 'プログラミングパラダイム' },
            { id: 'performance', name: 'パフォーマンス' },
            { id: 'ecosystem', name: 'エコシステム' },
            { id: 'learning', name: '学習難易度' },
            { id: 'usage', name: '主な用途' }
        ];
        
        features.forEach(feature => {
            let row = `<tr><td>${feature.name}</td>`;
            
            languages.forEach(lang => {
                row += `<td>${languageData[lang][feature.id]}</td>`;
            });
            
            row += '</tr>';
            tableBody.innerHTML += row;
        });
    }
    
    // 比較グラフを描画する関数
    function drawComparisonCharts(languages) {
        // パフォーマンスデータ
        const performanceData = {
            'opal': 95,
            'cpp': 100,
            'python': 30,
            'swift': 80,
            'javascript': 50
        };
        
        // 生産性データ
        const productivityData = {
            'opal': 70,
            'cpp': 50,
            'python': 95,
            'swift': 85,
            'javascript': 90
        };
        
        // メモリ使用量データ
        const memoryData = {
            'opal': 30,
            'cpp': 25,
            'python': 80,
            'swift': 45,
            'javascript': 70
        };
        
        // 言語ごとの色
        const colors = {
            'opal': 'rgba(0, 102, 255, 0.7)',
            'cpp': 'rgba(0, 153, 51, 0.7)',
            'python': 'rgba(255, 204, 0, 0.7)',
            'swift': 'rgba(255, 102, 0, 0.7)',
            'javascript': 'rgba(153, 51, 255, 0.7)'
        };
        
        // パフォーマンスグラフ
        const perfCtx = document.getElementById('performance-chart').getContext('2d');
        const perfData = languages.map(lang => performanceData[lang]);
        const perfColors = languages.map(lang => colors[lang]);
        const perfLabels = languages.map(lang => lang.charAt(0).toUpperCase() + lang.slice(1));
        
        new Chart(perfCtx, {
            type: 'bar',
            data: {
                labels: perfLabels,
                datasets: [{
                    label: 'パフォーマンス (相対値)',
                    data: perfData,
                    backgroundColor: perfColors,
                    borderColor: perfColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
        
        // 生産性グラフ
        const prodCtx = document.getElementById('productivity-chart').getContext('2d');
        const prodData = languages.map(lang => productivityData[lang]);
        
        new Chart(prodCtx, {
            type: 'bar',
            data: {
                labels: perfLabels,
                datasets: [{
                    label: '開発生産性 (相対値)',
                    data: prodData,
                    backgroundColor: perfColors,
                    borderColor: perfColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
        
        // メモリ使用量グラフ
        const memCtx = document.getElementById('memory-chart').getContext('2d');
        const memData = languages.map(lang => memoryData[lang]);
        
        new Chart(memCtx, {
            type: 'bar',
            data: {
                labels: perfLabels,
                datasets: [{
                    label: 'メモリ使用量 (相対値、低いほど良い)',
                    data: memData,
                    backgroundColor: perfColors,
                    borderColor: perfColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
        
        // レーダーチャート
        const radarCtx = document.getElementById('radar-chart').getContext('2d');
        
        const radarDatasets = languages.map(lang => {
            return {
                label: lang.charAt(0).toUpperCase() + lang.slice(1),
                data: [
                    performanceData[lang],
                    100 - memoryData[lang], // メモリ使用量は逆転（低いほど良い）
                    productivityData[lang],
                    lang === 'opal' ? 90 : (lang === 'cpp' ? 95 : (lang === 'python' ? 60 : (lang === 'swift' ? 85 : 70))), // 型安全性
                    lang === 'opal' ? 75 : (lang === 'cpp' ? 60 : (lang === 'python' ? 95 : (lang === 'swift' ? 85 : 90))), // エコシステム
                ],
                backgroundColor: colors[lang].replace('0.7', '0.2'),
                borderColor: colors[lang].replace('0.7', '1'),
                pointBackgroundColor: colors[lang].replace('0.7', '1'),
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: colors[lang].replace('0.7', '1')
            };
        });
        
        new Chart(radarCtx, {
            type: 'radar',
            data: {
                labels: [
                    'パフォーマンス',
                    'メモリ効率',
                    '開発生産性',
                    '型安全性',
                    'エコシステム'
                ],
                datasets: radarDatasets
            },
            options: {
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: 100
                    }
                }
            }
        });
    }
    
    // コピーボタンのイベント
    const comparisonCopyUrlBtn = document.getElementById('comparison-copy-url-btn');
    if (comparisonCopyUrlBtn) {
        comparisonCopyUrlBtn.addEventListener('click', function() {
            const shareUrl = document.getElementById('comparison-share-url');
            shareUrl.select();
            document.execCommand('copy');
            
            // コピー成功メッセージ
            this.innerHTML = '<i class="bi bi-check"></i> コピー完了';
            setTimeout(() => {
                this.innerHTML = '<i class="bi bi-clipboard"></i> コピー';
            }, 2000);
        });
    }
    
    // ダウンロードボタンのイベント
    const comparisonDownloadBtn = document.getElementById('comparison-download-btn');
    if (comparisonDownloadBtn) {
        comparisonDownloadBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーからファイルをダウンロードします
            alert('比較結果をCSVファイルとしてダウンロードします。');
        });
    }
});
