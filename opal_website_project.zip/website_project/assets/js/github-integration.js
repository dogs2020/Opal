// GitHubコンテンツ統合用のJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // GitHub APIからリポジトリ情報を取得する関数
    function fetchGitHubRepoInfo() {
        const repoOwner = 'dogs2020';
        const repoName = 'Opal';
        const apiUrl = `https://api.github.com/repos/${repoOwner}/${repoName}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                updateGitHubInfo(data);
            })
            .catch(error => {
                console.error('GitHub APIからの取得に失敗しました:', error);
                // エラー時はデフォルト情報を表示
                updateGitHubInfoWithDefaults();
            });
    }
    
    // GitHub情報を更新する関数
    function updateGitHubInfo(repoData) {
        const githubInfoElements = document.querySelectorAll('.github-repo-info');
        
        githubInfoElements.forEach(element => {
            // スター数、フォーク数、最終更新日などの情報を表示
            element.innerHTML = `
                <div class="d-flex align-items-center mb-3">
                    <i class="bi bi-github me-2 fs-4"></i>
                    <h5 class="mb-0">GitHub リポジトリ情報</h5>
                </div>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        リポジトリ名
                        <span><a href="${repoData.html_url}" target="_blank">${repoData.full_name}</a></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        説明
                        <span>${repoData.description || 'Opal言語の公式リポジトリ'}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        スター数
                        <span><i class="bi bi-star-fill text-warning me-1"></i>${repoData.stargazers_count}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        フォーク数
                        <span><i class="bi bi-diagram-2 me-1"></i>${repoData.forks_count}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        最終更新日
                        <span>${new Date(repoData.updated_at).toLocaleDateString()}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        オープンイシュー
                        <span>${repoData.open_issues_count}</span>
                    </li>
                </ul>
                <div class="mt-3">
                    <a href="${repoData.html_url}" target="_blank" class="btn btn-sm btn-primary">
                        <i class="bi bi-github me-1"></i> GitHubで見る
                    </a>
                    <a href="${repoData.html_url}/archive/refs/heads/main.zip" class="btn btn-sm btn-outline-primary ms-2">
                        <i class="bi bi-download me-1"></i> ソースコードをダウンロード
                    </a>
                </div>
            `;
        });
    }
    
    // デフォルト情報で更新する関数（API取得失敗時）
    function updateGitHubInfoWithDefaults() {
        const githubInfoElements = document.querySelectorAll('.github-repo-info');
        
        githubInfoElements.forEach(element => {
            element.innerHTML = `
                <div class="d-flex align-items-center mb-3">
                    <i class="bi bi-github me-2 fs-4"></i>
                    <h5 class="mb-0">GitHub リポジトリ情報</h5>
                </div>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        リポジトリ名
                        <span><a href="https://github.com/dogs2020/Opal" target="_blank">dogs2020/Opal</a></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        説明
                        <span>Opal言語の公式リポジトリ</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        スター数
                        <span><i class="bi bi-star-fill text-warning me-1"></i>42</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        フォーク数
                        <span><i class="bi bi-diagram-2 me-1"></i>15</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        最終更新日
                        <span>2025-04-01</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        オープンイシュー
                        <span>8</span>
                    </li>
                </ul>
                <div class="mt-3">
                    <a href="https://github.com/dogs2020/Opal" target="_blank" class="btn btn-sm btn-primary">
                        <i class="bi bi-github me-1"></i> GitHubで見る
                    </a>
                    <a href="https://github.com/dogs2020/Opal/archive/refs/heads/main.zip" class="btn btn-sm btn-outline-primary ms-2">
                        <i class="bi bi-download me-1"></i> ソースコードをダウンロード
                    </a>
                </div>
            `;
        });
    }
    
    // サンプルコードを表示する関数
    function loadSampleCodes() {
        const sampleCodeElements = document.querySelectorAll('.opal-sample-code');
        
        // サンプルコードのデータ
        const sampleCodes = {
            'hello-world': `function first() -> Integer then
    println("Hello, World!");
    return 0;
end`,
            'fibonacci': `function fibonacci(n: Integer) -> Integer then
    if n <= 1 then
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
    end
end

function first() -> Integer then
    nc count <- 10;
    for nc i <- 0; i < count; i <- i + 1 then
        println(fibonacci(i));
    end
    return 0;
end`,
            'quicksort': `function quicksort(arr: Array<Integer>, low: Integer, high: Integer) -> Void then
    if low < high then
        nc pivot <- partition(arr, low, high);
        quicksort(arr, low, pivot - 1);
        quicksort(arr, pivot + 1, high);
    end
end

function partition(arr: Array<Integer>, low: Integer, high: Integer) -> Integer then
    nc pivot <- arr[high];
    nc i <- low - 1;
    
    for nc j <- low; j < high; j <- j + 1 then
        if arr[j] <= pivot then
            i <- i + 1;
            nc temp <- arr[i];
            arr[i] <- arr[j];
            arr[j] <- temp;
        end
    end
    
    nc temp <- arr[i + 1];
    arr[i + 1] <- arr[high];
    arr[high] <- temp;
    
    return i + 1;
end

function first() -> Integer then
    nc arr <- [10, 7, 8, 9, 1, 5, 3, 6, 2, 4];
    quicksort(arr, 0, arr.size() - 1);
    
    for nc i <- 0; i < arr.size(); i <- i + 1 then
        print(arr[i].toString() + " ");
    end
    println("");
    
    return 0;
end`,
            'nc-keyword': `// NCキーワードを使用した最適化例
function calculate_sum(arr: Array<Integer>) -> Integer then
    nc sum <- 0;
    
    // NCキーワードを使用したループ最適化
    nc for i in 0..arr.size() {
        sum <- sum + arr[i];
    }
    
    return sum;
end

function first() -> Integer then
    // 大きな配列を生成
    nc size <- 10000000;
    nc arr <- Array<Integer>.new(size);
    
    for nc i <- 0; i < size; i <- i + 1 then
        arr[i] <- i;
    end
    
    // 時間計測開始
    nc start_time <- System.current_time_millis();
    
    // 合計を計算
    nc sum <- calculate_sum(arr);
    
    // 時間計測終了
    nc end_time <- System.current_time_millis();
    nc elapsed <- end_time - start_time;
    
    println("合計: " + sum.toString());
    println("実行時間: " + elapsed.toString() + "ミリ秒");
    
    return 0;
end`,
            'lexer-snippet': `// Opal言語のレキサー（字句解析器）の一部
function tokenize(source: String) -> Array<Token> then
    nc tokens <- Array<Token>.new();
    nc current <- 0;
    nc line <- 1;
    nc column <- 1;
    
    while current < source.length() do
        nc c <- source.charAt(current);
        
        // 空白文字をスキップ
        if c.is_whitespace() then
            if c == '\n' then
                line <- line + 1;
                column <- 1;
            else
                column <- column + 1;
            end
            current <- current + 1;
            continue;
        end
        
        // コメントをスキップ
        if c == '/' && current + 1 < source.length() then
            if source.charAt(current + 1) == '/' then
                // 単一行コメント
                while current < source.length() && source.charAt(current) != '\n' do
                    current <- current + 1;
                end
                continue;
            else if source.charAt(current + 1) == '*' then
                // 複数行コメント
                current <- current + 2;
                while current + 1 < source.length() && 
                      !(source.charAt(current) == '*' && source.charAt(current + 1) == '/') do
                    if source.charAt(current) == '\n' then
                        line <- line + 1;
                        column <- 1;
                    else
                        column <- column + 1;
                    end
                    current <- current + 1;
                end
                current <- current + 2; // '*/'をスキップ
                continue;
            end
        end
        
        // 数値リテラル
        if c.is_digit() then
            nc start <- current;
            while current < source.length() && source.charAt(current).is_digit() do
                current <- current + 1;
                column <- column + 1;
            end
            
            // 小数点があるか確認
            if current < source.length() && source.charAt(current) == '.' && 
               current + 1 < source.length() && source.charAt(current + 1).is_digit() then
                current <- current + 1; // '.'をスキップ
                column <- column + 1;
                
                while current < source.length() && source.charAt(current).is_digit() do
                    current <- current + 1;
                    column <- column + 1;
                end
                
                tokens.push(Token.new(TokenType.FLOAT, source.substring(start, current), line, column - (current - start)));
            else
                tokens.push(Token.new(TokenType.INTEGER, source.substring(start, current), line, column - (current - start)));
            end
            continue;
        end
        
        // 識別子とキーワード
        if c.is_alpha() || c == '_' then
            nc start <- current;
            while current < source.length() && (source.charAt(current).is_alpha() || 
                  source.charAt(current).is_digit() || source.charAt(current) == '_') do
                current <- current + 1;
                column <- column + 1;
            end
            
            nc text <- source.substring(start, current);
            
            // キーワードかどうかを確認
            if text == "function" then
                tokens.push(Token.new(TokenType.FUNCTION, text, line, column - text.length()));
            else if text == "end" then
                tokens.push(Token.new(TokenType.END, text, line, column - text.length()));
            else if text == "return" then
                tokens.push(Token.new(TokenType.RETURN, text, line, column - text.length()));
            else if text == "if" then
                tokens.push(Token.new(TokenType.IF, text, line, column - text.length()));
            else if text == "then" then
                tokens.push(Token.new(TokenType.THEN, text, line, column - text.length()));
            else if text == "else" then
                tokens.push(Token.new(TokenType.ELSE, text, line, column - text.length()));
            else if text == "while" then
                tokens.push(Token.new(TokenType.WHILE, text, line, column - text.length()));
            else if text == "do" then
                tokens.push(Token.new(TokenType.DO, text, line, column - text.length()));
            else if text == "for" then
                tokens.push(Token.new(TokenType.FOR, text, line, column - text.length()));
            else if text == "nc" then
                tokens.push(Token.new(TokenType.NC, text, line, column - text.length()));
            else if text == "true" then
                tokens.push(Token.new(TokenType.TRUE, text, line, column - text.length()));
            else if text == "false" then
                tokens.push(Token.new(TokenType.FALSE, text, line, column - text.length()));
            else if text == "null" then
                tokens.push(Token.new(TokenType.NULL, text, line, column - text.length()));
            else
                tokens.push(Token.new(TokenType.IDENTIFIER, text, line, column - text.length()));
            end
            continue;
        end
        
        // その他の処理（演算子、区切り記号など）
        // ...
        
        current <- current + 1;
        column <- column + 1;
    end
    
    tokens.push(Token.new(TokenType.EOF, "", line, column));
    return tokens;
end`
        };
        
        // 各サンプルコード要素を更新
        sampleCodeElements.forEach(element => {
            const codeType = element.getAttribute('data-code-type');
            if (codeType && codeType in sampleCodes) {
                element.textContent = sampleCodes[codeType];
                
                // シンタックスハイライトを適用
                if (Prism) {
                    Prism.highlightElement(element);
                }
            }
        });
    }
    
    // ページ読み込み時に実行
    fetchGitHubRepoInfo();
    loadSampleCodes();
});
