// ベンチマークデータを格納するオブジェクト
const benchmarkData = {
  // Fannkuch Redux (n=10)のデータ
  fannkuchRedux: {
    cpp: { time: 0.258, relative: 1.00 },
    javascript: { time: 0.475, relative: 1.84 },
    swift: { time: 1.770, relative: 6.86 },
    python: { time: 9.011, relative: 34.93 },
    opal: { time: 0.350, relative: 1.36 }
  },
  
  // N-Body (50000ステップ)のデータ
  nBody: {
    cpp: { time: 0.016, relative: 1.00 },
    javascript: { time: 0.067, relative: 4.19 },
    swift: { time: 0.675, relative: 42.19 },
    python: { time: 1.964, relative: 122.75 },
    opal: { time: 0.045, relative: 2.81 }
  }
};

// ベンチマークデータを表示する関数
function displayBenchmarkData() {
  // Fannkuch Reduxのデータを表示
  document.getElementById('fannkuch-cpp').textContent = benchmarkData.fannkuchRedux.cpp.time.toFixed(3) + 's (1.00x)';
  document.getElementById('fannkuch-javascript').textContent = benchmarkData.fannkuchRedux.javascript.time.toFixed(3) + 's (' + benchmarkData.fannkuchRedux.javascript.relative.toFixed(2) + 'x)';
  document.getElementById('fannkuch-swift').textContent = benchmarkData.fannkuchRedux.swift.time.toFixed(3) + 's (' + benchmarkData.fannkuchRedux.swift.relative.toFixed(2) + 'x)';
  document.getElementById('fannkuch-python').textContent = benchmarkData.fannkuchRedux.python.time.toFixed(3) + 's (' + benchmarkData.fannkuchRedux.python.relative.toFixed(2) + 'x)';
  document.getElementById('fannkuch-opal').textContent = benchmarkData.fannkuchRedux.opal.time.toFixed(3) + 's (' + benchmarkData.fannkuchRedux.opal.relative.toFixed(2) + 'x)';
  
  // N-Bodyのデータを表示
  document.getElementById('nbody-cpp').textContent = benchmarkData.nBody.cpp.time.toFixed(3) + 's (1.00x)';
  document.getElementById('nbody-javascript').textContent = benchmarkData.nBody.javascript.time.toFixed(3) + 's (' + benchmarkData.nBody.javascript.relative.toFixed(2) + 'x)';
  document.getElementById('nbody-swift').textContent = benchmarkData.nBody.swift.time.toFixed(3) + 's (' + benchmarkData.nBody.swift.relative.toFixed(2) + 'x)';
  document.getElementById('nbody-python').textContent = benchmarkData.nBody.python.time.toFixed(3) + 's (' + benchmarkData.nBody.python.relative.toFixed(2) + 'x)';
  document.getElementById('nbody-opal').textContent = benchmarkData.nBody.opal.time.toFixed(3) + 's (' + benchmarkData.nBody.opal.relative.toFixed(2) + 'x)';
  
  // グラフの更新（もし実装されている場合）
  updateBenchmarkCharts();
}

// グラフを更新する関数
function updateBenchmarkCharts() {
  // Chart.jsなどのライブラリを使用してグラフを描画する場合の処理
  if (typeof Chart !== 'undefined') {
    // Fannkuch Reduxのグラフデータ
    const fannkuchData = {
      labels: ['C++', 'JavaScript', 'Swift', 'Python', 'Opal'],
      datasets: [{
        label: 'Fannkuch Redux (n=10) 実行時間 (秒)',
        data: [
          benchmarkData.fannkuchRedux.cpp.time,
          benchmarkData.fannkuchRedux.javascript.time,
          benchmarkData.fannkuchRedux.swift.time,
          benchmarkData.fannkuchRedux.python.time,
          benchmarkData.fannkuchRedux.opal.time
        ],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)'
        ],
        borderWidth: 1
      }]
    };
    
    // N-Bodyのグラフデータ
    const nBodyData = {
      labels: ['C++', 'JavaScript', 'Swift', 'Python', 'Opal'],
      datasets: [{
        label: 'N-Body (50000ステップ) 実行時間 (秒)',
        data: [
          benchmarkData.nBody.cpp.time,
          benchmarkData.nBody.javascript.time,
          benchmarkData.nBody.swift.time,
          benchmarkData.nBody.python.time,
          benchmarkData.nBody.opal.time
        ],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)'
        ],
        borderWidth: 1
      }]
    };
    
    // グラフの描画
    const fannkuchCtx = document.getElementById('fannkuch-chart');
    if (fannkuchCtx) {
      new Chart(fannkuchCtx, {
        type: 'bar',
        data: fannkuchData,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
    
    const nBodyCtx = document.getElementById('nbody-chart');
    if (nBodyCtx) {
      new Chart(nBodyCtx, {
        type: 'bar',
        data: nBodyData,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  }
}

// ページ読み込み時にベンチマークデータを表示
document.addEventListener('DOMContentLoaded', function() {
  displayBenchmarkData();
});
