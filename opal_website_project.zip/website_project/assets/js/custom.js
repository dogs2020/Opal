// カスタムベンチマークページのJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // CodeMirrorエディタの初期化
    const opalEditor = CodeMirror.fromTextArea(document.getElementById('opal-editor'), {
        lineNumbers: true,
        mode: 'text/x-c++src', // Opal用のモードがないのでC++モードを使用
        theme: 'dracula',
        indentUnit: 4,
        smartIndent: true,
        tabSize: 4,
        indentWithTabs: false,
        lineWrapping: true,
        autoCloseBrackets: true,
        matchBrackets: true
    });

    const cppEditor = CodeMirror.fromTextArea(document.getElementById('cpp-editor'), {
        lineNumbers: true,
        mode: 'text/x-c++src',
        theme: 'dracula',
        indentUnit: 4,
        smartIndent: true,
        tabSize: 4,
        indentWithTabs: false,
        lineWrapping: true,
        autoCloseBrackets: true,
        matchBrackets: true
    });

    const pythonEditor = CodeMirror.fromTextArea(document.getElementById('python-editor'), {
        lineNumbers: true,
        mode: 'text/x-python',
        theme: 'dracula',
        indentUnit: 4,
        smartIndent: true,
        tabSize: 4,
        indentWithTabs: false,
        lineWrapping: true,
        autoCloseBrackets: true,
        matchBrackets: true
    });

    const swiftEditor = CodeMirror.fromTextArea(document.getElementById('swift-editor'), {
        lineNumbers: true,
        mode: 'text/x-c++src', // Swift用のモードがないのでC++モードを使用
        theme: 'dracula',
        indentUnit: 4,
        smartIndent: true,
        tabSize: 4,
        indentWithTabs: false,
        lineWrapping: true,
        autoCloseBrackets: true,
        matchBrackets: true
    });

    const jsEditor = CodeMirror.fromTextArea(document.getElementById('js-editor'), {
        lineNumbers: true,
        mode: 'javascript',
        theme: 'dracula',
        indentUnit: 4,
        smartIndent: true,
        tabSize: 4,
        indentWithTabs: false,
        lineWrapping: true,
        autoCloseBrackets: true,
        matchBrackets: true
    });

    // サンプルコード選択の変更イベント
    const sampleCodeSelect = document.getElementById('sample-code-select');
    const sampleCodeDescription = document.getElementById('sample-code-description');
    
    if (sampleCodeSelect) {
        sampleCodeSelect.addEventListener('change', function() {
            const selectedSample = this.value;
            loadSampleCode(selectedSample);
            updateSampleDescription(selectedSample);
        });
    }
    
    // ベンチマーク実行ボタンのイベント
    const runBenchmarkBtn = document.getElementById('run-benchmark-btn');
    const customResultsArea = document.getElementById('custom-results-area');
    
    if (runBenchmarkBtn && customResultsArea) {
        runBenchmarkBtn.addEventListener('click', function() {
            runCustomBenchmark();
        });
    }
    
    // クリアボタンのイベント
    const clearCodeBtn = document.getElementById('clear-code-btn');
    if (clearCodeBtn) {
        clearCodeBtn.addEventListener('click', function() {
            clearAllEditors();
        });
    }
    
    // サンプルコードを読み込む関数
    function loadSampleCode(sample) {
        // サンプルコードの定義
        const sampleCodes = {
            'fibonacci': {
                opal: `function fibonacci(n: Integer) -> Integer then
    if n <= 1 then
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
    end
end

function first() -> Integer then
    nc count <- 20;
    for nc i <- 0; i < count; i <- i + 1 then
        println(fibonacci(i));
    end
    return 0;
end`,
                cpp: `#include <iostream>

int fibonacci(int n) {
    if (n <= 1)
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    const int count = 20;
    for (int i = 0; i < count; i++) {
        std::cout << fibonacci(i) << std::endl;
    }
    return 0;
}`,
                python: `def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

count = 20
for i in range(count):
    print(fibonacci(i))`,
                swift: `func fibonacci(_ n: Int) -> Int {
    if n <= 1 {
        return n
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2)
    }
}

let count = 20
for i in 0..<count {
    print(fibonacci(i))
}`,
                javascript: `function fibonacci(n) {
    if (n <= 1)
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
}

const count = 20;
for (let i = 0; i < count; i++) {
    console.log(fibonacci(i));
}`
            },
            'quicksort': {
                opal: `function quicksort(arr: Array<Integer>, low: Integer, high: Integer) -> Void then
    if low < high then
        nc pivot <- partition(arr, low, high);
        quicksort(arr, low, pivot - 1);
        quicksort(arr, pivot + 1, high);
    end
end

function partition(arr: Array<Integer>, low: Integer, high: Integer) -> Integer then
    nc pivot <- arr[high];
    nc i <- low - 1;
    
    for nc j <- low; j < high; j <- j + 1 then
        if arr[j] <= pivot then
            i <- i + 1;
            nc temp <- arr[i];
            arr[i] <- arr[j];
            arr[j] <- temp;
        end
    end
    
    nc temp <- arr[i + 1];
    arr[i + 1] <- arr[high];
    arr[high] <- temp;
    
    return i + 1;
end

function first() -> Integer then
    nc arr <- [10, 7, 8, 9, 1, 5, 3, 6, 2, 4];
    quicksort(arr, 0, arr.size() - 1);
    
    for nc i <- 0; i < arr.size(); i <- i + 1 then
        print(arr[i].toString() + " ");
    end
    println("");
    
    return 0;
end`,
                cpp: `#include <iostream>
#include <vector>

void quicksort(std::vector<int>& arr, int low, int high) {
    if (low < high) {
        // パーティション
        int pivot = arr[high];
        int i = low - 1;
        
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                std::swap(arr[i], arr[j]);
            }
        }
        std::swap(arr[i + 1], arr[high]);
        
        int pivotIndex = i + 1;
        
        // 再帰的にソート
        quicksort(arr, low, pivotIndex - 1);
        quicksort(arr, pivotIndex + 1, high);
    }
}

int main() {
    std::vector<int> arr = {10, 7, 8, 9, 1, 5, 3, 6, 2, 4};
    quicksort(arr, 0, arr.size() - 1);
    
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    return 0;
}`,
                python: `def quicksort(arr, low, high):
    if low < high:
        # パーティション
        pivot = arr[high]
        i = low - 1
        
        for j in range(low, high):
            if arr[j] <= pivot:
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
        
        arr[i + 1], arr[high] = arr[high], arr[i + 1]
        
        pivot_index = i + 1
        
        # 再帰的にソート
        quicksort(arr, low, pivot_index - 1)
        quicksort(arr, pivot_index + 1, high)

arr = [10, 7, 8, 9, 1, 5, 3, 6, 2, 4]
quicksort(arr, 0, len(arr) - 1)
print(' '.join(map(str, arr)))`,
                swift: `func quicksort(_ arr: inout [Int], _ low: Int, _ high: Int) {
    if low < high {
        // パーティション
        let pivot = arr[high]
        var i = low - 1
        
        for j in low..<high {
            if arr[j] <= pivot {
                i += 1
                arr.swapAt(i, j)
            }
        }
        arr.swapAt(i + 1, high)
        
        let pivotIndex = i + 1
        
        // 再帰的にソート
        quicksort(&arr, low, pivotIndex - 1)
        quicksort(&arr, pivotIndex + 1, high)
    }
}

var arr = [10, 7, 8, 9, 1, 5, 3, 6, 2, 4]
quicksort(&arr, 0, arr.count - 1)
print(arr.map { String($0) }.joined(separator: " "))`,
                javascript: `function quicksort(arr, low, high) {
    if (low < high) {
        // パーティション
        const pivot = arr[high];
        let i = low - 1;
        
        for (let j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                [arr[i], arr[j]] = [arr[j], arr[i]];
            }
        }
        [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
        
        const pivotIndex = i + 1;
        
        // 再帰的にソート
        quicksort(arr, low, pivotIndex - 1);
        quicksort(arr, pivotIndex + 1, high);
    }
}

const arr = [10, 7, 8, 9, 1, 5, 3, 6, 2, 4];
quicksort(arr, 0, arr.length - 1);
console.log(arr.join(' '));`
            },
            'prime': {
                opal: `function is_prime(n: Integer) -> Boolean then
    if n <= 1 then
        return false;
    end
    
    if n <= 3 then
        return true;
    end
    
    if n % 2 == 0 || n % 3 == 0 then
        return false;
    end
    
    nc i <- 5;
    while i * i <= n do
        if n % i == 0 || n % (i + 2) == 0 then
            return false;
        end
        i <- i + 6;
    end
    
    return true;
end

function first() -> Integer then
    nc limit <- 1000;
    nc count <- 0;
    
    for nc i <- 2; i <= limit; i <- i + 1 then
        if is_prime(i) then
            count <- count + 1;
            print(i.toString() + " ");
            
            if count % 10 == 0 then
                println("");
            end
        end
    end
    
    println("\n素数の総数: " + count.toString());
    return 0;
end`,
                cpp: `#include <iostream>

bool is_prime(int n) {
    if (n <= 1)
        return false;
    if (n <= 3)
        return true;
    if (n % 2 == 0 || n % 3 == 0)
        return false;
    
    for (int i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    }
    
    return true;
}

int main() {
    const int limit = 1000;
    int count = 0;
    
    for (int i = 2; i <= limit; i++) {
        if (is_prime(i)) {
            count++;
            std::cout << i << " ";
            
            if (count % 10 == 0)
                std::cout << std::endl;
        }
    }
    
    std::cout << "\n素数の総数: " << count << std::endl;
    return 0;
}`,
                python: `def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    
    return True

limit = 1000
count = 0

for i in range(2, limit + 1):
    if is_prime(i):
        count += 1
        print(i, end=" ")
        
        if count % 10 == 0:
            print()

print(f"\n素数の総数: {count}")`,
                swift: `func isPrime(_ n: Int) -> Bool {
    if n <= 1 {
        return false
    }
    if n <= 3 {
        return true
    }
    if n % 2 == 0 || n % 3 == 0 {
        return false
    }
    
    var i = 5
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false
        }
        i += 6
    }
    
    return true
}

let limit = 1000
var count = 0

for i in 2...limit {
    if isPrime(i) {
        count += 1
        print("\\(i) ", terminator: "")
        
        if count % 10 == 0 {
            print("")
        }
    }
}

print("\\n素数の総数: \\(count)")`,
                javascript: `function isPrime(n) {
    if (n <= 1)
        return false;
    if (n <= 3)
        return true;
    if (n % 2 === 0 || n % 3 === 0)
        return false;
    
    let i = 5;
    while (i * i <= n) {
        if (n % i === 0 || n % (i + 2) === 0)
            return false;
        i += 6;
    }
    
    return true;
}

const limit = 1000;
let count = 0;
let output = "";

for (let i = 2; i <= limit; i++) {
    if (isPrime(i)) {
        count++;
        output += i + " ";
        
        if (count % 10 === 0)
            output += "\\n";
    }
}

console.log(output);
console.log("\\n素数の総数: " + count);`
            },
            'nc-keyword': {
                opal: `// NCキーワードを使用した最適化例
function calculate_sum(arr: Array<Integer>) -> Integer then
    nc sum <- 0;
    
    // NCキーワードを使用したループ最適化
    nc for i in 0..arr.size() {
        sum <- sum + arr[i];
    }
    
    return sum;
end

function first() -> Integer then
    // 大きな配列を生成
    nc size <- 10000000;
    nc arr <- Array<Integer>.new(size);
    
    for nc i <- 0; i < size; i <- i + 1 then
        arr[i] <- i;
    end
    
    // 時間計測開始
    nc start_time <- System.current_time_millis();
    
    // 合計を計算
    nc sum <- calculate_sum(arr);
    
    // 時間計測終了
    nc end_time <- System.current_time_millis();
    nc elapsed <- end_time - start_time;
    
    println("合計: " + sum.toString());
    println("実行時間: " + elapsed.toString() + "ミリ秒");
    
    return 0;
end`,
                cpp: `#include <iostream>
#include <vector>
#include <chrono>

int calculate_sum(const std::vector<int>& arr) {
    int sum = 0;
    
    // 通常のループ
    for (int i = 0; i < arr.size(); i++) {
        sum += arr[i];
    }
    
    return sum;
}

int main() {
    // 大きな配列を生成
    const int size = 10000000;
    std::vector<int> arr(size);
    
    for (int i = 0; i < size; i++) {
        arr[i] = i;
    }
    
    // 時間計測開始
    auto start_time = std::chrono::high_resolution_clock::now();
    
    // 合計を計算
    int sum = calculate_sum(arr);
    
    // 時間計測終了
    auto end_time = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
    
    std::cout << "合計: " << sum << std::endl;
    std::cout << "実行時間: " << elapsed << "ミリ秒" << std::endl;
    
    return 0;
}`,
                python: `import time

def calculate_sum(arr):
    sum = 0
    
    # 通常のループ
    for i in range(len(arr)):
        sum += arr[i]
    
    return sum

# 大きな配列を生成
size = 10000000
arr = list(range(size))

# 時間計測開始
start_time = time.time() * 1000

# 合計を計算
sum = calculate_sum(arr)

# 時間計測終了
end_time = time.time() * 1000
elapsed = end_time - start_time

print(f"合計: {sum}")
print(f"実行時間: {elapsed:.2f}ミリ秒")`,
                swift: `import Foundation

func calculateSum(_ arr: [Int]) -> Int {
    var sum = 0
    
    // 通常のループ
    for i in 0..<arr.count {
        sum += arr[i]
    }
    
    return sum
}

// 大きな配列を生成
let size = 10000000
var arr = [Int](repeating: 0, count: size)

for i in 0..<size {
    arr[i] = i
}

// 時間計測開始
let startTime = Date().timeIntervalSince1970 * 1000

// 合計を計算
let sum = calculateSum(arr)

// 時間計測終了
let endTime = Date().timeIntervalSince1970 * 1000
let elapsed = endTime - startTime

print("合計: \\(sum)")
print("実行時間: \\(elapsed)ミリ秒")`,
                javascript: `function calculateSum(arr) {
    let sum = 0;
    
    // 通常のループ
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    
    return sum;
}

// 大きな配列を生成
const size = 10000000;
const arr = Array(size);

for (let i = 0; i < size; i++) {
    arr[i] = i;
}

// 時間計測開始
const startTime = performance.now();

// 合計を計算
const sum = calculateSum(arr);

// 時間計測終了
const endTime = performance.now();
const elapsed = endTime - startTime;

console.log("合計: " + sum);
console.log("実行時間: " + elapsed + "ミリ秒");`
            },
            'nc-keyword-edge': {
                opal: `// NCキーワードのエッジケース最適化
function matrix_multiply(a: Array<Array<Float>>, b: Array<Array<Float>>) -> Array<Array<Float>> then
    nc rows_a <- a.size();
    nc cols_a <- a[0].size();
    nc cols_b <- b[0].size();
    
    nc result <- Array<Array<Float>>.new(rows_a);
    
    for nc i <- 0; i < rows_a; i <- i + 1 then
        result[i] <- Array<Float>.new(cols_b);
        
        // NCキーワードを使用したネストループの最適化
        nc for j in 0..cols_b {
            nc sum <- 0.0;
            
            nc for k in 0..cols_a {
                sum <- sum + a[i][k] * b[k][j];
            }
            
            result[i][j] <- sum;
        }
    end
    
    return result;
end

function first() -> Integer then
    // テスト行列の作成
    nc size <- 200;
    nc matrix_a <- Array<Array<Float>>.new(size);
    nc matrix_b <- Array<Array<Float>>.new(size);
    
    for nc i <- 0; i < size; i <- i + 1 then
        matrix_a[i] <- Array<Float>.new(size);
        matrix_b[i] <- Array<Float>.new(size);
        
        for nc j <- 0; j < size; j <- j + 1 then
            matrix_a[i][j] <- i + j * 0.1;
            matrix_b[i][j] <- i * 0.1 + j;
        end
    end
    
    // 時間計測開始
    nc start_time <- System.current_time_millis();
    
    // 行列乗算
    nc result <- matrix_multiply(matrix_a, matrix_b);
    
    // 時間計測終了
    nc end_time <- System.current_time_millis();
    nc elapsed <- end_time - start_time;
    
    println("行列サイズ: " + size.toString() + "x" + size.toString());
    println("実行時間: " + elapsed.toString() + "ミリ秒");
    
    // 結果の一部を表示
    println("結果の一部:");
    for nc i <- 0; i < 3; i <- i + 1 then
        for nc j <- 0; j < 3; j <- j + 1 then
            print(result[i][j].toString() + " ");
        end
        println("");
    end
    
    return 0;
end`,
                cpp: `#include <iostream>
#include <vector>
#include <chrono>
#include <iomanip>

std::vector<std::vector<double>> matrix_multiply(const std::vector<std::vector<double>>& a, const std::vector<std::vector<double>>& b) {
    int rows_a = a.size();
    int cols_a = a[0].size();
    int cols_b = b[0].size();
    
    std::vector<std::vector<double>> result(rows_a, std::vector<double>(cols_b, 0.0));
    
    for (int i = 0; i < rows_a; i++) {
        for (int j = 0; j < cols_b; j++) {
            double sum = 0.0;
            
            for (int k = 0; k < cols_a; k++) {
                sum += a[i][k] * b[k][j];
            }
            
            result[i][j] = sum;
        }
    }
    
    return result;
}

int main() {
    // テスト行列の作成
    const int size = 200;
    std::vector<std::vector<double>> matrix_a(size, std::vector<double>(size));
    std::vector<std::vector<double>> matrix_b(size, std::vector<double>(size));
    
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            matrix_a[i][j] = i + j * 0.1;
            matrix_b[i][j] = i * 0.1 + j;
        }
    }
    
    // 時間計測開始
    auto start_time = std::chrono::high_resolution_clock::now();
    
    // 行列乗算
    auto result = matrix_multiply(matrix_a, matrix_b);
    
    // 時間計測終了
    auto end_time = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
    
    std::cout << "行列サイズ: " << size << "x" << size << std::endl;
    std::cout << "実行時間: " << elapsed << "ミリ秒" << std::endl;
    
    // 結果の一部を表示
    std::cout << "結果の一部:" << std::endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            std::cout << std::fixed << std::setprecision(2) << result[i][j] << " ";
        }
        std::cout << std::endl;
    }
    
    return 0;
}`,
                python: `import time
import numpy as np

def matrix_multiply(a, b):
    rows_a = len(a)
    cols_a = len(a[0])
    cols_b = len(b[0])
    
    result = [[0.0 for _ in range(cols_b)] for _ in range(rows_a)]
    
    for i in range(rows_a):
        for j in range(cols_b):
            sum = 0.0
            
            for k in range(cols_a):
                sum += a[i][k] * b[k][j]
            
            result[i][j] = sum
    
    return result

# テスト行列の作成
size = 200
matrix_a = [[i + j * 0.1 for j in range(size)] for i in range(size)]
matrix_b = [[i * 0.1 + j for j in range(size)] for i in range(size)]

# 時間計測開始
start_time = time.time()

# 行列乗算
result = matrix_multiply(matrix_a, matrix_b)

# 時間計測終了
end_time = time.time()
elapsed = (end_time - start_time) * 1000

print(f"行列サイズ: {size}x{size}")
print(f"実行時間: {elapsed:.2f}ミリ秒")

# 結果の一部を表示
print("結果の一部:")
for i in range(3):
    for j in range(3):
        print(f"{result[i][j]:.2f} ", end="")
    print()`,
                swift: `import Foundation

func matrixMultiply(_ a: [[Double]], _ b: [[Double]]) -> [[Double]] {
    let rowsA = a.count
    let colsA = a[0].count
    let colsB = b[0].count
    
    var result = Array(repeating: Array(repeating: 0.0, count: colsB), count: rowsA)
    
    for i in 0..<rowsA {
        for j in 0..<colsB {
            var sum = 0.0
            
            for k in 0..<colsA {
                sum += a[i][k] * b[k][j]
            }
            
            result[i][j] = sum
        }
    }
    
    return result
}

// テスト行列の作成
let size = 200
var matrixA = Array(repeating: Array(repeating: 0.0, count: size), count: size)
var matrixB = Array(repeating: Array(repeating: 0.0, count: size), count: size)

for i in 0..<size {
    for j in 0..<size {
        matrixA[i][j] = Double(i) + Double(j) * 0.1
        matrixB[i][j] = Double(i) * 0.1 + Double(j)
    }
}

// 時間計測開始
let startTime = Date().timeIntervalSince1970

// 行列乗算
let result = matrixMultiply(matrixA, matrixB)

// 時間計測終了
let endTime = Date().timeIntervalSince1970
let elapsed = (endTime - startTime) * 1000

print("行列サイズ: \\(size)x\\(size)")
print("実行時間: \\(elapsed)ミリ秒")

// 結果の一部を表示
print("結果の一部:")
for i in 0..<3 {
    for j in 0..<3 {
        print("\\(String(format: "%.2f", result[i][j])) ", terminator: "")
    }
    print("")
}`,
                javascript: `function matrixMultiply(a, b) {
    const rowsA = a.length;
    const colsA = a[0].length;
    const colsB = b[0].length;
    
    const result = Array(rowsA).fill().map(() => Array(colsB).fill(0));
    
    for (let i = 0; i < rowsA; i++) {
        for (let j = 0; j < colsB; j++) {
            let sum = 0;
            
            for (let k = 0; k < colsA; k++) {
                sum += a[i][k] * b[k][j];
            }
            
            result[i][j] = sum;
        }
    }
    
    return result;
}

// テスト行列の作成
const size = 200;
const matrixA = Array(size).fill().map((_, i) => 
    Array(size).fill().map((_, j) => i + j * 0.1)
);
const matrixB = Array(size).fill().map((_, i) => 
    Array(size).fill().map((_, j) => i * 0.1 + j)
);

// 時間計測開始
const startTime = performance.now();

// 行列乗算
const result = matrixMultiply(matrixA, matrixB);

// 時間計測終了
const endTime = performance.now();
const elapsed = endTime - startTime;

console.log(`行列サイズ: ${size}x${size}`);
console.log(`実行時間: ${elapsed}ミリ秒`);

// 結果の一部を表示
console.log("結果の一部:");
for (let i = 0; i < 3; i++) {
    let row = "";
    for (let j = 0; j < 3; j++) {
        row += result[i][j].toFixed(2) + " ";
    }
    console.log(row);
}`
            }
        };
        
        if (sample in sampleCodes) {
            opalEditor.setValue(sampleCodes[sample].opal);
            cppEditor.setValue(sampleCodes[sample].cpp);
            pythonEditor.setValue(sampleCodes[sample].python);
            swiftEditor.setValue(sampleCodes[sample].swift);
            jsEditor.setValue(sampleCodes[sample].javascript);
        } else {
            clearAllEditors();
        }
    }
    
    // サンプルコードの説明を更新する関数
    function updateSampleDescription(sample) {
        let description = '';
        
        switch(sample) {
            case 'fibonacci':
                description = '<h5>フィボナッチ数列</h5><p>フィボナッチ数列を計算する再帰関数の実装です。このサンプルは再帰呼び出しのパフォーマンスをテストします。</p><p>各言語の実装を比較して、再帰処理の効率性を確認できます。</p>';
                break;
            case 'quicksort':
                description = '<h5>クイックソート</h5><p>クイックソートアルゴリズムの実装です。このサンプルは配列操作と再帰的なアルゴリズムの性能をテストします。</p><p>各言語でのパーティショニングと再帰呼び出しの効率を比較できます。</p>';
                break;
            case 'prime':
                description = '<h5>素数計算</h5><p>指定された範囲内の素数を計算するプログラムです。このサンプルは整数演算と条件分岐の性能をテストします。</p><p>各言語での数値計算の効率性を比較できます。</p>';
                break;
            case 'nc-keyword':
                description = '<h5>NCキーワード最適化</h5><p>Opal言語のNCキーワードを使用した最適化の例です。大きな配列の合計を計算する処理を最適化します。</p><p>NCキーワードを使用したOpal言語と他の言語の実装を比較して、最適化の効果を確認できます。</p>';
                break;
            case 'nc-keyword-edge':
                description = '<h5>NCキーワードエッジケース</h5><p>Opal言語のNCキーワードをネストしたループで使用した最適化の例です。行列乗算のような計算集約型の処理を最適化します。</p><p>複雑なアルゴリズムでのNCキーワードの効果を確認できます。</p>';
                break;
            default:
                description = '<p>サンプルコードを選択すると、ここに説明が表示されます。</p><p>各言語のタブでコードを確認し、必要に応じて編集できます。</p>';
        }
        
        sampleCodeDescription.innerHTML = description;
    }
    
    // すべてのエディタをクリアする関数
    function clearAllEditors() {
        opalEditor.setValue('');
        cppEditor.setValue('');
        pythonEditor.setValue('');
        swiftEditor.setValue('');
        jsEditor.setValue('');
        
        // サンプルコード選択をリセット
        if (sampleCodeSelect) {
            sampleCodeSelect.value = '';
        }
        
        // 説明をリセット
        if (sampleCodeDescription) {
            sampleCodeDescription.innerHTML = '<p>サンプルコードを選択すると、ここに説明が表示されます。</p><p>各言語のタブでコードを確認し、必要に応じて編集できます。</p>';
        }
    }
    
    // カスタムベンチマークを実行する関数
    function runCustomBenchmark() {
        // 実際のアプリケーションではサーバーサイドでコードを実行しますが、
        // ここではUIの動作をシミュレートします
        
        // 結果エリアを表示
        customResultsArea.style.display = 'block';
        
        // 実行するかどうかをチェック
        const runAll = document.getElementById('run-all-languages').checked;
        
        // 結果テーブルを更新
        const resultsTableBody = document.getElementById('custom-results-table-body');
        resultsTableBody.innerHTML = '';
        
        // サンプルデータ（実際のアプリケーションではサーバーからのレスポンスを使用）
        const sampleResults = {
            'opal': { time: 0.85, memory: 18.2, cpu: 0.82, lines: opalEditor.getValue().split('\n').length },
            'cpp': { time: 0.65, memory: 15.7, cpu: 0.63, lines: cppEditor.getValue().split('\n').length },
            'python': { time: 4.25, memory: 28.3, cpu: 4.20, lines: pythonEditor.getValue().split('\n').length },
            'swift': { time: 1.75, memory: 22.5, cpu: 1.72, lines: swiftEditor.getValue().split('\n').length },
            'javascript': { time: 3.45, memory: 26.8, cpu: 3.40, lines: jsEditor.getValue().split('\n').length }
        };
        
        // 言語リスト
        const languages = ['opal', 'cpp', 'python', 'swift', 'javascript'];
        const languageNames = {
            'opal': 'Opal',
            'cpp': 'C++',
            'python': 'Python',
            'swift': 'Swift',
            'javascript': 'JavaScript'
        };
        
        // 実行する言語を決定
        const languagesToRun = runAll ? languages : ['opal'];
        
        // 選択された言語の結果を表示
        languagesToRun.forEach(lang => {
            const result = sampleResults[lang];
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${languageNames[lang]}</td>
                <td>${result.time}</td>
                <td>${result.memory}</td>
                <td>${result.cpu}</td>
                <td>${result.lines}</td>
            `;
            
            resultsTableBody.appendChild(row);
        });
        
        // グラフを描画
        drawCustomCharts(languagesToRun, sampleResults);
        
        // 出力を表示
        updateOutputs(languagesToRun);
        
        // 共有URLを更新
        document.getElementById('custom-share-url').value = `https://mymkyoko.manus.space/custom_benchmark.html?run=${languagesToRun.join(',')}`;
    }
    
    // グラフを描画する関数
    function drawCustomCharts(languages, results) {
        // 実行時間グラフ
        const timeCtx = document.getElementById('custom-execution-time-chart').getContext('2d');
        const timeData = languages.map(lang => results[lang].time);
        const timeColors = languages.map(lang => getColorForLanguage(lang));
        const timeLabels = languages.map(lang => lang.charAt(0).toUpperCase() + lang.slice(1));
        
        new Chart(timeCtx, {
            type: 'bar',
            data: {
                labels: timeLabels,
                datasets: [{
                    label: '実行時間 (秒)',
                    data: timeData,
                    backgroundColor: timeColors,
                    borderColor: timeColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // メモリ使用量グラフ
        const memoryCtx = document.getElementById('custom-memory-usage-chart').getContext('2d');
        const memoryData = languages.map(lang => results[lang].memory);
        
        new Chart(memoryCtx, {
            type: 'bar',
            data: {
                labels: timeLabels,
                datasets: [{
                    label: 'メモリ使用量 (MB)',
                    data: memoryData,
                    backgroundColor: timeColors,
                    borderColor: timeColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // 出力を更新する関数
    function updateOutputs(languages) {
        // サンプル出力（実際のアプリケーションではサーバーからのレスポンスを使用）
        const sampleOutputs = {
            'opal': "Opal言語での実行結果...\n計算が完了しました。",
            'cpp': "C++での実行結果...\n計算が完了しました。",
            'python': "Pythonでの実行結果...\n計算が完了しました。",
            'swift': "Swiftでの実行結果...\n計算が完了しました。",
            'javascript': "JavaScriptでの実行結果...\n計算が完了しました。"
        };
        
        // 各言語の出力を更新
        languages.forEach(lang => {
            const outputElement = document.getElementById(`${lang}-output-content`);
            if (outputElement) {
                outputElement.textContent = sampleOutputs[lang];
            }
        });
    }
    
    // 言語ごとの色を取得する関数
    function getColorForLanguage(lang) {
        const colors = {
            'opal': 'rgba(0, 102, 255, 0.7)',
            'cpp': 'rgba(0, 153, 51, 0.7)',
            'python': 'rgba(255, 204, 0, 0.7)',
            'swift': 'rgba(255, 102, 0, 0.7)',
            'javascript': 'rgba(153, 51, 255, 0.7)'
        };
        
        return colors[lang] || 'rgba(128, 128, 128, 0.7)';
    }
    
    // コピーボタンのイベント
    const customCopyUrlBtn = document.getElementById('custom-copy-url-btn');
    if (customCopyUrlBtn) {
        customCopyUrlBtn.addEventListener('click', function() {
            const shareUrl = document.getElementById('custom-share-url');
            shareUrl.select();
            document.execCommand('copy');
            
            // コピー成功メッセージ
            this.innerHTML = '<i class="bi bi-check"></i> コピー完了';
            setTimeout(() => {
                this.innerHTML = '<i class="bi bi-clipboard"></i> コピー';
            }, 2000);
        });
    }
    
    // ダウンロードボタンのイベント
    const customDownloadResultsBtn = document.getElementById('custom-download-results-btn');
    if (customDownloadResultsBtn) {
        customDownloadResultsBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーからファイルをダウンロードします
            alert('結果をCSVファイルとしてダウンロードします。');
        });
    }
    
    // 保存ボタンのイベント
    const customSaveResultsBtn = document.getElementById('custom-save-results-btn');
    if (customSaveResultsBtn) {
        customSaveResultsBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーに結果を保存します
            alert('結果をサーバーに保存しました。');
        });
    }
});
