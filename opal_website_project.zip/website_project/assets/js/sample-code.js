// サンプルコードのJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // サンプルコードタブの切り替え
    const sampleCodeTabs = document.querySelectorAll('.sample-code-tab');
    if (sampleCodeTabs.length > 0) {
        sampleCodeTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                // アクティブなタブを更新
                document.querySelectorAll('.sample-code-tab').forEach(t => {
                    t.classList.remove('active');
                });
                this.classList.add('active');
                
                // 対応するコードを表示
                const targetId = this.getAttribute('data-target');
                document.querySelectorAll('.sample-code-content').forEach(content => {
                    content.style.display = 'none';
                });
                document.getElementById(targetId).style.display = 'block';
                
                // シンタックスハイライトを再適用
                if (Prism) {
                    Prism.highlightAll();
                }
            });
        });
    }
    
    // コピーボタンの機能
    const copyButtons = document.querySelectorAll('.copy-code-btn');
    if (copyButtons.length > 0) {
        copyButtons.forEach(button => {
            button.addEventListener('click', function() {
                const codeElement = this.closest('.code-container').querySelector('code');
                const textArea = document.createElement('textarea');
                textArea.value = codeElement.textContent;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                
                // コピー成功メッセージ
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i> コピー完了';
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 2000);
            });
        });
    }
    
    // ダウンロードボタンの機能
    const downloadButtons = document.querySelectorAll('.download-code-btn');
    if (downloadButtons.length > 0) {
        downloadButtons.forEach(button => {
            button.addEventListener('click', function() {
                const codeElement = this.closest('.code-container').querySelector('code');
                const codeText = codeElement.textContent;
                const fileName = this.getAttribute('data-filename') || 'sample_code.opal';
                
                const blob = new Blob([codeText], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                
                const a = document.createElement('a');
                a.href = url;
                a.download = fileName;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            });
        });
    }
    
    // 実行ボタンの機能（デモ用）
    const runButtons = document.querySelectorAll('.run-code-btn');
    if (runButtons.length > 0) {
        runButtons.forEach(button => {
            button.addEventListener('click', function() {
                const codeElement = this.closest('.code-container').querySelector('code');
                const outputElement = this.closest('.code-container').querySelector('.code-output');
                
                if (outputElement) {
                    // 実際のアプリケーションではサーバーサイドでコードを実行します
                    // ここではデモ出力を表示
                    outputElement.style.display = 'block';
                    outputElement.innerHTML = '<div class="alert alert-info">' +
                        '<i class="bi bi-info-circle me-2"></i>' +
                        'Opalコードの実行結果がここに表示されます。実際の環境ではサーバーサイドでコードが実行されます。' +
                        '</div>';
                    
                    // コードの種類に基づいてデモ出力を追加
                    const codeType = codeElement.getAttribute('data-code-type');
                    if (codeType === 'hello-world') {
                        outputElement.innerHTML += '<pre>Hello, World!</pre>';
                    } else if (codeType === 'fibonacci') {
                        outputElement.innerHTML += '<pre>0\n1\n1\n2\n3\n5\n8\n13\n21\n34</pre>';
                    } else if (codeType === 'quicksort') {
                        outputElement.innerHTML += '<pre>1 2 3 4 5 6 7 8 9 10</pre>';
                    } else if (codeType === 'nc-keyword') {
                        outputElement.innerHTML += '<pre>合計: 49999995000000\n実行時間: 127ミリ秒</pre>';
                    }
                }
            });
        });
    }
});
