#!/bin/bash
# Opal言語自己ホスティング実装のインストールスクリプト

# 色の定義
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ヘッダーを表示
echo -e "${BLUE}=================================================${NC}"
echo -e "${BLUE}    Opal言語自己ホスティング実装インストーラー    ${NC}"
echo -e "${BLUE}=================================================${NC}"
echo ""

# 必要なディレクトリを作成
echo -e "${YELLOW}必要なディレクトリを作成しています...${NC}"
mkdir -p /usr/local/opal/bin
mkdir -p /usr/local/opal/lib
mkdir -p /usr/local/opal/include
mkdir -p /usr/local/opal/examples
mkdir -p /usr/local/opal/docs

# 実行ファイルをコピー
echo -e "${YELLOW}実行ファイルをインストールしています...${NC}"
cp -f bin/opal /usr/local/opal/bin/
cp -f bin/opalc /usr/local/opal/bin/
cp -f bin/opal_ide /usr/local/opal/bin/
cp -f bin/opal_playground /usr/local/opal/bin/
cp -f bin/opal_pm /usr/local/opal/bin/

# ライブラリをコピー
echo -e "${YELLOW}ライブラリをインストールしています...${NC}"
cp -rf lib/* /usr/local/opal/lib/

# インクルードファイルをコピー
echo -e "${YELLOW}インクルードファイルをインストールしています...${NC}"
cp -rf include/* /usr/local/opal/include/

# サンプルをコピー
echo -e "${YELLOW}サンプルプログラムをインストールしています...${NC}"
cp -rf examples/* /usr/local/opal/examples/

# ドキュメントをコピー
echo -e "${YELLOW}ドキュメントをインストールしています...${NC}"
cp -rf docs/* /usr/local/opal/docs/

# シンボリックリンクを作成
echo -e "${YELLOW}シンボリックリンクを作成しています...${NC}"
ln -sf /usr/local/opal/bin/opal /usr/local/bin/opal
ln -sf /usr/local/opal/bin/opalc /usr/local/bin/opalc
ln -sf /usr/local/opal/bin/opal_ide /usr/local/bin/opal_ide
ln -sf /usr/local/opal/bin/opal_playground /usr/local/bin/opal_playground
ln -sf /usr/local/opal/bin/opal_pm /usr/local/bin/opal_pm

# 実行権限を設定
echo -e "${YELLOW}実行権限を設定しています...${NC}"
chmod +x /usr/local/opal/bin/opal
chmod +x /usr/local/opal/bin/opalc
chmod +x /usr/local/opal/bin/opal_ide
chmod +x /usr/local/opal/bin/opal_playground
chmod +x /usr/local/opal/bin/opal_pm

# 環境変数を設定
echo -e "${YELLOW}環境変数を設定しています...${NC}"
echo 'export OPAL_HOME=/usr/local/opal' > /etc/profile.d/opal.sh
echo 'export PATH=$PATH:$OPAL_HOME/bin' >> /etc/profile.d/opal.sh
chmod +x /etc/profile.d/opal.sh

# インストール完了メッセージ
echo ""
echo -e "${GREEN}=================================================${NC}"
echo -e "${GREEN}    Opal言語のインストールが完了しました！    ${NC}"
echo -e "${GREEN}=================================================${NC}"
echo ""
echo -e "インストール先: ${BLUE}/usr/local/opal${NC}"
echo -e "実行ファイル: ${BLUE}/usr/local/bin/opal, opalc, opal_ide, opal_playground, opal_pm${NC}"
echo ""
echo -e "${YELLOW}使用方法:${NC}"
echo -e "  ${BLUE}opal${NC} [ファイル名]     - Opalスクリプトを実行"
echo -e "  ${BLUE}opalc${NC} [ファイル名]    - Opalソースをコンパイル"
echo -e "  ${BLUE}opal_ide${NC}             - Opal統合開発環境を起動"
echo -e "  ${BLUE}opal_playground${NC}      - Opalプレイグラウンドを起動"
echo -e "  ${BLUE}opal_pm${NC} [コマンド]    - Opalパッケージマネージャ"
echo ""
echo -e "${YELLOW}サンプルプログラム:${NC}"
echo -e "  ${BLUE}/usr/local/opal/examples/${NC} ディレクトリにサンプルがあります"
echo ""
echo -e "${YELLOW}ドキュメント:${NC}"
echo -e "  ${BLUE}/usr/local/opal/docs/${NC} ディレクトリにドキュメントがあります"
echo ""
echo -e "${YELLOW}環境を更新するには、次のコマンドを実行するか、ターミナルを再起動してください:${NC}"
echo -e "  ${BLUE}source /etc/profile.d/opal.sh${NC}"
echo ""
