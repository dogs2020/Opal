# Opal言語の「nc」キーワードの意味と使用法

## 概要

Opal言語では、変数宣言に「nc」キーワードを使用します。これは「not changeable」（変更不可）の略であり、定数宣言のためのキーワードです。このドキュメントでは、「nc」キーワードの意味と正しい使用法について説明します。

## 「nc」キーワードの意味

「nc」（not changeable）は、値が変更できない変数、つまり定数を宣言するために使用されます。これは他の言語における「const」や「final」に相当するものです。

Opalの設計哲学では、デフォルトで変数は不変（immutable）であるべきという考え方があります。「nc」キーワードはこの哲学を反映しており、変数が一度初期化されると、その値は変更できないことを明示します。

## 基本的な使用法

### 型指定あり
```opal
nc x: Integer = 42;
nc PI: Float = 3.14159;
nc NAME: String = "Opal";
```

### 型推論あり
```opal
nc y <- 3.14;  // Float型と推論される
nc message <- "Hello, World!";  // String型と推論される
nc isValid <- true;  // Boolean型と推論される
```

## クラスフィールドでの使用

クラス内のフィールド宣言にも「nc」キーワードを使用します：

```opal
class Point then
    nc x: Integer;
    nc y: Integer;
    
    function init(x: Integer, y: Integer) then
        this.x <- x;
        this.y <- y;
    end
end
```

## 配列とコレクションの宣言

配列やその他のコレクション型の宣言にも「nc」キーワードを使用します：

```opal
nc numbers: Array<Integer> = [1, 2, 3, 4, 5];
nc nameMap: Map<String, String> = Map<String, String>.new();
```

## ループ変数での使用

forループの変数宣言にも「nc」キーワードを使用します：

```opal
for nc i <- 0; i < 10; i <- i + 1 then
    // ループ処理
end
```

## 関数内での使用

関数内のローカル変数宣言にも「nc」キーワードを使用します：

```opal
function calculate(a: Integer, b: Integer) -> Integer then
    nc result <- a + b;
    return result;
end
```

## 注意点

1. 「nc」で宣言された変数は、初期化後に値を変更することはできません。
2. すべての変数宣言には「nc」キーワードを使用する必要があります。
3. 「let」キーワードは古い構文であり、現在のOpal言語では使用されていません。

## まとめ

Opal言語では、変数宣言に「nc」（not changeable）キーワードを使用します。これは変数が不変であることを明示し、言語の設計哲学を反映しています。すべての変数宣言（グローバル変数、ローカル変数、クラスフィールド、ループ変数など）には「nc」キーワードを使用する必要があります。
