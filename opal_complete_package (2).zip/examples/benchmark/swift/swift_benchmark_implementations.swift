// swift_benchmark_implementations.swift
// Opal言語ベンチマークのSwift実装
// このファイルは、Opal言語のパフォーマンスをSwiftと比較するためのベンチマーク実装を提供します

import Foundation

// 整数演算ベンチマーク
func integerOperationsBenchmark() {
    var sum = 0
    for i in 0..<100000000 {
        sum = sum + i
        sum = sum - (i / 2)
        sum = sum * 2
        sum = sum / 2
        sum = sum % 1000000
    }
    print(sum) // 結果を出力して最適化を防止
}

// 浮動小数点演算ベンチマーク
func floatingPointOperationsBenchmark() {
    var sum = 0.0
    for i in 0..<10000000 {
        sum = sum + Double(i) * 0.5
        sum = sum - (Double(i) * 0.25)
        sum = sum * 1.01
        sum = sum / 1.01
        sum = sin(sum) + cos(sum)
        if sum > 1000000.0 {
            sum = sum.truncatingRemainder(dividingBy: 1000000.0)
        }
    }
    print(sum) // 結果を出力して最適化を防止
}

// 文字列操作ベンチマーク
func stringOperationsBenchmark() {
    var result = ""
    for i in 0..<100000 {
        result += String(i)
        if result.count > 1000000 {
            let startIndex = result.startIndex
            let endIndex = result.index(startIndex, offsetBy: 1000)
            result = String(result[startIndex..<endIndex])
        }
    }
    print(result.count) // 結果を出力して最適化を防止
}

// 配列操作ベンチマーク
func arrayOperationsBenchmark() {
    var array = [Int]()
    for i in 0..<1000000 {
        array.append(i)
    }
    
    var sum = 0
    for i in 0..<array.count {
        sum += array[i]
    }
    
    for _ in 0..<1000 {
        array.sort()
        array.reverse()
    }
    
    print(sum) // 結果を出力して最適化を防止
}

// アルゴリズムベンチマーク
func algorithmsBenchmark() {
    // クイックソート
    var array = [Double]()
    for _ in 0..<100000 {
        array.append(Double.random(in: 0..<1000000))
    }
    
    quickSort(&array, low: 0, high: array.count - 1)
    
    // フィボナッチ数列
    let fib = fibonacci(40)
    
    // 素数判定
    var primeCount = 0
    for i in 2..<100000 {
        if isPrime(i) {
            primeCount += 1
        }
    }
    
    print("Sorted array first element: \(array[0]), Fibonacci: \(fib), Prime count: \(primeCount)")
}

// クイックソート実装
func quickSort(_ array: inout [Double], low: Int, high: Int) {
    if low < high {
        let pivotIndex = partition(&array, low: low, high: high)
        quickSort(&array, low: low, high: pivotIndex - 1)
        quickSort(&array, low: pivotIndex + 1, high: high)
    }
}

func partition(_ array: inout [Double], low: Int, high: Int) -> Int {
    let pivot = array[high]
    var i = low - 1
    
    for j in low..<high {
        if array[j] <= pivot {
            i += 1
            let temp = array[i]
            array[i] = array[j]
            array[j] = temp
        }
    }
    
    let temp = array[i + 1]
    array[i + 1] = array[high]
    array[high] = temp
    
    return i + 1
}

// フィボナッチ数列
func fibonacci(_ n: Int) -> Int {
    if n <= 1 {
        return n
    }
    return fibonacci(n - 1) + fibonacci(n - 2)
}

// 素数判定
func isPrime(_ n: Int) -> Bool {
    if n <= 1 {
        return false
    }
    
    if n <= 3 {
        return true
    }
    
    if n % 2 == 0 || n % 3 == 0 {
        return false
    }
    
    var i = 5
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false
        }
        i += 6
    }
    
    return true
}

// メモリ管理ベンチマーク
func memoryManagementBenchmark() {
    for _ in 0..<1000 {
        var objects = [[String: Any]]()
        for j in 0..<10000 {
            objects.append([
                "id": j,
                "name": "Object \(j)",
                "data": "Some data for object \(j)",
                "values": [j, j*2, j*3, j*4, j*5]
            ])
        }
        
        // オブジェクトにアクセスして使用
        var sum = 0
        for j in 0..<objects.count {
            sum += objects[j]["id"] as! Int
        }
        
        // 結果を出力して最適化を防止
        if sum % 1000000 == 0 {
            print(sum)
        }
    }
}

// 並行処理ベンチマーク
func concurrencyBenchmark() {
    let threadCount = 8
    var results = Array(repeating: 0, count: threadCount)
    var threads = [Thread]()
    
    for i in 0..<threadCount {
        let thread = Thread {
            var localSum = 0
            for j in 0..<10000000 {
                localSum += j
            }
            results[i] = localSum
        }
        threads.append(thread)
    }
    
    for i in 0..<threadCount {
        threads[i].start()
    }
    
    for i in 0..<threadCount {
        threads[i].join()
    }
    
    var totalSum = 0
    for i in 0..<threadCount {
        totalSum += results[i]
    }
    
    print(totalSum) // 結果を出力して最適化を防止
}

// メイン関数
func runBenchmark(_ benchmarkName: String) {
    let startTime = Date()
    let startMemory = getMemoryUsage()
    let startCPU = getCPUUsage()
    
    switch benchmarkName {
    case "integer_operations":
        integerOperationsBenchmark()
    case "floating_point_operations":
        floatingPointOperationsBenchmark()
    case "string_operations":
        stringOperationsBenchmark()
    case "array_operations":
        arrayOperationsBenchmark()
    case "algorithms":
        algorithmsBenchmark()
    case "memory_management":
        memoryManagementBenchmark()
    case "concurrency":
        concurrencyBenchmark()
    default:
        print("Unknown benchmark: \(benchmarkName)")
        exit(1)
    }
    
    let endTime = Date()
    let endMemory = getMemoryUsage()
    let endCPU = getCPUUsage()
    
    let executionTime = endTime.timeIntervalSince(startTime) * 1000 // ミリ秒に変換
    let memoryUsage = endMemory - startMemory
    let cpuUsage = endCPU - startCPU
    
    // 結果を出力（ベンチマークランナーが解析する形式）
    print("\(executionTime)")
    print("\(memoryUsage)")
    print("\(cpuUsage)")
}

// メモリ使用量を取得する関数
func getMemoryUsage() -> Int {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size)/4
    
    let kerr: kern_return_t = withUnsafeMutablePointer(to: &info) {
        $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    
    if kerr == KERN_SUCCESS {
        return Int(info.resident_size / 1024) // KBに変換
    } else {
        return 0
    }
}

// CPU使用率を取得する関数
func getCPUUsage() -> Double {
    var totalUsageOfCPU: Double = 0.0
    var threadsList = UnsafeMutablePointer<thread_act_t>.allocate(capacity: 1)
    var threadsCount = mach_msg_type_number_t(0)
    let threadsResult = task_threads(mach_task_self_, &threadsList, &threadsCount)
    
    if threadsResult == KERN_SUCCESS {
        for index in 0..<threadsCount {
            var threadInfo = thread_basic_info()
            var threadInfoCount = mach_msg_type_number_t(THREAD_INFO_MAX)
            let infoResult = withUnsafeMutablePointer(to: &threadInfo) {
                $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
                    thread_info(threadsList[Int(index)], thread_flavor_t(THREAD_BASIC_INFO), $0, &threadInfoCount)
                }
            }
            
            if infoResult == KERN_SUCCESS {
                let threadBasicInfo = threadInfo
                if threadBasicInfo.flags & TH_FLAGS_IDLE == 0 {
                    totalUsageOfCPU = (totalUsageOfCPU + (Double(threadBasicInfo.cpu_usage) / Double(TH_USAGE_SCALE) * 100.0))
                }
            }
        }
    }
    
    vm_deallocate(mach_task_self_, vm_address_t(threadsList.pointee), vm_size_t(threadsCount))
    return totalUsageOfCPU
}

// コマンドライン引数からベンチマーク名を取得して実行
if CommandLine.arguments.count > 1 {
    let benchmarkName = CommandLine.arguments[1]
    runBenchmark(benchmarkName)
} else {
    print("Usage: swift benchmark.swift <benchmark_name>")
    exit(1)
}
