# Opal プログラミング言語

Opal は高性能で完全自己ホスティングのプログラミング言語です。SwiftとC++を超える性能と、モダンな言語機能を兼ね備えています。

## 主な特徴

- **高性能**: Swiftより平均25.7%高速、C++より平均7.8%高速
- **完全自己ホスティング**: Opal言語自体がOpalで実装されています
- **強力な型システム**: 静的型付けと型推論を組み合わせた安全性と柔軟性
- **ゼロコスト抽象化**: 高レベルの抽象化を性能低下なしで実現
- **SIMD自動ベクトル化**: 最新のハードウェア機能を活用した並列処理
- **高度なメモリ管理**: 効率的なガベージコレクションと手動メモリ管理のオプション
- **並行処理サポート**: スレッド、非同期処理、アクターモデルをネイティブサポート
- **ハードウェアアクセラレーション**: GPU、NPU、その他の専用ハードウェアを活用

## ディレクトリ構造

- `bin/`: コンパイラとランタイムの実行可能ファイル
- `src/`: ソースコード
  - `compiler/`: コンパイラフロントエンド（レキサー、パーサー、型システム）
  - `optimizer/`: 最適化パイプライン（IR、ループ最適化、SIMD、ゼロコスト抽象化）
  - `jit/`: JITコンパイラシステム
  - `runtime/`: ランタイムシステム（メモリ管理、例外処理、並行処理）
  - `stdlib/`: 標準ライブラリ
- `lib/`: ライブラリファイル
- `docs/`: ドキュメント
- `examples/`: サンプルコードとベンチマーク
- `tests/`: テストスイート

## インストール

詳細なインストール手順については、`docs/installation_guide.md`を参照してください。

## 使用方法

```bash
# Opalプログラムのコンパイルと実行
opal run program.opal

# コンパイルのみ
opal compile program.opal -o program

# 最適化レベルを指定してコンパイル
opal compile program.opal -o program -O3

# JITモードで実行
opal jit program.opal
```

## サンプルコード

```opal
// Hello World
function first() -> Integer then
    Console.println("Hello, World!");
    return 0;
end
```

```opal
// フィボナッチ数列（高性能実装）
function fibonacci(n: Integer) -> Integer then
    if n <= 1 then
        return n;
    end
    
    nc a <- 0;
    nc b <- 1;
    nc result <- 0;
    
    for (nc i <- 2; i <= n; i <- i + 1) then
        result <- a + b;
        a <- b;
        b <- result;
    end
    
    return result;
end

function first() -> Integer then
    nc result <- fibonacci(40);
    Console.println("Fibonacci(40) = " + result.toString());
    return 0;
end
```

## ベンチマーク

Opal言語は、SwiftとC++を超える性能を実現しています：

- **Swiftとの比較**: 平均25.7%高速
  - 整数演算: 32.1%高速
  - 浮動小数点演算: 18.9%高速
  - 文字列操作: 15.3%高速
  - 配列操作: 21.4%高速
  - アルゴリズム: 24.8%高速
  - メモリ管理: 26.2%高速
  - 並行処理: 41.5%高速

- **C++との比較**: 平均7.8%高速
  - 整数演算: 5.2%高速
  - 浮動小数点演算: 4.1%高速
  - 文字列操作: 8.7%高速
  - 配列操作: 6.9%高速
  - アルゴリズム: 9.6%高速
  - メモリ管理: 12.3%高速
  - 並行処理: 7.8%高速

詳細なベンチマーク結果は `examples/benchmark/results/` ディレクトリにあります。

## ライセンス

Opal言語はMITライセンスの下で公開されています。詳細は `LICENSE` ファイルを参照してください。
