// ベンチマークページのJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // ベンチマーク選択の変更イベント
    const benchmarkSelect = document.getElementById('benchmark-select');
    const benchmarkDescription = document.getElementById('benchmark-description');
    
    if (benchmarkSelect && benchmarkDescription) {
        benchmarkSelect.addEventListener('change', function() {
            const selectedBenchmark = this.value;
            updateBenchmarkDescription(selectedBenchmark);
        });
    }
    
    // ベンチマーク実行フォームの送信イベント
    const benchmarkForm = document.getElementById('benchmark-form');
    const resultsArea = document.getElementById('results-area');
    
    if (benchmarkForm && resultsArea) {
        benchmarkForm.addEventListener('submit', function(e) {
            e.preventDefault();
            runBenchmark();
        });
    }
    
    // ベンチマークの説明を更新する関数
    function updateBenchmarkDescription(benchmark) {
        let description = '';
        
        switch(benchmark) {
            case 'fannkuch-redux':
                description = '<h5>Fannkuch Redux</h5><p>配列の並べ替えと操作に焦点を当てたベンチマークです。特定の順列を生成し、「パンケーキソート」と呼ばれる操作を実行します。</p><p>このベンチマークはCPU性能とメモリアクセスパターンをテストします。</p>';
                break;
            case 'n-body':
                description = '<h5>N-Body</h5><p>太陽系の天体（太陽、木星、土星、天王星、海王星）の動きをシミュレーションするベンチマークです。</p><p>このベンチマークは浮動小数点演算と数値計算の性能をテストします。</p>';
                break;
            case 'binary-trees':
                description = '<h5>バイナリツリー</h5><p>再帰的なメモリ割り当てと解放を行うベンチマークです。二分木の作成、走査、削除を繰り返し実行します。</p><p>このベンチマークはメモリ管理とガベージコレクションの効率をテストします。</p>';
                break;
            case 'spectral-norm':
                description = '<h5>スペクトル正規化</h5><p>行列の最大固有値（スペクトル正規）を計算するベンチマークです。</p><p>このベンチマークは浮動小数点演算と行列計算の性能をテストします。</p>';
                break;
            case 'mandelbrot':
                description = '<h5>マンデルブロ集合</h5><p>マンデルブロ集合のフラクタル画像を生成するベンチマークです。</p><p>このベンチマークは複素数計算と条件分岐の性能をテストします。</p>';
                break;
            case 'regex-redux':
                description = '<h5>正規表現 Redux</h5><p>大きなテキストに対して複数の正規表現操作を実行するベンチマークです。</p><p>このベンチマークは文字列処理と正規表現エンジンの性能をテストします。</p>';
                break;
            case 'fasta':
                description = '<h5>FASTA</h5><p>FASTA形式のDNA配列を生成するベンチマークです。</p><p>このベンチマークは文字列生成と出力操作の性能をテストします。</p>';
                break;
            case 'k-nucleotide':
                description = '<h5>k-ヌクレオチド</h5><p>DNA配列内の特定のヌクレオチドパターンの出現頻度を数えるベンチマークです。</p><p>このベンチマークはハッシュテーブル操作と文字列処理の性能をテストします。</p>';
                break;
            default:
                description = '<p>左側のフォームからベンチマークテストを選択すると、ここに詳細な説明が表示されます。</p>';
        }
        
        benchmarkDescription.innerHTML = description;
    }
    
    // ベンチマークを実行する関数
    function runBenchmark() {
        // 実際のベンチマーク実行はサーバーサイドで行われますが、
        // ここではUIの動作をシミュレートします
        
        // 選択されたベンチマークと言語を取得
        const selectedBenchmark = benchmarkSelect.value;
        const selectedLanguages = [];
        
        document.querySelectorAll('input[type="checkbox"]:checked').forEach(checkbox => {
            selectedLanguages.push(checkbox.value);
        });
        
        // 結果エリアを表示
        resultsArea.style.display = 'block';
        
        // 結果テーブルを更新
        const resultsTableBody = document.getElementById('results-table-body');
        resultsTableBody.innerHTML = '';
        
        // サンプルデータ（実際のアプリケーションではサーバーからのレスポンスを使用）
        const sampleResults = {
            'opal': { time: 1.25, memory: 24.8, cpu: 1.22, lines: 120 },
            'cpp': { time: 0.98, memory: 22.3, cpu: 0.95, lines: 145 },
            'python': { time: 6.35, memory: 35.7, cpu: 6.30, lines: 85 },
            'swift': { time: 2.45, memory: 28.1, cpu: 2.40, lines: 110 },
            'javascript': { time: 4.75, memory: 32.5, cpu: 4.70, lines: 95 }
        };
        
        // 選択された言語の結果を表示
        selectedLanguages.forEach(lang => {
            const result = sampleResults[lang];
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${lang.charAt(0).toUpperCase() + lang.slice(1)}</td>
                <td>${result.time}</td>
                <td>${result.memory}</td>
                <td>${result.cpu}</td>
                <td>${result.lines}</td>
            `;
            
            resultsTableBody.appendChild(row);
        });
        
        // グラフを描画
        drawCharts(selectedLanguages, sampleResults);
        
        // 共有URLを更新
        document.getElementById('share-url').value = `https://mymkyoko.manus.space/benchmark.html?test=${selectedBenchmark}&langs=${selectedLanguages.join(',')}`;
    }
    
    // グラフを描画する関数
    function drawCharts(languages, results) {
        // 実行時間グラフ
        const timeCtx = document.getElementById('execution-time-chart').getContext('2d');
        const timeData = languages.map(lang => results[lang].time);
        const timeColors = languages.map(lang => getColorForLanguage(lang));
        
        new Chart(timeCtx, {
            type: 'bar',
            data: {
                labels: languages.map(lang => lang.charAt(0).toUpperCase() + lang.slice(1)),
                datasets: [{
                    label: '実行時間 (秒)',
                    data: timeData,
                    backgroundColor: timeColors,
                    borderColor: timeColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // メモリ使用量グラフ
        const memoryCtx = document.getElementById('memory-usage-chart').getContext('2d');
        const memoryData = languages.map(lang => results[lang].memory);
        
        new Chart(memoryCtx, {
            type: 'bar',
            data: {
                labels: languages.map(lang => lang.charAt(0).toUpperCase() + lang.slice(1)),
                datasets: [{
                    label: 'メモリ使用量 (MB)',
                    data: memoryData,
                    backgroundColor: timeColors,
                    borderColor: timeColors.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // 言語ごとの色を取得する関数
    function getColorForLanguage(lang) {
        const colors = {
            'opal': 'rgba(0, 102, 255, 0.7)',
            'cpp': 'rgba(0, 153, 51, 0.7)',
            'python': 'rgba(255, 204, 0, 0.7)',
            'swift': 'rgba(255, 102, 0, 0.7)',
            'javascript': 'rgba(153, 51, 255, 0.7)'
        };
        
        return colors[lang] || 'rgba(128, 128, 128, 0.7)';
    }
    
    // コピーボタンのイベント
    const copyUrlBtn = document.getElementById('copy-url-btn');
    if (copyUrlBtn) {
        copyUrlBtn.addEventListener('click', function() {
            const shareUrl = document.getElementById('share-url');
            shareUrl.select();
            document.execCommand('copy');
            
            // コピー成功メッセージ
            this.innerHTML = '<i class="bi bi-check"></i> コピー完了';
            setTimeout(() => {
                this.innerHTML = '<i class="bi bi-clipboard"></i> コピー';
            }, 2000);
        });
    }
    
    // ダウンロードボタンのイベント
    const downloadResultsBtn = document.getElementById('download-results-btn');
    if (downloadResultsBtn) {
        downloadResultsBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーからファイルをダウンロードします
            alert('結果をCSVファイルとしてダウンロードします。');
        });
    }
    
    // 保存ボタンのイベント
    const saveResultsBtn = document.getElementById('save-results-btn');
    if (saveResultsBtn) {
        saveResultsBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーに結果を保存します
            alert('結果をサーバーに保存しました。');
        });
    }
});
