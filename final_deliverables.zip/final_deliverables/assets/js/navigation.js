// ナビゲーションリンクの動作を確認するためのJavaScriptファイル
document.addEventListener('DOMContentLoaded', function() {
    // 現在のページのURLを取得
    const currentPath = window.location.pathname;
    
    // ナビゲーションリンクを取得
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    // 各リンクをチェックして、現在のページに対応するリンクにactiveクラスを追加
    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (currentPath.endsWith(linkPath)) {
            link.classList.add('active');
        } else if (currentPath.endsWith('/') && linkPath === 'index.html') {
            link.classList.add('active');
        }
    });
    
    // ドキュメントページのサイドバーナビゲーション
    const docLinks = document.querySelectorAll('.card .nav-link');
    docLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (currentPath.endsWith(linkPath)) {
            link.classList.add('active');
        }
    });
    
    // スムーズスクロール
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });
});
