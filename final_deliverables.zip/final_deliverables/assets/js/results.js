// 結果ページのJavaScript
document.addEventListener('DOMContentLoaded', function() {
    // 結果フィルターの変更イベント
    const resultFilterSelect = document.getElementById('result-filter');
    
    if (resultFilterSelect) {
        resultFilterSelect.addEventListener('change', function() {
            const selectedFilter = this.value;
            filterResults(selectedFilter);
        });
    }
    
    // 結果をフィルタリングする関数
    function filterResults(filter) {
        const resultItems = document.querySelectorAll('.result-item');
        
        resultItems.forEach(item => {
            if (filter === 'all') {
                item.style.display = 'block';
            } else {
                const itemCategory = item.getAttribute('data-category');
                item.style.display = (itemCategory === filter) ? 'block' : 'none';
            }
        });
    }
    
    // 結果の詳細を表示する関数
    const resultLinks = document.querySelectorAll('.result-link');
    
    resultLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const resultId = this.getAttribute('data-result-id');
            showResultDetail(resultId);
        });
    });
    
    // 結果の詳細を表示する関数
    function showResultDetail(resultId) {
        // 結果データ（実際のアプリケーションではサーバーからのデータを使用）
        const resultData = {
            'result1': {
                title: 'フィボナッチ数列ベンチマーク',
                date: '2025-03-15',
                languages: ['Opal', 'C++', 'Python', 'Swift', 'JavaScript'],
                description: 'フィボナッチ数列を計算する再帰関数のベンチマーク結果です。',
                executionTimes: [1.25, 0.98, 6.35, 2.45, 4.75],
                memoryUsage: [24.8, 22.3, 35.7, 28.1, 32.5],
                cpuUsage: [1.22, 0.95, 6.30, 2.40, 4.70],
                codeLines: [120, 145, 85, 110, 95]
            },
            'result2': {
                title: 'クイックソートベンチマーク',
                date: '2025-03-20',
                languages: ['Opal', 'C++', 'Python', 'Swift', 'JavaScript'],
                description: 'クイックソートアルゴリズムのベンチマーク結果です。',
                executionTimes: [0.85, 0.65, 4.25, 1.75, 3.45],
                memoryUsage: [18.2, 15.7, 28.3, 22.5, 26.8],
                cpuUsage: [0.82, 0.63, 4.20, 1.72, 3.40],
                codeLines: [95, 120, 70, 90, 80]
            },
            'result3': {
                title: '素数計算ベンチマーク',
                date: '2025-03-25',
                languages: ['Opal', 'C++', 'Python', 'Swift', 'JavaScript'],
                description: '1000までの素数を計算するベンチマーク結果です。',
                executionTimes: [0.45, 0.35, 2.85, 1.15, 2.25],
                memoryUsage: [12.5, 10.8, 22.6, 16.3, 20.4],
                cpuUsage: [0.42, 0.33, 2.80, 1.12, 2.20],
                codeLines: [65, 80, 45, 60, 55]
            },
            'result4': {
                title: 'NCキーワード最適化ベンチマーク',
                date: '2025-04-01',
                languages: ['Opal', 'C++', 'Python', 'Swift', 'JavaScript'],
                description: 'Opal言語のNCキーワードを使用した最適化のベンチマーク結果です。',
                executionTimes: [0.65, 0.75, 3.95, 1.55, 2.85],
                memoryUsage: [15.2, 16.7, 26.3, 19.5, 23.8],
                cpuUsage: [0.62, 0.73, 3.90, 1.52, 2.80],
                codeLines: [85, 95, 60, 75, 70]
            },
            'result5': {
                title: 'マンデルブロ集合ベンチマーク',
                date: '2025-04-05',
                languages: ['Opal', 'C++', 'Python', 'Swift', 'JavaScript'],
                description: 'マンデルブロ集合のフラクタル画像を生成するベンチマーク結果です。',
                executionTimes: [1.85, 1.45, 8.25, 3.75, 6.45],
                memoryUsage: [28.2, 25.7, 42.3, 32.5, 38.8],
                cpuUsage: [1.82, 1.43, 8.20, 3.72, 6.40],
                codeLines: [110, 130, 75, 100, 90]
            }
        };
        
        // 結果が存在するか確認
        if (!(resultId in resultData)) {
            alert('結果が見つかりません。');
            return;
        }
        
        const result = resultData[resultId];
        
        // 結果詳細エリアを表示
        const resultDetailArea = document.getElementById('result-detail-area');
        resultDetailArea.style.display = 'block';
        
        // 結果詳細を更新
        document.getElementById('result-detail-title').textContent = result.title;
        document.getElementById('result-detail-date').textContent = result.date;
        document.getElementById('result-detail-description').textContent = result.description;
        
        // 結果テーブルを更新
        const resultTableBody = document.getElementById('result-detail-table-body');
        resultTableBody.innerHTML = '';
        
        for (let i = 0; i < result.languages.length; i++) {
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${result.languages[i]}</td>
                <td>${result.executionTimes[i]}</td>
                <td>${result.memoryUsage[i]}</td>
                <td>${result.cpuUsage[i]}</td>
                <td>${result.codeLines[i]}</td>
            `;
            
            resultTableBody.appendChild(row);
        }
        
        // グラフを描画
        drawResultCharts(result);
        
        // 共有URLを更新
        document.getElementById('result-share-url').value = `https://mymkyoko.manus.space/results.html?id=${resultId}`;
    }
    
    // グラフを描画する関数
    function drawResultCharts(result) {
        // 言語ごとの色
        const colors = {
            'Opal': 'rgba(0, 102, 255, 0.7)',
            'C++': 'rgba(0, 153, 51, 0.7)',
            'Python': 'rgba(255, 204, 0, 0.7)',
            'Swift': 'rgba(255, 102, 0, 0.7)',
            'JavaScript': 'rgba(153, 51, 255, 0.7)'
        };
        
        const colorArray = result.languages.map(lang => colors[lang]);
        
        // 実行時間グラフ
        const timeCtx = document.getElementById('result-execution-time-chart').getContext('2d');
        
        new Chart(timeCtx, {
            type: 'bar',
            data: {
                labels: result.languages,
                datasets: [{
                    label: '実行時間 (秒)',
                    data: result.executionTimes,
                    backgroundColor: colorArray,
                    borderColor: colorArray.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // メモリ使用量グラフ
        const memoryCtx = document.getElementById('result-memory-usage-chart').getContext('2d');
        
        new Chart(memoryCtx, {
            type: 'bar',
            data: {
                labels: result.languages,
                datasets: [{
                    label: 'メモリ使用量 (MB)',
                    data: result.memoryUsage,
                    backgroundColor: colorArray,
                    borderColor: colorArray.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // CPU使用率グラフ
        const cpuCtx = document.getElementById('result-cpu-usage-chart').getContext('2d');
        
        new Chart(cpuCtx, {
            type: 'bar',
            data: {
                labels: result.languages,
                datasets: [{
                    label: 'CPU使用率',
                    data: result.cpuUsage,
                    backgroundColor: colorArray,
                    borderColor: colorArray.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // コード行数グラフ
        const linesCtx = document.getElementById('result-code-lines-chart').getContext('2d');
        
        new Chart(linesCtx, {
            type: 'bar',
            data: {
                labels: result.languages,
                datasets: [{
                    label: 'コード行数',
                    data: result.codeLines,
                    backgroundColor: colorArray,
                    borderColor: colorArray.map(color => color.replace('0.7', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // コピーボタンのイベント
    const resultCopyUrlBtn = document.getElementById('result-copy-url-btn');
    if (resultCopyUrlBtn) {
        resultCopyUrlBtn.addEventListener('click', function() {
            const shareUrl = document.getElementById('result-share-url');
            shareUrl.select();
            document.execCommand('copy');
            
            // コピー成功メッセージ
            this.innerHTML = '<i class="bi bi-check"></i> コピー完了';
            setTimeout(() => {
                this.innerHTML = '<i class="bi bi-clipboard"></i> コピー';
            }, 2000);
        });
    }
    
    // ダウンロードボタンのイベント
    const resultDownloadBtn = document.getElementById('result-download-btn');
    if (resultDownloadBtn) {
        resultDownloadBtn.addEventListener('click', function() {
            // 実際のアプリケーションではサーバーからファイルをダウンロードします
            alert('結果をCSVファイルとしてダウンロードします。');
        });
    }
    
    // URLパラメータから結果IDを取得して表示
    function getResultIdFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const resultId = urlParams.get('id');
        
        if (resultId) {
            showResultDetail(resultId);
        }
    }
    
    // ページ読み込み時にURLパラメータをチェック
    getResultIdFromUrl();
});
