# Opal深層学習ライブラリドキュメント

## 概要

Opal深層学習ライブラリは、Opal言語で実装された包括的な深層学習フレームワークです。このライブラリは、TensorFlow、PyTorch、JAXに相当する機能をOpal言語で提供し、ニューラルネットワークの構築、トレーニング、評価、デプロイを簡単に行うことができます。

## 主な機能

- **テンソル操作**: 多次元配列の操作と数学的演算
- **自動微分**: 勾配の自動計算によるバックプロパゲーション
- **ニューラルネットワークレイヤー**: 線形層、畳み込み層、再帰層など
- **活性化関数**: ReLU、Sigmoid、Tanh、LeakyReLUなど
- **損失関数**: MSE、クロスエントロピー、バイナリクロスエントロピーなど
- **オプティマイザ**: SGD、Adam、RMSprop、Adagradなど
- **高度なアーキテクチャ**: CNN、RNN、LSTM、Transformerなど
- **GPU/TPU最適化**: ハードウェアアクセラレーションによる高速計算
- **分散学習**: データ並列、モデル並列、パイプライン並列処理
- **モデルシリアライズ**: モデルの保存と読み込み、ONNX互換性
- **高レベルAPI**: データセット、データローダー、トレーナーなど

## モジュール構成

```
OpalStdlib.DeepLearning
├── Tensor                  # テンソル操作
├── Autograd                # 自動微分
├── NNBase                  # ニューラルネットワーク基本コンポーネント
├── Layers                  # レイヤー実装
├── Activations             # 活性化関数
├── Losses                  # 損失関数
├── Optimizers              # オプティマイザ
├── Models                  # 事前定義モデル
│   ├── CNN                 # 畳み込みニューラルネットワーク
│   ├── RNN                 # 再帰型ニューラルネットワーク
│   └── Transformer         # Transformerモデル
├── GPU                     # GPU最適化
├── Distributed             # 分散学習
├── Serialization           # モデルシリアライズ
├── API                     # 高レベルAPI
└── Tests                   # テストスイート
```

## 使用例

### 基本的なニューラルネットワークの構築

```opal
import OpalStdlib.DeepLearning.NNBase
import OpalStdlib.DeepLearning.Layers
import OpalStdlib.DeepLearning.Activations

// シーケンシャルモデルの作成
nc model <- Sequential<Float32>()

// レイヤーの追加
model.add(Linear<Float32>(784, 128))
model.add(ReLU<Float32>())
model.add(Linear<Float32>(128, 64))
model.add(ReLU<Float32>())
model.add(Linear<Float32>(64, 10))
model.add(Softmax<Float32>())

// モデル情報の表示
model.summary()
```

### 高レベルAPIを使用したモデルのトレーニング

```opal
import OpalStdlib.DeepLearning.API.DeepLearningAPI

// モデルビルダーを使用したモデルの構築
nc builder <- ModelBuilder<Float32>()
nc model <- builder
    .addLinear(784, 128)
    .addActivation("relu")
    .addLinear(128, 64)
    .addActivation("relu")
    .addLinear(64, 10)
    .build()

// 損失関数とオプティマイザの設定
nc lossFunction <- CrossEntropyLoss<Float32>()
nc optimizer <- Adam<Float32>(model.getParameters(), 0.001)

// トレーナーの作成
nc trainer <- Trainer<Float32>(model, lossFunction, optimizer)

// データセットの読み込み
nc dataset <- datasetUtils.loadFromCSV("mnist.csv", [1..784], [0], true)
nc splits <- datasetUtils.splitDataset(dataset, 0.8, true)
nc trainDataset <- splits.first()
nc testDataset <- splits.second()

// データローダーの作成
nc trainLoader <- DataLoader<Float32>(trainDataset, 32, true)
nc testLoader <- DataLoader<Float32>(testDataset, 32)

// モデルのトレーニング
nc history <- trainer.train(trainLoader, testLoader, 10, "mnist_model", 1, 3)

// 学習曲線の表示
trainer.plotLearningCurve(history, "learning_curve.png")
```

### CNNモデルの構築

```opal
import OpalStdlib.DeepLearning.Models.CNN

// 事前定義されたLeNet-5モデルの使用
nc model <- CNN.lenet5<Float32>(10)

// カスタムCNNの構築
nc customCNN <- Sequential<Float32>()
customCNN.add(Conv2d<Float32>(1, 32, 3, 1, 1))
customCNN.add(ReLU<Float32>())
customCNN.add(MaxPool2d<Float32>(2, 2))
customCNN.add(Conv2d<Float32>(32, 64, 3, 1, 1))
customCNN.add(ReLU<Float32>())
customCNN.add(MaxPool2d<Float32>(2, 2))
customCNN.add(Flatten<Float32>())
customCNN.add(Linear<Float32>(64 * 7 * 7, 128))
customCNN.add(ReLU<Float32>())
customCNN.add(Linear<Float32>(128, 10))
```

### RNNモデルの構築

```opal
import OpalStdlib.DeepLearning.Models.RNN

// 事前定義されたLSTMモデルの使用
nc model <- RNN.lstm<Float32>(256, 128, 2, 10)

// カスタムRNNの構築
nc customRNN <- Sequential<Float32>()
customRNN.add(Embedding<Float32>(10000, 256))
customRNN.add(LSTM<Float32>(256, 128, 2, true, 0.2))
customRNN.add(Linear<Float32>(256, 10))  // 双方向LSTMなので出力は256次元
```

### Transformerモデルの構築

```opal
import OpalStdlib.DeepLearning.Models.Transformer

// 事前定義されたTransformerモデルの使用
nc model <- Transformer.transformer<Float32>(10000, 10, 512, 8, 6, 6)

// BERTモデルの使用
nc bertModel <- Transformer.bertBase<Float32>(30000)
```

### GPU加速の使用

```opal
import OpalStdlib.DeepLearning.GPU.GPUTensor

// GPUデバイスの設定
GPUTensor.setDevice(0)

// GPUテンソルの作成
nc tensor <- GPUTensor<Float32>.zeros([1000, 1000])

// モデルをGPUに移動
model.toDevice("gpu")

// トレーナーでGPUを使用
nc trainer <- Trainer<Float32>(model, lossFunction, optimizer, "gpu")
```

### 分散学習の使用

```opal
import OpalStdlib.DeepLearning.Distributed.DistributedTraining

// プロセスグループの初期化
nc processGroup <- DistributedUtils.initProcessGroup()

// データ並列モデルの作成
nc ddpModel <- DistributedUtils.dataParallel(model, processGroup)

// 分散トレーナーの作成
nc trainer <- Trainer<Float32>(model, lossFunction, optimizer, "gpu", true)
```

### モデルの保存と読み込み

```opal
import OpalStdlib.DeepLearning.Serialization.ModelSerialization

// モデルの保存
modelIO.saveModel(model, "model.opal", ModelFormat.OPAL, optimizer.getState())

// モデルの読み込み
modelIO.loadModel(model, "model.opal", ModelFormat.OPAL)

// ONNX形式でのエクスポート
onnxConverter.exportToONNX(model, "model.onnx", [1, 3, 224, 224])
```

## テンソル操作

テンソルは深層学習の基本的なデータ構造であり、多次元配列として表現されます。

### テンソルの作成

```opal
// ゼロテンソルの作成
nc zeros <- tensor.zeros<Float32>([2, 3])

// 1で満たされたテンソルの作成
nc ones <- tensor.ones<Float32>([2, 3])

// 配列からテンソルの作成
nc data <- [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
nc t <- tensor.fromArray<Float32>(data, [2, 3])

// ランダムテンソルの作成
nc random <- tensor.rand<Float32>([2, 3])
```

### テンソル操作

```opal
// テンソルの加算
nc c <- a.add(b)

// テンソルの減算
nc d <- a.sub(b)

// テンソルの乗算
nc e <- a.mul(b)

// テンソルの除算
nc f <- a.div(b)

// 行列積
nc g <- a.matmul(b)

// 転置
nc h <- a.transpose()

// 要素の取得
nc value <- a.getAt([0, 1])

// 要素の設定
a.setAt([0, 1], 10.0)
```

## 自動微分

自動微分は、ニューラルネットワークのトレーニングに必要な勾配を自動的に計算する機能です。

### 勾配計算

```opal
// 勾配計算が必要なテンソルの作成
nc a <- tensor.fromArray<Float32>([2.0], [1], true)
nc b <- tensor.fromArray<Float32>([3.0], [1], true)

// 演算
nc c <- a.mul(b)  // c = a * b

// 勾配計算
c.backward()

// 勾配の取得
nc gradA <- a.getGrad()
nc gradB <- b.getGrad()
```

## レイヤー

レイヤーはニューラルネットワークの基本的な構成要素です。

### 線形層

```opal
// 線形層の作成
nc linear <- Linear<Float32>(10, 5)

// 順伝播
nc output <- linear.forward(input)
```

### 畳み込み層

```opal
// 2D畳み込み層の作成
nc conv <- Conv2d<Float32>(3, 16, 3, 1, 1)

// 順伝播
nc output <- conv.forward(input)
```

### プーリング層

```opal
// 最大プーリング層の作成
nc maxPool <- MaxPool2d<Float32>(2, 2)

// 平均プーリング層の作成
nc avgPool <- AvgPool2d<Float32>(2, 2)

// 順伝播
nc output <- maxPool.forward(input)
```

### 再帰層

```opal
// LSTM層の作成
nc lstm <- LSTM<Float32>(256, 128, 2, false, 0.2)

// GRU層の作成
nc gru <- GRU<Float32>(256, 128, 2, false, 0.2)

// 順伝播
nc output <- lstm.forward(input)
```

### Transformer層

```opal
// Transformerエンコーダー層の作成
nc encoderLayer <- TransformerEncoderLayer<Float32>(512, 8, 2048, 0.1)
nc encoder <- TransformerEncoder<Float32>(encoderLayer, 6)

// Transformerデコーダー層の作成
nc decoderLayer <- TransformerDecoderLayer<Float32>(512, 8, 2048, 0.1)
nc decoder <- TransformerDecoder<Float32>(decoderLayer, 6)

// 順伝播
nc encoderOutput <- encoder.forward(input)
nc decoderOutput <- decoder.forward(target, encoderOutput)
```

## 活性化関数

活性化関数はニューラルネットワークに非線形性を導入します。

### 基本的な活性化関数

```opal
// ReLU
nc relu <- ReLU<Float32>()

// Sigmoid
nc sigmoid <- Sigmoid<Float32>()

// Tanh
nc tanh <- Tanh<Float32>()

// LeakyReLU
nc leakyRelu <- LeakyReLU<Float32>(0.01)

// ELU
nc elu <- ELU<Float32>(1.0)

// GELU
nc gelu <- GELU<Float32>()

// Softmax
nc softmax <- Softmax<Float32>()

// 順伝播
nc output <- relu.forward(input)
```

## 損失関数

損失関数はモデルの予測と実際の値の差を測定します。

### 基本的な損失関数

```opal
// 平均二乗誤差
nc mseLoss <- MSELoss<Float32>()

// クロスエントロピー損失
nc crossEntropyLoss <- CrossEntropyLoss<Float32>()

// バイナリクロスエントロピー損失
nc binaryCrossEntropyLoss <- BinaryCrossEntropyLoss<Float32>()

// 損失計算
nc loss <- mseLoss.forward(predictions, targets)
```

## オプティマイザ

オプティマイザはモデルのパラメータを更新してトレーニングを行います。

### 基本的なオプティマイザ

```opal
// 確率的勾配降下法
nc sgd <- SGD<Float32>(model.getParameters(), 0.01, 0.9, 0.0001)

// Adam
nc adam <- Adam<Float32>(model.getParameters(), 0.001, 0.9, 0.999, 1e-8)

// RMSprop
nc rmsprop <- RMSprop<Float32>(model.getParameters(), 0.001, 0.9, 1e-8)

// Adagrad
nc adagrad <- Adagrad<Float32>(model.getParameters(), 0.01, 1e-8)

// パラメータ更新
optimizer.zeroGrad()
loss.backward()
optimizer.step()
```

## 高レベルAPI

高レベルAPIは、データの読み込み、モデルの構築、トレーニング、評価を簡単に行うための抽象化を提供します。

### データセットとデータローダー

```opal
// CSVからデータセットを読み込み
nc dataset <- datasetUtils.loadFromCSV("data.csv", [1..10], [0], true)

// 画像フォルダからデータセットを読み込み
nc imageDataset <- datasetUtils.loadFromImageFolder("images/", 224)

// テキストファイルからデータセットを読み込み
nc textDataset <- datasetUtils.loadFromTextFile("text.txt", 10000, 100)

// データセットの分割
nc splits <- datasetUtils.splitDataset(dataset, 0.8, true)
nc trainDataset <- splits.first()
nc testDataset <- splits.second()

// データローダーの作成
nc trainLoader <- DataLoader<Float32>(trainDataset, 32, true)
nc testLoader <- DataLoader<Float32>(testDataset, 32)
```

### モデルビルダー

```opal
// モデルビルダーの作成
nc builder <- ModelBuilder<Float32>()

// モデルの構築
nc model <- builder
    .addLinear(784, 128)
    .addActivation("relu")
    .addDropout(0.2)
    .addLinear(128, 64)
    .addActivation("relu")
    .addDropout(0.2)
    .addLinear(64, 10)
    .build()

// 事前定義モデルの構築
nc lenet <- builder.buildPredefined("lenet5", 10)
nc resnet <- builder.buildPredefined("resnet18", 1000)
nc bertModel <- builder.buildPredefined("bert", 30000)
```

### トレーナー

```opal
// トレーナーの作成
nc trainer <- Trainer<Float32>(model, lossFunction, optimizer, "gpu")

// モデルのトレーニング
nc history <- trainer.train(trainLoader, testLoader, 10, "model", 1, 3)

// モデルの評価
nc result <- trainer.evaluate(testLoader)
nc testLoss <- result.first()
nc accuracy <- result.second()

// 予測
nc predictions <- trainer.predict(input)

// 学習曲線の表示
trainer.plotLearningCurve(history, "learning_curve.png")
```

## GPU最適化

GPUを使用して計算を高速化します。

### GPUテンソル

```opal
// GPUデバイスの設定
GPUTensor.setDevice(0)

// GPUテンソルの作成
nc tensor <- GPUTensor<Float32>.zeros([1000, 1000])

// CPUテンソルをGPUに移動
nc gpuTensor <- tensor.toDevice("gpu")

// GPUテンソルをCPUに移動
nc cpuTensor <- gpuTensor.toDevice("cpu")
```

### GPUカーネル

```opal
// カスタムGPUカーネルの定義
nc kernel <- GPUKernel<Float32>("my_kernel", "
    __global__ void my_kernel(float* input, float* output, int size) {
        int idx = blockIdx.x * blockDim.x + threadIdx.x;
        if (idx < size) {
            output[idx] = input[idx] * 2.0f;
        }
    }
")

// カーネルの実行
kernel.launch(input, output, size, [size / 256 + 1, 256])
```

## 分散学習

複数のデバイスやマシンを使用して大規模なモデルをトレーニングします。

### データ並列処理

```opal
// プロセスグループの初期化
nc processGroup <- DistributedUtils.initProcessGroup()

// データ並列モデルの作成
nc ddpModel <- DistributedUtils.dataParallel(model, processGroup)

// 分散サンプラーの作成
nc sampler <- DistributedSampler(dataset, processGroup.getSize(), processGroup.getRank())

// 分散データローダーの作成
nc dataLoader <- DataLoader<Float32>(dataset, 32, false, false, 4, sampler)
```

### モデル並列処理

```opal
// モデル並列処理の設定
nc modelParallel <- ModelParallel<Float32>(model, [0, 1])

// パイプライン並列処理の設定
nc pipelineParallel <- PipelineParallel<Float32>(model, 4, [0, 1, 2, 3])
```

## モデルシリアライズ

モデルを保存して後で使用したり、他のフレームワークと共有したりします。

### モデルの保存と読み込み

```opal
// モデルの保存
modelIO.saveModel(model, "model.opal", ModelFormat.OPAL, optimizer.getState())

// モデルの読み込み
modelIO.loadModel(model, "model.opal", ModelFormat.OPAL)

// オプティマイザ状態の読み込み
nc optimizerState <- modelIO.loadOptimizerState("model.opal", ModelFormat.OPAL)
optimizer.setState(optimizerState)

// モデルのメタデータの読み込み
nc metadata <- modelIO.loadModelMetadata("model.opal", ModelFormat.OPAL)
```

### ONNX互換性

```opal
// モデルをONNX形式でエクスポート
onnxConverter.exportToONNX(model, "model.onnx", [1, 3, 224, 224])

// PyTorch形式での保存
modelIO.saveModel(model, "model.pt", ModelFormat.PYTORCH)

// TensorFlow形式での保存
modelIO.saveModel(model, "model.tf", ModelFormat.TENSORFLOW)
```

## テスト

ライブラリの各コンポーネントをテストします。

### テストの実行

```opal
import OpalStdlib.DeepLearning.Tests.DeepLearningTests

// テストの実行
DeepLearningTests.runTests()
```

## エラー処理

エラーを適切に処理して、デバッグを容易にします。

### 例外処理

```opal
try then
    // 深層学習コード
    nc model <- Sequential<Float32>()
    model.add(Linear<Float32>(784, 128))
    model.add(ReLU<Float32>())
    model.add(Linear<Float32>(128, 10))
    
    // トレーニング
    nc trainer <- Trainer<Float32>(model, lossFunction, optimizer)
    trainer.train(trainLoader, testLoader, 10)
catch e then
    // エラー処理
    "Error: " + e.getMessage() => out
    e.printStackTrace()
end
```

## パフォーマンスチューニング

モデルのパフォーマンスを最適化します。

### メモリ最適化

```opal
// 勾配チェックポイント
nc checkpoint <- GradientCheckpoint<Float32>(model)

// 混合精度トレーニング
nc mixedPrecision <- MixedPrecision<Float32>(model)

// メモリ効率の良いバックプロパゲーション
nc memoryEfficientBackprop <- MemoryEfficientBackprop<Float32>(model)
```

### 計算最適化

```opal
// 演算融合
nc fusedOps <- FusedOperations<Float32>(model)

// カーネル融合
nc fusedKernels <- FusedKernels<Float32>(model)

// 量子化
nc quantized <- Quantization<Float32>(model, QuantizationMode.INT8)
```

## 拡張機能

ライブラリを拡張して新しい機能を追加します。

### カスタムレイヤーの作成

```opal
// カスタムレイヤーの定義
nc class MyCustomLayer<T: Number> extends Module<T> then
    // パラメータ
    private nc weight: Parameter<T>
    private nc bias: Parameter<T>
    
    // コンストラクタ
    function init(inFeatures: Int32, outFeatures: Int32) -> Void then
        // パラメータの初期化
        weight <- Parameter<T>(tensor.rand<T>([inFeatures, outFeatures]).mul(0.01))
        bias <- Parameter<T>(tensor.zeros<T>([outFeatures]))
        
        // パラメータの登録
        registerParameter("weight", weight)
        registerParameter("bias", bias)
    end
    
    // 順伝播
    override function forward(input: AutogradTensor<T>) -> AutogradTensor<T> then
        // カスタム演算
        nc output <- input.matmul(weight.getData())
        output <- output.add(bias.getData())
        return output
    end
end

// カスタムレイヤーの使用
nc customLayer <- MyCustomLayer<Float32>(10, 5)
nc output <- customLayer.forward(input)
```

### カスタム損失関数の作成

```opal
// カスタム損失関数の定義
nc class MyCustomLoss<T: Number> extends LossFunction<T> then
    // コンストラクタ
    function init() -> Void then
        // 初期化
    end
    
    // 順伝播
    override function forward(predictions: AutogradTensor<T>, targets: AutogradTensor<T>) -> AutogradTensor<T> then
        // カスタム損失計算
        nc diff <- predictions.sub(targets)
        nc squared <- diff.pow(2)
        nc loss <- squared.mean()
        return loss
    end
end

// カスタム損失関数の使用
nc customLoss <- MyCustomLoss<Float32>()
nc loss <- customLoss.forward(predictions, targets)
```

### カスタムオプティマイザの作成

```opal
// カスタムオプティマイザの定義
nc class MyCustomOptimizer<T: Number> extends Optimizer<T> then
    // 学習率
    private nc learningRate: T
    
    // コンストラクタ
    function init(parameters: Array<Parameter<T>>, learningRate: T) -> Void then
        // 親クラスの初期化
        super.init(parameters)
        
        // 学習率の設定
        this.learningRate <- learningRate
    end
    
    // パラメータ更新
    override function step() -> Void then
        for param in parameters then
            if param.getGrad() != null then
                // カスタム更新ルール
                nc data <- param.getData()
                nc grad <- param.getGrad()
                nc update <- grad.mul(learningRate)
                nc newData <- data.sub(update)
                param.setData(newData)
            end
        end
    end
end

// カスタムオプティマイザの使用
nc customOptimizer <- MyCustomOptimizer<Float32>(model.getParameters(), 0.01)
customOptimizer.step()
```

## 応用例

ライブラリを使用した実際の応用例を示します。

### 画像分類

```opal
// ResNet-18モデルの作成
nc model <- CNN.resnet18<Float32>(1000)

// 画像データセットの読み込み
nc dataset <- datasetUtils.loadFromImageFolder("images/", 224)
nc splits <- datasetUtils.splitDataset(dataset, 0.8, true)
nc trainDataset <- splits.first()
nc testDataset <- splits.second()

// データローダーの作成
nc trainLoader <- DataLoader<Float32>(trainDataset, 32, true)
nc testLoader <- DataLoader<Float32>(testDataset, 32)

// トレーナーの作成
nc trainer <- Trainer<Float32>(model, CrossEntropyLoss<Float32>(), 
                             Adam<Float32>(model.getParameters(), 0.001), "gpu")

// モデルのトレーニング
trainer.train(trainLoader, testLoader, 10, "resnet18_model", 1, 3)
```

### 自然言語処理

```opal
// BERTモデルの作成
nc model <- Transformer.bertBase<Float32>(30000)

// テキストデータセットの読み込み
nc dataset <- datasetUtils.loadFromTextFile("text.txt", 30000, 512)
nc splits <- datasetUtils.splitDataset(dataset, 0.8, true)
nc trainDataset <- splits.first()
nc testDataset <- splits.second()

// データローダーの作成
nc trainLoader <- DataLoader<Float32>(trainDataset, 16, true)
nc testLoader <- DataLoader<Float32>(testDataset, 16)

// トレーナーの作成
nc trainer <- Trainer<Float32>(model, CrossEntropyLoss<Float32>(), 
                             Adam<Float32>(model.getParameters(), 0.00005), "gpu")

// モデルのトレーニング
trainer.train(trainLoader, testLoader, 5, "bert_model", 1, 2)
```

### 時系列予測

```opal
// LSTMモデルの作成
nc model <- Sequential<Float32>()
model.add(LSTM<Float32>(1, 64, 2, false, 0.2))
model.add(Linear<Float32>(64, 1))

// 時系列データセットの読み込み
nc dataset <- TimeSeriesDataset<Float32>("timeseries.csv", 10, 1)
nc splits <- datasetUtils.splitDataset(dataset, 0.8, false)
nc trainDataset <- splits.first()
nc testDataset <- splits.second()

// データローダーの作成
nc trainLoader <- DataLoader<Float32>(trainDataset, 32, true)
nc testLoader <- DataLoader<Float32>(testDataset, 32)

// トレーナーの作成
nc trainer <- Trainer<Float32>(model, MSELoss<Float32>(), 
                             Adam<Float32>(model.getParameters(), 0.001))

// モデルのトレーニング
trainer.train(trainLoader, testLoader, 50, "lstm_model", 5, 10)
```

## まとめ

Opal深層学習ライブラリは、Opal言語で深層学習モデルを構築、トレーニング、評価、デプロイするための包括的なツールセットを提供します。テンソル操作から高レベルAPIまで、深層学習の全ての側面をカバーし、TensorFlow、PyTorch、JAXに相当する機能をOpal言語で実現しています。

このライブラリを使用することで、Opalプログラマーは最先端の深層学習技術を活用し、画像認識、自然言語処理、時系列予測などの様々なタスクに取り組むことができます。
