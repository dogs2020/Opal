#!/bin/bash

# Opal Language Installation Script

# Default installation directory
DEFAULT_INSTALL_DIR="$HOME/opal"
INSTALL_DIR=""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}"
echo "  ____  ____   _    _     "
echo " / __ \|  _ \ / \  | |    "
echo "| |  | | |_) / _ \ | |    "
echo "| |  | |  __/ ___ \| |___ "
echo "| |__| | | /_/   \_\_____|"
echo " \____/|_|               "
echo -e "${NC}"
echo "Opal Programming Language Installer"
echo "===================================="
echo ""

# Check if running with root privileges
if [ "$EUID" -eq 0 ]; then
  echo -e "${RED}Warning: Running as root. It's recommended to install Opal as a regular user.${NC}"
  echo "Press Enter to continue anyway, or Ctrl+C to abort."
  read
fi

# Ask for installation directory
echo "Where would you like to install Opal?"
echo "Default: $DEFAULT_INSTALL_DIR"
read -p "Installation directory [press Enter for default]: " INSTALL_DIR

# Use default if empty
if [ -z "$INSTALL_DIR" ]; then
  INSTALL_DIR="$DEFAULT_INSTALL_DIR"
fi

# Expand tilde to home directory
INSTALL_DIR="${INSTALL_DIR/#\~/$HOME}"

echo ""
echo "Installing Opal to: $INSTALL_DIR"

# Create installation directory if it doesn't exist
mkdir -p "$INSTALL_DIR"

# Copy files
echo "Copying files..."
cp -r bin "$INSTALL_DIR/"
cp -r lib "$INSTALL_DIR/"
cp -r docs "$INSTALL_DIR/"
cp -r examples "$INSTALL_DIR/"
cp -r opal_implementation "$INSTALL_DIR/"

# Make executables executable
chmod +x "$INSTALL_DIR/bin/"*

# Detect shell
SHELL_NAME="$(basename "$SHELL")"
SHELL_CONFIG=""

case "$SHELL_NAME" in
  bash)
    SHELL_CONFIG="$HOME/.bashrc"
    ;;
  zsh)
    SHELL_CONFIG="$HOME/.zshrc"
    ;;
  fish)
    SHELL_CONFIG="$HOME/.config/fish/config.fish"
    ;;
  *)
    SHELL_CONFIG="$HOME/.bashrc"
    echo -e "${RED}Warning: Unsupported shell detected. Using .bashrc as fallback.${NC}"
    ;;
esac

# Add to PATH
echo ""
echo "Updating shell configuration ($SHELL_CONFIG)..."

# Check if config file exists
if [ ! -f "$SHELL_CONFIG" ]; then
  touch "$SHELL_CONFIG"
fi

# Add environment variables to shell config
if ! grep -q "OPAL_HOME" "$SHELL_CONFIG"; then
  echo "" >> "$SHELL_CONFIG"
  echo "# Opal Programming Language" >> "$SHELL_CONFIG"
  echo "export OPAL_HOME=\"$INSTALL_DIR\"" >> "$SHELL_CONFIG"
  echo "export PATH=\"\$PATH:\$OPAL_HOME/bin\"" >> "$SHELL_CONFIG"
  echo "export LD_LIBRARY_PATH=\"\$LD_LIBRARY_PATH:\$OPAL_HOME/lib\"" >> "$SHELL_CONFIG"
fi

# Create desktop entries for Linux
if [ "$(uname)" = "Linux" ]; then
  echo "Creating desktop entries..."
  DESKTOP_DIR="$HOME/.local/share/applications"
  mkdir -p "$DESKTOP_DIR"
  
  # Create desktop entry for Opal IDE
  cat > "$DESKTOP_DIR/opal-ide.desktop" << EOF
[Desktop Entry]
Name=Opal IDE
Comment=Integrated Development Environment for Opal
Exec=$INSTALL_DIR/bin/opal_ide
Icon=$INSTALL_DIR/opal_implementation/src/assets/icons/opal-ide.png
Terminal=false
Type=Application
Categories=Development;IDE;
EOF

  # Create desktop entry for Opal Playground
  cat > "$DESKTOP_DIR/opal-playground.desktop" << EOF
[Desktop Entry]
Name=Opal Playground
Comment=Interactive playground for Opal language
Exec=$INSTALL_DIR/bin/opal_playground
Icon=$INSTALL_DIR/opal_implementation/src/assets/icons/opal-playground.png
Terminal=false
Type=Application
Categories=Development;Education;
EOF
fi

echo -e "${GREEN}Opal installation completed successfully!${NC}"
echo ""
echo "To start using Opal, please:"
echo "1. Restart your terminal or run: source $SHELL_CONFIG"
echo "2. Run 'opal_ide' to start the Opal IDE"
echo "3. Run 'opal_playground' to start the Opal Playground"
echo "4. Run 'opal help' for more information"
echo ""
echo "Documentation is available at: $INSTALL_DIR/docs"
echo "Examples are available at: $INSTALL_DIR/examples"
echo ""
echo "Enjoy programming with Opal!"
