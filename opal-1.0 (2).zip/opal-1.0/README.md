# Opal Programming Language

## 概要

Opal（オパール）は高速で効率的なプログラミング言語です。手動メモリ管理と最小限のランタイムオーバーヘッドを特徴とし、SwiftやC++よりも高速な実行速度を目指しています。

## 特徴

- **高速な実行速度**: 最小限のランタイムオーバーヘッドと効率的なコード生成により、高速な実行を実現
- **手動メモリ管理**: 予測可能なパフォーマンスと低いメモリ使用量
- **静的型付け**: コンパイル時の型チェックによるエラー検出
- **関数型プログラミングの要素**: 高階関数、クロージャなどをサポート
- **自己ホスティング**: コンパイラ自身がOpal言語で記述されている

## インストール

### 前提条件

- C/C++コンパイラ（GCC 7.0以上またはClang 6.0以上）
- Python 3.6以上（ブートストラップコンパイラ用）
- CMake 3.10以上

### ビルド手順

```bash
# リポジトリをクローン
git clone https://github.com/yourusername/opal.git
cd opal

# ビルドディレクトリを作成
mkdir build
cd build

# CMakeを実行
cmake ..

# ビルド
make

# インストール（オプション）
sudo make install
```

## 使い方

### Hello Worldプログラム

```opal
// hello_world.opal
function main() -> Integer then
    println("Hello, Opal World!");
    return 0;
end
```

### コンパイルと実行

```bash
# コンパイル
opalc hello_world.opal -o hello_world

# 実行
./hello_world
```

## ドキュメント

詳細なドキュメントは `docs` ディレクトリにあります：

- [言語仕様書](docs/language_specification.md)
- [標準ライブラリリファレンス](docs/standard_library.md)
- [コンパイラユーザーガイド](docs/compiler_guide.md)
- [チュートリアル](docs/tutorials.md)

## サンプルコード

サンプルコードは `examples` ディレクトリにあります：

- [Hello World](examples/hello_world.opal)
- [ファイルI/O](examples/file_io.opal)
- [データ構造](examples/data_structures.opal)
- [アルゴリズム](examples/algorithms.opal)

## コントリビューション

Opal言語の開発に貢献していただける方を歓迎します。以下の方法で貢献できます：

1. バグの報告
2. 機能リクエストの提出
3. プルリクエストの送信
4. ドキュメントの改善

## ライセンス

Opal言語はMITライセンスの下で公開されています。詳細は[LICENSE](LICENSE)ファイルを参照してください。

## 連絡先

- GitHub: [https://github.com/yourusername/opal](https://github.com/yourusername/opal)
- メール: your.email@example.com
- ウェブサイト: [https://opal-lang.org](https://opal-lang.org)

## 謝辞

Opal言語の開発に貢献してくださったすべての方々に感謝します。
