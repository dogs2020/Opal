#include <iostream>
#include <vector>
#include <chrono>
#include <random>
#include <algorithm>
#include <functional>
#include <string>
#include <unordered_map>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>

// 整数演算ベンチマーク
class IntegerOperationsBenchmark {
private:
    const int iterations = 10000000;
    std::vector<int> numbers;

public:
    void setup() {
        numbers.clear();
        for (int i = 0; i < 1000; i++) {
            numbers.push_back(i);
        }
    }

    void run() {
        int sum = 0;
        int product = 1;
        int quotient = 1000000;

        for (int i = 0; i < iterations; i++) {
            int index = i % numbers.size();
            int num = numbers[index];

            sum += num;
            product = (product * (num + 1)) % 1000;
            quotient = quotient / (num + 1) + 1;
        }
    }

    void cleanup() {
        numbers.clear();
    }
};

// 浮動小数点演算ベンチマーク
class FloatOperationsBenchmark {
private:
    const int iterations = 10000000;
    std::vector<double> numbers;

public:
    void setup() {
        numbers.clear();
        for (int i = 0; i < 1000; i++) {
            numbers.push_back(i / 100.0);
        }
    }

    void run() {
        double sum = 0.0;
        double product = 1.0;
        double quotient = 1000.0;

        for (int i = 0; i < iterations; i++) {
            int index = i % numbers.size();
            double num = numbers[index];

            sum += num;
            product *= (num + 0.01);
            quotient = quotient / (num + 0.01) + 0.01;

            if (product > 1000000.0) {
                product = 1.0;
            }
        }
    }

    void cleanup() {
        numbers.clear();
    }
};

// ビット演算ベンチマーク
class BitOperationsBenchmark {
private:
    const int iterations = 10000000;
    std::vector<int> numbers;

public:
    void setup() {
        numbers.clear();
        for (int i = 0; i < 1000; i++) {
            numbers.push_back(i);
        }
    }

    void run() {
        uint32_t result1 = 0;
        uint32_t result2 = 0;
        uint32_t result3 = 0;

        for (int i = 0; i < iterations; i++) {
            int index = i % numbers.size();
            int num = numbers[index];

            result1 |= num;
            result2 &= (num | 0xFF);
            result3 ^= num;

            result1 <<= 1;
            result2 >>= 1;
            result3 = (result3 << 2) | (result3 >> 30);

            result1 &= 0xFFFFFFFF;
        }
    }

    void cleanup() {
        numbers.clear();
    }
};

// 文字列操作ベンチマーク
class StringOperationsBenchmark {
private:
    const int iterations = 100000;
    std::vector<std::string> strings;

public:
    void setup() {
        strings.clear();
        for (int i = 0; i < 100; i++) {
            strings.push_back("String" + std::to_string(i));
        }
    }

    void run() {
        std::string result = "";

        for (int i = 0; i < iterations; i++) {
            int index = i % strings.size();
            const std::string& str = strings[index];

            result += str.substr(0, 3);

            if (result.length() > 1000) {
                result = "";
            }

            size_t index2 = str.find("g");
            std::string replaced = str;
            std::replace(replaced.begin(), replaced.end(), 'i', 'I');
        }
    }

    void cleanup() {
        strings.clear();
    }
};

// ソートアルゴリズムベンチマーク
class SortingBenchmark {
private:
    const int iterations = 100;
    std::vector<std::vector<double>> arrays;

public:
    void setup() {
        arrays.clear();
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0, 10000);

        for (int i = 0; i < 10; i++) {
            std::vector<double> array;
            for (int j = 0; j < 10000; j++) {
                array.push_back(dis(gen));
            }
            arrays.push_back(array);
        }
    }

    void run() {
        for (int i = 0; i < iterations; i++) {
            int index = i % arrays.size();
            std::vector<double> array = arrays[index];

            // クイックソート（C++のstd::sortはクイックソートベース）
            std::sort(array.begin(), array.end());
        }
    }

    void cleanup() {
        arrays.clear();
    }
};

// 検索アルゴリズムベンチマーク
class SearchingBenchmark {
private:
    const int iterations = 1000000;
    std::vector<std::vector<int>> arrays;
    std::random_device rd;
    std::mt19937 gen;
    std::uniform_int_distribution<> dis;

public:
    SearchingBenchmark() : gen(rd()), dis(0, 9999) {}

    void setup() {
        arrays.clear();
        for (int i = 0; i < 10; i++) {
            std::vector<int> array;
            for (int j = 0; j < 10000; j++) {
                array.push_back(j);
            }
            arrays.push_back(array);
        }
    }

    void run() {
        for (int i = 0; i < iterations; i++) {
            int index = i % arrays.size();
            const std::vector<int>& array = arrays[index];
            int target = dis(gen);

            // 二分探索
            std::binary_search(array.begin(), array.end(), target);
        }
    }

    void cleanup() {
        arrays.clear();
    }
};

// メイン関数
int main() {
    // ベンチマークの選択（コマンドライン引数から取得する代わりに、ここでは整数演算を実行）
    IntegerOperationsBenchmark benchmark;

    // セットアップ
    benchmark.setup();

    // ウォームアップ
    benchmark.run();

    // 測定開始
    auto start = std::chrono::high_resolution_clock::now();

    // ベンチマーク実行
    for (int i = 0; i < 10; i++) {
        benchmark.run();
    }

    // 測定終了
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration = end - start;

    // クリーンアップ
    benchmark.cleanup();

    // 結果の出力
    std::cout << "execution_time:" << duration.count() / 10.0 << std::endl;
    std::cout << "memory_usage:10.5" << std::endl;  // ダミー値
    std::cout << "cpu_usage:45.2" << std::endl;     // ダミー値
    std::cout << "cache_hit_rate:91.8" << std::endl; // ダミー値

    return 0;
}
