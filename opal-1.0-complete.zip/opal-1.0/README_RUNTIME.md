# Opal言語の実行方法

このパッケージには、Opal言語のコンパイラとランタイム環境が含まれています。以下の手順でOpal言語のプログラムをビルドして実行できます。

## 前提条件

- Python 3.6以上
- Node.js（コンパイル結果の実行に必要）

## 使用方法

1. ビルドと実行スクリプトを使用する：

```bash
./build_and_run.sh examples/hello.opal
```

このコマンドは、Opalソースコードをコンパイルし、生成されたJavaScriptコードを実行します。

## ファイル構成

- `src/` - Opal言語のソースコード
  - `lexer.opal` - レキサー（字句解析器）
  - `parser.opal` - パーサー（構文解析器）
  - `compiler.opal` - コンパイラ
  - `main.opal` - メインエントリーポイント
  - `python_bootstrap_eliminator.opal` - Opalで書かれたブートストラップコンパイラ

- `lib/` - ランタイムライブラリ
  - `runtime.opal` - 基本的なランタイム環境

- `bootstrap/` - Pythonブートストラップコンパイラ
  - `bootstrap.py` - Opal言語のPython実装

- `examples/` - サンプルプログラム
  - `hello_world.opal` - 基本的なHello Worldプログラム
  - `hello.opal` - テスト用のサンプルプログラム

- `docs/` - ドキュメント
  - `language_specification.md` - 言語仕様書

- `build_and_run.sh` - ビルドと実行のためのスクリプト

## ブートストラップの流れ

Opal言語の実装は以下のブートストラップ手順に従っています：

1. Pythonで書かれた初期ブートストラップコンパイラ（bootstrap.py）を使用して、Opalプログラムをコンパイルします。
2. Opalで書かれたコンパイラ（python_bootstrap_eliminator.opal）を使用して、Pythonの依存関係を排除します。
3. 最終的に、Opalコンパイラが自分自身をコンパイルできる「自己ホスティング」状態を実現します。

## サンプルプログラムの実行

```bash
./build_and_run.sh examples/hello.opal
```

このコマンドを実行すると、「Hello, Opal World!」というメッセージが表示されます。
