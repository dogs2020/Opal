#!/bin/bash

# Opalアプリケーションインストールスクリプト

# 色の定義
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# ヘルパー関数
print_header() {
    echo -e "${BLUE}===========================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}===========================================================${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# インストール先ディレクトリの設定
DEFAULT_INSTALL_DIR="/opt/opal-apps"
INSTALL_DIR=""

# インストール先の確認
print_header "Opalアプリケーションインストーラー"
echo "このスクリプトはOpal実行アプリ、IDE(OX)、プレイグラウンドをインストールします。"
echo ""

# インストールディレクトリの選択
read -p "インストール先ディレクトリを入力してください [デフォルト: $DEFAULT_INSTALL_DIR]: " INSTALL_DIR
INSTALL_DIR=${INSTALL_DIR:-$DEFAULT_INSTALL_DIR}

# インストールディレクトリの作成
echo "インストール先ディレクトリを作成しています: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

if [ ! -d "$INSTALL_DIR" ]; then
    print_error "インストール先ディレクトリの作成に失敗しました。権限を確認してください。"
    exit 1
fi

# ファイルの展開
print_header "ファイルの展開"
echo "アプリケーションファイルを展開しています..."

# binディレクトリ
mkdir -p "$INSTALL_DIR/bin"
cp -r bin/* "$INSTALL_DIR/bin/"
if [ $? -eq 0 ]; then
    print_success "実行ファイルのコピーが完了しました"
else
    print_error "実行ファイルのコピーに失敗しました"
    exit 1
fi

# libディレクトリ
mkdir -p "$INSTALL_DIR/lib"
cp -r lib/* "$INSTALL_DIR/lib/"
if [ $? -eq 0 ]; then
    print_success "ライブラリファイルのコピーが完了しました"
else
    print_error "ライブラリファイルのコピーに失敗しました"
    exit 1
fi

# docsディレクトリ
mkdir -p "$INSTALL_DIR/docs"
cp -r docs/* "$INSTALL_DIR/docs/"
if [ $? -eq 0 ]; then
    print_success "ドキュメントのコピーが完了しました"
else
    print_error "ドキュメントのコピーに失敗しました"
    exit 1
fi

# examplesディレクトリ
mkdir -p "$INSTALL_DIR/examples"
cp -r examples/* "$INSTALL_DIR/examples/"
if [ $? -eq 0 ]; then
    print_success "サンプルファイルのコピーが完了しました"
else
    print_error "サンプルファイルのコピーに失敗しました"
    exit 1
fi

# 実行権限の設定
print_header "実行権限の設定"
echo "実行ファイルに実行権限を設定しています..."

chmod +x "$INSTALL_DIR/bin/opal_execution_app"
chmod +x "$INSTALL_DIR/bin/opal_ide"
chmod +x "$INSTALL_DIR/bin/opal_playground"
chmod +x "$INSTALL_DIR/bin/opal_integrated_app"

print_success "実行権限の設定が完了しました"

# シンボリックリンクの作成
print_header "シンボリックリンクの作成"
echo "システムのPATHにアプリケーションを追加しています..."

# ユーザーのbinディレクトリが存在するか確認
USER_BIN="$HOME/.local/bin"
if [ ! -d "$USER_BIN" ]; then
    mkdir -p "$USER_BIN"
    echo "ディレクトリを作成しました: $USER_BIN"
fi

# PATHにユーザーのbinディレクトリが含まれているか確認
if [[ ":$PATH:" != *":$USER_BIN:"* ]]; then
    echo "export PATH=\"\$PATH:$USER_BIN\"" >> "$HOME/.bashrc"
    echo "~/.bashrcにPATHを追加しました"
    echo "変更を適用するには、新しいターミナルを開くか、'source ~/.bashrc'を実行してください"
fi

# シンボリックリンクの作成
ln -sf "$INSTALL_DIR/bin/opal_execution_app" "$USER_BIN/opal_run"
ln -sf "$INSTALL_DIR/bin/opal_ide" "$USER_BIN/opal_ide"
ln -sf "$INSTALL_DIR/bin/opal_playground" "$USER_BIN/opal_playground"
ln -sf "$INSTALL_DIR/bin/opal_integrated_app" "$USER_BIN/opal_studio"

print_success "シンボリックリンクの作成が完了しました"

# 環境変数の設定
print_header "環境変数の設定"
echo "Opalアプリケーションの環境変数を設定しています..."

# .bashrcに環境変数を追加
BASHRC_CONTENT="
# Opal Applications Environment Variables
export OPAL_HOME=\"$INSTALL_DIR\"
export OPAL_LIB=\"$INSTALL_DIR/lib\"
export PATH=\"\$PATH:$INSTALL_DIR/bin\"
"

echo "$BASHRC_CONTENT" >> "$HOME/.bashrc"
print_success "環境変数の設定が完了しました"

# デスクトップエントリの作成
print_header "デスクトップエントリの作成"
echo "デスクトップエントリを作成しています..."

DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"

# IDE用デスクトップエントリ
cat > "$DESKTOP_DIR/opal-ide.desktop" << EOF
[Desktop Entry]
Name=Opal IDE (OX)
Comment=Integrated Development Environment for Opal
Exec=$INSTALL_DIR/bin/opal_ide
Icon=$INSTALL_DIR/docs/icons/opal_ide.png
Terminal=false
Type=Application
Categories=Development;IDE;
EOF

# プレイグラウンド用デスクトップエントリ
cat > "$DESKTOP_DIR/opal-playground.desktop" << EOF
[Desktop Entry]
Name=Opal Playground
Comment=Interactive environment for Opal language
Exec=$INSTALL_DIR/bin/opal_playground
Icon=$INSTALL_DIR/docs/icons/opal_playground.png
Terminal=false
Type=Application
Categories=Development;Education;
EOF

# 統合環境用デスクトップエントリ
cat > "$DESKTOP_DIR/opal-studio.desktop" << EOF
[Desktop Entry]
Name=Opal Studio
Comment=Integrated environment for Opal development
Exec=$INSTALL_DIR/bin/opal_integrated_app
Icon=$INSTALL_DIR/docs/icons/opal_studio.png
Terminal=false
Type=Application
Categories=Development;IDE;
EOF

print_success "デスクトップエントリの作成が完了しました"

# インストール完了メッセージ
print_header "インストール完了"
echo "Opalアプリケーションのインストールが完了しました！"
echo ""
echo "以下のコマンドでアプリケーションを起動できます："
echo "  opal_run     - Opal実行アプリ"
echo "  opal_ide     - Opal IDE (OX)"
echo "  opal_playground - Opalプレイグラウンド"
echo "  opal_studio  - Opal統合環境"
echo ""
echo "環境変数を適用するには、新しいターミナルを開くか、以下のコマンドを実行してください："
echo "  source ~/.bashrc"
echo ""
echo "詳細なドキュメントは以下の場所にあります："
echo "  $INSTALL_DIR/docs/opal_apps_documentation.md"
echo ""
echo "お楽しみください！"
