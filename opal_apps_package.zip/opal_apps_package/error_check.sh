#!/bin/bash

# Opalアプリケーションエラーチェックスクリプト

# 色の定義
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# ヘルパー関数
print_header() {
    echo -e "${BLUE}===========================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}===========================================================${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
    ERROR_COUNT=$((ERROR_COUNT+1))
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
    WARNING_COUNT=$((WARNING_COUNT+1))
}

# エラーカウンタの初期化
ERROR_COUNT=0
WARNING_COUNT=0

# 現在のディレクトリを取得
CURRENT_DIR=$(pwd)

print_header "Opalアプリケーションエラーチェック"
echo "すべてのOpalアプリケーションとスクリプトの包括的なエラーチェックを実行します..."
echo ""

# Opalファイルの構文チェック
check_opal_syntax() {
    local file=$1
    echo "ファイルをチェック中: $file"
    
    # Opalコンパイラを使用して構文チェック
    # 実際の環境では、Opalコンパイラの構文チェックモードを使用
    # ここではファイルの存在確認と基本的なパターンチェックを行う
    
    if [ ! -f "$file" ]; then
        print_error "ファイルが存在しません: $file"
        return 1
    fi
    
    # モジュール宣言のチェック
    if ! grep -q "module" "$file"; then
        print_warning "モジュール宣言が見つかりません: $file"
    fi
    
    # 関数宣言のチェック
    if ! grep -q "function" "$file"; then
        print_warning "関数宣言が見つかりません: $file"
    fi
    
    # 括弧の対応チェック
    local open_parens=$(grep -o "(" "$file" | wc -l)
    local close_parens=$(grep -o ")" "$file" | wc -l)
    if [ $open_parens -ne $close_parens ]; then
        print_error "括弧の対応が取れていません: $file (開き括弧: $open_parens, 閉じ括弧: $close_parens)"
    fi
    
    # 中括弧の対応チェック
    local open_braces=$(grep -o "{" "$file" | wc -l)
    local close_braces=$(grep -o "}" "$file" | wc -l)
    if [ $open_braces -ne $close_braces ]; then
        print_error "中括弧の対応が取れていません: $file (開き中括弧: $open_braces, 閉じ中括弧: $close_braces)"
    fi
    
    # セミコロンのチェック
    if ! grep -q ";" "$file"; then
        print_warning "セミコロンが見つかりません: $file"
    fi
    
    # 代入演算子のチェック
    if ! grep -q "<=" "$file"; then
        print_warning "代入演算子が見つかりません: $file"
    fi
    
    # エントリーポイント関数のチェック
    if grep -q "module" "$file" && ! grep -q "function first()" "$file"; then
        print_warning "エントリーポイント関数(first)が見つかりません: $file"
    fi
    
    return 0
}

# シェルスクリプトの構文チェック
check_shell_syntax() {
    local file=$1
    echo "シェルスクリプトをチェック中: $file"
    
    if [ ! -f "$file" ]; then
        print_error "ファイルが存在しません: $file"
        return 1
    fi
    
    # シェルスクリプトの構文チェック
    bash -n "$file"
    if [ $? -ne 0 ]; then
        print_error "シェルスクリプトの構文エラー: $file"
        return 1
    else
        print_success "シェルスクリプトの構文チェック成功: $file"
        return 0
    fi
}

# ディレクトリ内のすべてのOpalファイルをチェック
check_directory() {
    local dir=$1
    echo "ディレクトリをチェック中: $dir"
    
    if [ ! -d "$dir" ]; then
        print_error "ディレクトリが存在しません: $dir"
        return 1
    fi
    
    # Opalファイルをチェック
    find "$dir" -name "*.opal" -type f | while read file; do
        check_opal_syntax "$file"
    done
    
    # シェルスクリプトをチェック
    find "$dir" -name "*.sh" -type f | while read file; do
        check_shell_syntax "$file"
    done
    
    return 0
}

# インストールスクリプトのチェック
print_header "インストールスクリプトのチェック"
check_shell_syntax "$CURRENT_DIR/install.sh"

# binディレクトリのチェック
print_header "binディレクトリのチェック"
check_directory "$CURRENT_DIR/bin"

# libディレクトリのチェック
print_header "libディレクトリのチェック"
check_directory "$CURRENT_DIR/lib"

# docsディレクトリのチェック
print_header "docsディレクトリのチェック"
check_directory "$CURRENT_DIR/docs"

# examplesディレクトリのチェック
print_header "examplesディレクトリのチェック"
check_directory "$CURRENT_DIR/examples"

# 結果の表示
print_header "エラーチェック結果"
if [ $ERROR_COUNT -eq 0 ] && [ $WARNING_COUNT -eq 0 ]; then
    print_success "すべてのチェックが成功しました！エラーや警告は見つかりませんでした。"
else
    if [ $ERROR_COUNT -gt 0 ]; then
        print_error "エラーが $ERROR_COUNT 件見つかりました。修正が必要です。"
    fi
    
    if [ $WARNING_COUNT -gt 0 ]; then
        print_warning "警告が $WARNING_COUNT 件見つかりました。確認をお勧めします。"
    fi
fi

echo ""
echo "エラーチェックが完了しました。"
echo "詳細なログは上記を参照してください。"

# 終了コードの設定
if [ $ERROR_COUNT -gt 0 ]; then
    exit 1
else
    exit 0
fi
