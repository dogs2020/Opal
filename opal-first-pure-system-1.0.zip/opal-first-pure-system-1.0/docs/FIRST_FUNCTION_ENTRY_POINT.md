# Opal言語のfirst関数エントリーポイント

## 概要

Opal言語では、プログラムのエントリーポイントとして`first`関数を使用します。これは従来の多くのプログラミング言語で使用される`main`関数に相当するものです。

## first関数の定義

first関数は以下の形式で定義する必要があります：

```opal
function first() -> Integer then
    // プログラムのメインロジック
    return 0;  // 成功時は0、エラー時は非0の値を返す
end
```

または、コマンドライン引数を受け取る場合：

```opal
function first(args: Array<String>) -> Integer then
    // プログラムのメインロジック
    // args[0]はプログラム名、args[1]以降が実際の引数
    return 0;  // 成功時は0、エラー時は非0の値を返す
end
```

## 使用例

以下は、簡単なHello Worldプログラムの例です：

```opal
// Hello Worldプログラム - first関数エントリーポイント

function first() -> Integer then
    "Hello, Absolutely Pure Opal World!" => println;
    return 0;
end
```

## 注意点

- プログラムには必ず`first`関数が含まれている必要があります
- `first`関数は整数型（Integer）を返す必要があります
- 戻り値は、プログラムの終了コードとして使用されます（0は成功、非0は失敗）
- コマンドライン引数を使用する場合は、`Array<String>`型の引数を1つ受け取る必要があります

## 従来のmain関数からの移行

従来のmain関数を使用していたコードは、以下のように変更する必要があります：

変更前：
```opal
function main() -> Integer then
    // プログラムのメインロジック
    return 0;
end
```

変更後：
```opal
function first() -> Integer then
    // プログラムのメインロジック
    return 0;
end
```
