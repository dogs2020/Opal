# 絶対的に純粋なOpalシステム（first関数エントリーポイント対応版）

## 概要

このパッケージは、100%純粋なOpal言語で実装された自己完結型のプログラミング言語システムです。外部言語（Python、JavaScript、C/C++など）への依存関係は一切ありません。

このバージョンでは、プログラムのエントリーポイントとして`first`関数を使用します。

## 特徴

- 100%純粋なOpal実装 - 外部言語への依存なし
- 自己ホスティング能力 - Opalコンパイラ自身がOpalで実装
- アセンブリレベルのコンパイラ - 直接マシンコードを生成
- ELF形式の実行可能ファイル生成
- `first`関数をエントリーポイントとして使用

## インストール方法

```bash
# ビルドスクリプトを実行
./build.sh
```

## 使用方法

```bash
# Opalプログラムのコンパイル
./bin/opalc <source_file.opal> -o <output_file>

# 依存関係の検証
./bin/dependency_validator <directory>
```

## サンプルプログラム

```bash
# Hello Worldプログラムの実行
./examples/hello_world
```

## ドキュメント

詳細なドキュメントは`docs`ディレクトリに含まれています：

- `language_specification.md` - Opal言語の仕様
- `ABSOLUTELY_PURE_SYSTEM.md` - 絶対的に純粋なOpalシステムの設計
- `FIRST_FUNCTION_ENTRY_POINT.md` - first関数エントリーポイントの使用方法

## ライセンス

このプロジェクトはMITライセンスの下で公開されています。詳細は`LICENSE`ファイルを参照してください。
