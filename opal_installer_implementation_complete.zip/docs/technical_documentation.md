# Opalインストーラー技術ドキュメント

## 概要

このドキュメントは、Opal言語インストーラーの技術的な詳細を説明するものです。インストーラーの設計、アーキテクチャ、実装の詳細、および拡張方法について説明します。このドキュメントは、Opalインストーラーの開発者、カスタマイズを行いたい開発者、およびOpal言語の内部構造に興味のある技術者を対象としています。

## 目次

1. [アーキテクチャ概要](#アーキテクチャ概要)
2. [コンポーネント構成](#コンポーネント構成)
3. [コードの構造](#コードの構造)
4. [インストールワークフロー](#インストールワークフロー)
5. [パッケージ管理システム](#パッケージ管理システム)
6. [依存関係解決メカニズム](#依存関係解決メカニズム)
7. [プラットフォーム抽象化レイヤー](#プラットフォーム抽象化レイヤー)
8. [セキュリティ機能](#セキュリティ機能)
9. [パフォーマンス最適化](#パフォーマンス最適化)
10. [テスト戦略](#テスト戦略)
11. [拡張ポイント](#拡張ポイント)
12. [ビルドプロセス](#ビルドプロセス)
13. [トラブルシューティング](#トラブルシューティング)
14. [参考資料](#参考資料)

## アーキテクチャ概要

Opalインストーラーは、モジュール化された階層アーキテクチャに基づいて設計されています。各レイヤーは明確に定義されたインターフェースを通じて通信し、高い拡張性と保守性を実現しています。

### 主要レイヤー

1. **ユーザーインターフェースレイヤー**
   - GUIおよびCLIインターフェースを提供
   - ユーザー入力の処理とフィードバックの表示を担当

2. **コアロジックレイヤー**
   - インストール、アンインストール、アップデートのワークフローを管理
   - パッケージ管理と依存関係解決を担当

3. **プラットフォーム抽象化レイヤー**
   - OS固有の操作を抽象化
   - クロスプラットフォーム互換性を提供

4. **セキュリティレイヤー**
   - 署名検証、ハッシュチェック、権限管理を担当
   - セキュアな操作を保証

5. **パフォーマンスレイヤー**
   - リソース使用の最適化
   - 効率的なファイル操作とメモリ管理を提供

### アーキテクチャの特徴

- **自己ホスティング**: インストーラーは100%Opal言語で実装されており、Opal言語自体のインストールに使用されます。
- **モジュール性**: 各コンポーネントは独立して開発、テスト、更新が可能です。
- **拡張性**: プラグインアーキテクチャにより、新機能の追加が容易です。
- **クロスプラットフォーム**: Windows、macOS、Linuxで一貫した動作を保証します。

## コンポーネント構成

Opalインストーラーは以下の主要コンポーネントで構成されています：

### コアコンポーネント

1. **InstallationManager**
   - インストールプロセス全体を制御
   - インストールオプションの管理
   - インストール進捗の追跡

2. **UninstallationManager**
   - アンインストールプロセスを制御
   - ユーザーデータの保存オプション
   - クリーンアップ操作の管理

3. **UpdateManager**
   - アップデートの確認と通知
   - アップデートパッケージのダウンロードと適用
   - バックアップと復元機能

### パッケージ管理コンポーネント

1. **PackageRepository**
   - パッケージの保存と取得
   - パッケージメタデータの管理
   - リポジトリインデックスの維持

2. **PackageStructure**
   - パッケージ形式の定義
   - パッケージの作成と解析
   - パッケージの検証

3. **DependencyResolver**
   - 依存関係グラフの構築
   - バージョン互換性の確認
   - インストール順序の決定

### ユーザーインターフェースコンポーネント

1. **InstallerGUI**
   - グラフィカルインターフェース
   - インストールウィザード
   - 進捗表示

2. **InstallerCLI**
   - コマンドラインインターフェース
   - スクリプト化可能なインストール
   - 自動化サポート

### プラットフォーム固有コンポーネント

1. **WindowsPlatform**
   - Windows固有の機能
   - レジストリ操作
   - ショートカット作成

2. **MacOSPlatform**
   - macOS固有の機能
   - パッケージ署名
   - アプリケーションバンドル管理

3. **LinuxPlatform**
   - Linux固有の機能
   - パッケージマネージャー統合
   - システム設定

### セキュリティコンポーネント

1. **SecurityManager**
   - 署名検証
   - ハッシュチェック
   - 権限管理

### パフォーマンスコンポーネント

1. **PerformanceOptimizer**
   - リソース使用の最適化
   - キャッシュ管理
   - 並列処理

## コードの構造

Opalインストーラーのコードは以下のディレクトリ構造で整理されています：

```
/src
  /core                  # コアロジック
    installation_workflow.opal
    uninstallation_workflow.opal
  /package               # パッケージ管理
    package_manager.opal
    package_structure.opal
    package_repository.opal
  /dependency            # 依存関係解決
    dependency_resolver.opal
  /ui                    # ユーザーインターフェース
    /gui
      installer_gui.opal
    /cli
      installer_cli.opal
  /platform              # プラットフォーム抽象化
    platform_abstraction.opal
    /windows
      windows_platform.opal
    /macos
      macos_platform.opal
    /linux
      linux_platform.opal
  /verification          # 検証システム
    self_verification.opal
  /update                # アップデートシステム
    update_mechanism.opal
  /security              # セキュリティ
    security_manager.opal
  /performance           # パフォーマンス
    performance_optimizer.opal
  /packaging             # パッケージング
    installer_packager.opal
  /test                  # テスト
    integration_test.opal
/resources               # リソースファイル
  /images
  /templates
  /localization
/docs                    # ドキュメント
  user_guide.md
  technical_documentation.md
/platforms               # プラットフォーム固有のリソース
  /windows
  /macos
  /linux
```

### 主要クラスと関係

```
PlatformAbstraction
  ↑
  ├── InstallationManager
  ├── UninstallationManager
  ├── UpdateManager
  ├── PackageRepository
  ├── DependencyResolver
  ├── SecurityManager
  └── PerformanceOptimizer

InstallationManager
  ├── uses → PackageRepository
  ├── uses → DependencyResolver
  └── uses → SelfVerification

UpdateManager
  ├── uses → PackageRepository
  ├── uses → InstallationManager
  └── uses → SelfVerification

InstallerPackager
  ├── uses → SecurityManager
  └── uses → PerformanceOptimizer
```

## インストールワークフロー

Opalインストーラーのインストールプロセスは以下のステップで構成されています：

1. **初期化**
   - インストーラーの起動
   - システム要件の確認
   - ユーザーインターフェースの初期化

2. **ユーザー入力**
   - インストール先の選択
   - コンポーネントの選択
   - インストールオプションの設定

3. **準備**
   - 空き容量の確認
   - 既存のインストールの検出
   - 必要な権限の確認

4. **依存関係解決**
   - 必要なパッケージの特定
   - 依存関係グラフの構築
   - インストール順序の決定

5. **ファイル操作**
   - ファイルの展開
   - ディレクトリ構造の作成
   - ファイルのコピー

6. **環境設定**
   - 環境変数の設定
   - ショートカットの作成
   - ファイル関連付けの設定

7. **検証**
   - インストールの整合性確認
   - ハッシュチェック
   - 基本機能のテスト

8. **完了**
   - インストール情報の保存
   - ユーザーへの通知
   - クリーンアップ

### インストールオプション

インストールプロセスは、`InstallOptions`クラスを通じて設定される以下のオプションによってカスタマイズできます：

```opal
class InstallOptions then
    nc installLocation: String
    nc components: Array<String>
    nc createShortcut: Boolean
    nc registerEnvironmentVariables: Boolean
    nc installDependencies: Boolean
    nc overwriteExisting: Boolean
    // その他のオプション
end
```

## パッケージ管理システム

Opalインストーラーのパッケージ管理システムは、Opal言語とその関連コンポーネントの配布、インストール、更新を管理します。

### パッケージ形式

Opalパッケージ（`.opal-pkg`）は、以下の構造を持つZIPベースのアーカイブです：

```
package.json       # パッケージメタデータ
manifest.json      # ファイル一覧とハッシュ
/bin               # 実行可能ファイル
/lib               # ライブラリファイル
/doc               # ドキュメント
/resources         # リソースファイル
signature.sig      # パッケージ署名
```

### パッケージメタデータ

`package.json`ファイルには、以下の情報が含まれます：

```json
{
  "name": "opal",
  "version": "1.0.0",
  "description": "Opal言語",
  "author": "Opal Team",
  "license": "MIT",
  "dependencies": [
    {
      "name": "opal-tools",
      "version": ">=1.0.0",
      "optional": false
    },
    {
      "name": "opal-docs",
      "version": ">=1.0.0",
      "optional": true
    }
  ],
  "components": [
    "core",
    "stdlib",
    "compiler"
  ],
  "platforms": [
    "windows",
    "macos",
    "linux"
  ]
}
```

### パッケージリポジトリ

パッケージリポジトリは、以下の機能を提供します：

- パッケージのインポートとエクスポート
- パッケージのバージョン管理
- パッケージの検索と取得
- リポジトリインデックスの維持

## 依存関係解決メカニズム

依存関係解決システムは、パッケージ間の依存関係を解決し、正しいインストール順序を決定します。

### 依存関係グラフ

依存関係は有向グラフとして表現され、各ノードはパッケージを、各エッジは依存関係を表します。

### バージョン制約

バージョン制約は、セマンティックバージョニングに基づいて指定されます：

- `=1.0.0`: 正確なバージョン
- `>=1.0.0`: 指定バージョン以上
- `>1.0.0,<2.0.0`: バージョン範囲
- `~1.0.0`: パッチバージョンの更新のみ（1.0.x）
- `^1.0.0`: マイナーバージョンの更新まで（1.x.y）

### 解決アルゴリズム

依存関係解決は以下のステップで行われます：

1. 依存関係グラフの構築
2. 循環依存関係の検出と解決
3. バージョン制約の適用
4. 最適なバージョンの選択
5. インストール順序の決定

## プラットフォーム抽象化レイヤー

プラットフォーム抽象化レイヤーは、OS固有の操作を抽象化し、クロスプラットフォーム互換性を提供します。

### 抽象化されたOS操作

- ファイルシステム操作
- プロセス管理
- レジストリ/設定管理
- 環境変数管理
- ショートカット作成
- 権限管理

### プラットフォーム固有の実装

各プラットフォームには、抽象インターフェースを実装した固有のクラスがあります：

- `WindowsPlatform`: Windows固有の実装
- `MacOSPlatform`: macOS固有の実装
- `LinuxPlatform`: Linux固有の実装

## セキュリティ機能

Opalインストーラーは、以下のセキュリティ機能を提供します：

### 署名検証

- パッケージの署名検証
- 公開鍵暗号方式による署名
- 署名の自動検証

### ハッシュチェック

- ファイルの整合性検証
- SHA-256ハッシュアルゴリズム
- マニフェストベースの検証

### 権限管理

- 最小権限の原則
- 権限昇格の適切な処理
- 安全なファイル操作

### セキュアな通信

- HTTPS通信
- TLS証明書の検証
- 安全なダウンロード

## パフォーマンス最適化

Opalインストーラーは、以下のパフォーマンス最適化を実装しています：

### ファイル操作の最適化

- バッファサイズの最適化
- 並列ファイル操作
- ファイルキャッシュ

### メモリ使用の最適化

- メモリプール
- ガベージコレクション最適化
- メモリ使用量の制限

### 圧縮の最適化

- 最適な圧縮レベル
- 効率的な圧縮アルゴリズム（zstd）

### ネットワーク操作の最適化

- 並列ダウンロード
- ネットワークキャッシュ
- 再試行メカニズム

## テスト戦略

Opalインストーラーは、以下のテスト戦略を採用しています：

### 単体テスト

- 各クラスとメソッドの個別テスト
- モックとスタブの使用
- エッジケースのテスト

### 統合テスト

- コンポーネント間の相互作用のテスト
- エンドツーエンドのワークフローテスト
- プラットフォーム固有の機能テスト

### 自動テスト

- CI/CDパイプラインでの自動テスト
- 回帰テスト
- パフォーマンステスト

## 拡張ポイント

Opalインストーラーは、以下の拡張ポイントを提供します：

### プラグインシステム

- カスタムコンポーネントの追加
- インストールフックの実装
- カスタムUIの統合

### カスタマイズオプション

- インストーラーテーマのカスタマイズ
- インストールワークフローのカスタマイズ
- カスタムバリデーションルール

### スクリプティング

- インストール前/後のスクリプト
- カスタム検証スクリプト
- 環境設定スクリプト

## ビルドプロセス

Opalインストーラーのビルドプロセスは以下のステップで構成されています：

1. **ソースコードのコンパイル**
   - Opalコンパイラによるコンパイル
   - 最適化レベルの設定
   - デバッグシンボルの生成（オプション）

2. **リソースの組み込み**
   - 画像、アイコン、テンプレートの組み込み
   - ローカライゼーションリソースの組み込み
   - プラットフォーム固有のリソースの組み込み

3. **パッケージング**
   - プラットフォーム固有のパッケージの作成
   - 署名と検証
   - メタデータの生成

4. **配布**
   - パッケージのアップロード
   - リリースノートの生成
   - 更新情報の公開

### ビルド設定

ビルドプロセスは、`PackagingOptions`クラスを通じて設定されます：

```opal
class PackagingOptions then
    nc sourceDirectory: String
    nc outputDirectory: String
    nc packageName: String
    nc packageVersion: String
    nc optimizationLevel: Integer
    nc compressionLevel: Integer
    nc supportedPlatforms: Array<String>
    // その他の設定
end
```

## トラブルシューティング

### 開発者向けトラブルシューティング

#### ビルドエラー

- コンパイラバージョンの確認
- 依存関係の確認
- ビルド環境の設定確認

#### ランタイムエラー

- ログファイルの確認
- デバッグモードでの実行
- エラーコードの参照

#### プラットフォーム固有の問題

- プラットフォーム抽象化レイヤーの確認
- OS固有の制約の確認
- 権限とセキュリティ設定の確認

### ログとデバッグ

- ログレベルの設定
- ログファイルの場所
- デバッグ情報の出力方法

## 参考資料

- [Opal言語仕様](https://docs.opal-lang.org/spec)
- [Opal標準ライブラリリファレンス](https://docs.opal-lang.org/stdlib)
- [Opalコンパイラドキュメント](https://docs.opal-lang.org/compiler)
- [パッケージ形式仕様](https://docs.opal-lang.org/packaging)
- [セキュリティベストプラクティス](https://docs.opal-lang.org/security)

---

© 2025 Opal Team. All rights reserved.
