#!/usr/bin/env python3

def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

def main():
    import time
    
    start_time = int(time.time() * 1000)
    result = fibonacci(40)
    end_time = int(time.time() * 1000)
    
    print(f"Fibonacci(40) = {result}")
    print(f"Execution time: {end_time - start_time}ms")

if __name__ == "__main__":
    main()
