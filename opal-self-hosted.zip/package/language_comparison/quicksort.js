// JavaScript implementation of QuickSort benchmark

function quicksort(array, low, high) {
    if (low < high) {
        const pivotIndex = partition(array, low, high);
        quicksort(array, low, pivotIndex - 1);
        quicksort(array, pivotIndex + 1, high);
    }
}

function partition(array, low, high) {
    const pivot = array[high];
    let i = low - 1;
    
    for (let j = low; j < high; j++) {
        if (array[j] <= pivot) {
            i++;
            swap(array, i, j);
        }
    }
    
    swap(array, i + 1, high);
    return i + 1;
}

function swap(array, i, j) {
    const temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}

function main() {
    const size = 100000;
    const array = new Array(size);
    
    // Initialize array (reverse order)
    for (let i = 0; i < size; i++) {
        array[i] = size - i;
    }
    
    const startTime = Date.now();
    quicksort(array, 0, size - 1);
    const endTime = Date.now();
    
    // Verify result
    let isSorted = true;
    for (let i = 1; i < size; i++) {
        if (array[i] < array[i - 1]) {
            isSorted = false;
            break;
        }
    }
    
    console.log(`Array size: ${size}`);
    console.log(`Is sorted: ${isSorted ? "Yes" : "No"}`);
    console.log(`Execution time: ${endTime - startTime}ms`);
}

main();
