fn quicksort(array: &mut [i32], low: usize, high: usize) {
    if low < high {
        let pivot_index = partition(array, low, high);
        if pivot_index > 0 {
            quicksort(array, low, pivot_index - 1);
        }
        quicksort(array, pivot_index + 1, high);
    }
}

fn partition(array: &mut [i32], low: usize, high: usize) -> usize {
    let pivot = array[high];
    let mut i = low;
    
    for j in low..high {
        if array[j] <= pivot {
            array.swap(i, j);
            i += 1;
        }
    }
    
    array.swap(i, high);
    i
}

fn main() {
    use std::time::{Instant};
    
    let size = 100000;
    let mut array = vec![0; size];
    
    // Initialize array (reverse order)
    for i in 0..size {
        array[i] = (size - i) as i32;
    }
    
    let start_time = Instant::now();
    quicksort(&mut array, 0, size - 1);
    let duration = start_time.elapsed();
    
    // Verify result
    let mut is_sorted = true;
    for i in 1..size {
        if array[i] < array[i - 1] {
            is_sorted = false;
            break;
        }
    }
    
    println!("Array size: {}", size);
    println!("Is sorted: {}", if is_sorted { "Yes" } else { "No" });
    println!("Execution time: {}ms", duration.as_millis());
}
