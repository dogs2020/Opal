fn fibonacci(n: u64) -> u64 {
    if n <= 1 {
        return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

fn main() {
    use std::time::{Instant};
    
    let start_time = Instant::now();
    let result = fibonacci(40);
    let duration = start_time.elapsed();
    
    println!("Fibonacci(40) = {}", result);
    println!("Execution time: {}ms", duration.as_millis());
}
