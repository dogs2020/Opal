#!/usr/bin/env python3

def quicksort(array, low, high):
    if low < high:
        pivot_index = partition(array, low, high)
        quicksort(array, low, pivot_index - 1)
        quicksort(array, pivot_index + 1, high)

def partition(array, low, high):
    pivot = array[high]
    i = low - 1
    
    for j in range(low, high):
        if array[j] <= pivot:
            i += 1
            array[i], array[j] = array[j], array[i]
    
    array[i + 1], array[high] = array[high], array[i + 1]
    return i + 1

def main():
    import time
    
    size = 100000
    array = [0] * size
    
    # Initialize array (reverse order)
    for i in range(size):
        array[i] = size - i
    
    start_time = int(time.time() * 1000)
    quicksort(array, 0, size - 1)
    end_time = int(time.time() * 1000)
    
    # Verify result
    is_sorted = True
    for i in range(1, size):
        if array[i] < array[i - 1]:
            is_sorted = False
            break
    
    print(f"Array size: {size}")
    print(f"Is sorted: {'Yes' if is_sorted else 'No'}")
    print(f"Execution time: {end_time - start_time}ms")

if __name__ == "__main__":
    main()
