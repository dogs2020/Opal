// JavaScript implementation of Fibonacci benchmark

function fibonacci(n) {
    if (n <= 1) {
        return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

function main() {
    const startTime = Date.now();
    const result = fibonacci(40);
    const endTime = Date.now();
    
    console.log(`Fibonacci(40) = ${result}`);
    console.log(`Execution time: ${endTime - startTime}ms`);
}

main();
