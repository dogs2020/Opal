#!/bin/bash

# Opal自己ホスティング実装パッケージのインストールスクリプト
# このスクリプトは、Opal言語の自己ホスティング実装をインストールします。

echo "Opal自己ホスティング実装 インストーラー"
echo "========================================"
echo

# インストール先ディレクトリの確認
INSTALL_DIR="$HOME/opal-self-hosted"
echo "インストール先ディレクトリ: $INSTALL_DIR"
echo

# ユーザーの確認
read -p "このディレクトリにインストールしますか？ (y/n): " confirm
if [ "$confirm" != "y" ]; then
    read -p "インストール先ディレクトリを入力してください: " custom_dir
    if [ ! -z "$custom_dir" ]; then
        INSTALL_DIR="$custom_dir"
    fi
fi

# ディレクトリの作成
echo "インストール先ディレクトリを作成しています: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
if [ $? -ne 0 ]; then
    echo "エラー: ディレクトリの作成に失敗しました。"
    exit 1
fi

# パッケージの展開
echo "パッケージを展開しています..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR"
if [ $? -ne 0 ]; then
    echo "エラー: パッケージの展開に失敗しました。"
    exit 1
fi

# 実行権限の設定
echo "実行権限を設定しています..."
chmod +x "$INSTALL_DIR/bin/opal"
chmod +x "$INSTALL_DIR/bin/opal-benchmark"
chmod +x "$INSTALL_DIR/bin/opal-visualize"
chmod +x "$INSTALL_DIR/bin/opal-compare"

# 環境変数の設定
echo "環境変数を設定しています..."
echo "export PATH=\"\$PATH:$INSTALL_DIR/bin\"" > "$INSTALL_DIR/env.sh"
echo "export OPAL_HOME=\"$INSTALL_DIR\"" >> "$INSTALL_DIR/env.sh"

# .bashrcへの追加
echo
echo "環境変数を.bashrcに追加するには、以下のコマンドを実行してください:"
echo "echo \"source $INSTALL_DIR/env.sh\" >> ~/.bashrc"
echo "source ~/.bashrc"

# インストール完了メッセージ
echo
echo "Opal自己ホスティング実装のインストールが完了しました！"
echo
echo "使用方法:"
echo "  opal <ファイル名>              - Opalファイルをコンパイルして実行"
echo "  opal-benchmark                 - ベンチマークスイートを実行"
echo "  opal-visualize                 - パフォーマンス可視化ツールを起動"
echo "  opal-compare <言語1> <言語2>   - 言語間パフォーマンス比較"
echo
echo "ドキュメントは以下にあります:"
echo "  $INSTALL_DIR/docs/"
echo
echo "サンプルコードは以下にあります:"
echo "  $INSTALL_DIR/examples/"
echo
echo "お楽しみください！"
