# Opal自己ホスティング実装 - 開発者ガイド

## 1. アーキテクチャ概要

Opal言語の自己ホスティング実装は、以下の主要コンポーネントで構成されています。

```
+---------------------+      +---------------------+
| Opalソースコード    |----->| レキサー            |
+---------------------+      | (lexer.opal)        |
                             +---------------------+
                                      |
                                      v
+---------------------+      +---------------------+
| 抽象構文木 (AST)    |<-----| パーサー            |
+---------------------+      | (parser.opal)        |
         |                   +---------------------+
         v
+---------------------+      +---------------------+
| 中間表現            |----->| コード生成器        |
+---------------------+      | (code_generator.opal)|
                             +---------------------+
                                      |
                                      v
+---------------------+      +---------------------+
| 実行可能コード      |      | システムコール層    |
+---------------------+      | (system_call_layer.opal)
                             +---------------------+
```

### 1.1 主要コンポーネント

- **レキサー (lexer.opal)**: ソースコードをトークン列に変換
- **パーサー (parser.opal)**: トークン列から抽象構文木（AST）を構築
- **コード生成器 (code_generator.opal)**: ASTから実行可能コードを生成
- **システムコール層 (system_call_layer.opal)**: OSとの直接通信を行うインターフェース
- **Python依存関係排除ツール (python_bootstrap_eliminator.opal)**: Python依存を自動的に排除

## 2. 開発環境のセットアップ

### 2.1 必要なツール

- C/C++コンパイラ (GCC/Clang)
- Make
- Git

### 2.2 ビルド手順

1. リポジトリをクローンします。
   ```
   git clone https://github.com/your-username/opal-self-hosted.git
   cd opal-self-hosted
   ```

2. ビルドスクリプトを実行します。
   ```
   ./build.sh
   ```

3. テストを実行します。
   ```
   ./run_tests.sh
   ```

## 3. コードベースの構造

### 3.1 ディレクトリ構造

```
opal-self-hosted/
├── bin/                  # 実行可能ファイル
├── src/                  # ソースコード
│   ├── lexer.opal        # レキサー
│   ├── parser.opal       # パーサー
│   ├── code_generator.opal # コード生成器
│   ├── system_call_layer.opal # システムコール層
│   └── python_bootstrap_eliminator.opal # Python依存関係排除ツール
├── docs/                 # ドキュメント
├── examples/             # サンプルコード
├── benchmark/            # ベンチマークスイート
├── visualization/        # 可視化ツール
└── language_comparison/  # 言語比較ツール
```

### 3.2 主要ファイルの説明

- **lexer.opal**: ソースコードをトークン列に変換するレキサー
- **parser.opal**: トークン列からASTを構築するパーサー
- **code_generator.opal**: ASTから実行可能コードを生成するコード生成器
- **system_call_layer.opal**: OSとの直接通信を行うシステムコール層
- **python_bootstrap_eliminator.opal**: Python依存関係を排除するツール

## 4. 自己ホスティングの仕組み

### 4.1 ブートストラッププロセス

Opal言語の自己ホスティング実装は、以下のステップでブートストラップされます。

1. 初期コンパイラ（pure_opal_bootstrap.opal）がOpalコードをコンパイル
2. コンパイルされたコードが新しいコンパイラを生成
3. 新しいコンパイラが自身をコンパイルして最終的なコンパイラを生成

### 4.2 エントリーポイント

Opal言語では、`first`関数がプログラムのエントリーポイントとして使用されます。

```opal
function first() -> Integer then
    // プログラムの開始点
    return 0;
end
```

### 4.3 Python依存関係の排除

Python依存関係の排除は、以下のステップで行われます。

1. Python依存関係検出ツールがコードベース内のPython依存を特定
2. 依存関係排除ツールが依存を純粋なOpal実装に置き換え
3. 置換されたコードが新しいコンパイラでコンパイルされる

## 5. システムコール層の実装

### 5.1 低レベルシステムコール

システムコール層は、x86-64アーキテクチャのLinuxシステムコールを直接呼び出すための関数を提供します。

```opal
function syscall0(syscall_number: Integer) -> Integer then
    // 引数なしのシステムコール
end

function syscall1(syscall_number: Integer, arg1: Integer) -> Integer then
    // 引数1つのシステムコール
end

// syscall2, syscall3, ...
```

### 5.2 ファイル操作

ファイル操作関数は、低レベルシステムコールをラップして使いやすいインターフェースを提供します。

```opal
function open(filename: String, flags: Integer, mode: Integer) -> Integer then
    // ファイルを開く
end

function read(fd: Integer, buffer: Pointer, count: Integer) -> Integer then
    // ファイルから読み込む
end

function write(fd: Integer, buffer: Pointer, count: Integer) -> Integer then
    // ファイルに書き込む
end
```

### 5.3 メモリ管理

メモリ管理関数は、メモリの割り当てと解放を行います。

```opal
function mmap(addr: Pointer, length: Integer, prot: Integer, flags: Integer, fd: Integer, offset: Integer) -> Pointer then
    // メモリマッピング
end

function munmap(addr: Pointer, length: Integer) -> Integer then
    // メモリマッピング解除
end
```

## 6. コンパイラの実装

### 6.1 レキサー

レキサーは、ソースコードを字句解析してトークン列に変換します。

```opal
module Lexer then
    function tokenize(source: String) -> Array<Token> then
        // ソースコードをトークン列に変換
    end
end
```

### 6.2 パーサー

パーサーは、トークン列を構文解析して抽象構文木（AST）を構築します。

```opal
module Parser then
    function parse(tokens: Array<Token>) -> ASTNode then
        // トークン列からASTを構築
    end
end
```

### 6.3 コード生成器

コード生成器は、ASTから実行可能コードを生成します。

```opal
module CodeGenerator then
    function generate(ast: ASTNode) -> String then
        // ASTから実行可能コードを生成
    end
end
```

## 7. 言語仕様の実装

### 7.1 「nc」キーワードの統一

Opal言語では、変数宣言に「nc」キーワードを使用します。これは「not changeable」の略で、変数が不変（immutable）であることを示します。

```opal
// レキサーでのトークン定義
nc NC_TOKEN <- 1001;

// パーサーでの変数宣言解析
function parse_variable_declaration() -> ASTNode then
    expect(NC_TOKEN);
    nc identifier <- parse_identifier();
    expect(ASSIGN_TOKEN);
    nc initializer <- parse_expression();
    return new VariableDeclarationNode(identifier, initializer);
end
```

### 7.2 first関数エントリーポイント

Opal言語では、`first`関数がプログラムのエントリーポイントとして使用されます。

```opal
// エントリーポイント検出
function find_entry_point(ast: ASTNode) -> FunctionNode then
    for each function in ast.functions do
        if function.name == "first" then
            return function;
        end
    end
    error("No entry point found: function 'first' is missing");
end
```

## 8. テスト戦略

### 8.1 単体テスト

各コンポーネント（レキサー、パーサー、コード生成器など）の単体テストを実装しています。

```opal
function test_lexer() -> Boolean then
    nc source <- "nc x <- 10;";
    nc tokens <- Lexer.tokenize(source);
    assert(tokens.length == 5);
    assert(tokens[0].type == NC_TOKEN);
    // ...
end
```

### 8.2 統合テスト

コンパイラ全体の統合テストを実装しています。

```opal
function test_compiler() -> Boolean then
    nc source <- "module Test then function first() -> Integer then return 42; end end";
    nc result <- compile_and_run(source);
    assert(result == 42);
end
```

### 8.3 自己ホスティングテスト

コンパイラが自身をコンパイルできることを確認するテストを実装しています。

```opal
function test_self_hosting() -> Boolean then
    nc compiler_source <- read_file("src/compiler.opal");
    nc result <- compile(compiler_source);
    assert(result.success);
end
```

## 9. パフォーマンス最適化

### 9.1 コンパイル時最適化

コンパイル時に以下の最適化を行っています。

- 定数畳み込み
- 不要なコード除去
- ループ最適化

### 9.2 実行時最適化

実行時に以下の最適化を行っています。

- インライン展開
- テールコール最適化
- メモリ使用量最適化

### 9.3 ベンチマーク駆動開発

パフォーマンス改善のために、ベンチマーク駆動開発を採用しています。

1. ベースラインパフォーマンスを測定
2. 最適化を実装
3. パフォーマンスの変化を測定
4. 結果に基づいて最適化を調整

## 10. 今後の開発計画

### 10.1 短期目標

- クロスプラットフォーム対応の強化
- エラーメッセージの改善
- デバッグ情報の生成

### 10.2 中期目標

- JITコンパイラの実装
- 並列処理のサポート強化
- 標準ライブラリの拡充

### 10.3 長期目標

- 完全な自己最適化コンパイラの実装
- 他の言語とのインターオペラビリティ
- 分散システム向け機能の強化

## 11. コントリビューションガイド

### 11.1 コーディング規約

- インデントは4スペース
- 関数名はlower_snake_case
- モジュール名はPascalCase
- コメントは日本語または英語で記述

### 11.2 プルリクエストプロセス

1. イシューを作成して変更内容を説明
2. フォークしてブランチを作成
3. 変更を実装してテストを追加
4. プルリクエストを作成

### 11.3 レビュープロセス

- コードレビューは少なくとも1人の承認が必要
- すべてのテストがパスする必要がある
- コーディング規約に準拠している必要がある

## 12. 付録

### 12.1 システムコール番号一覧

Linux x86-64アーキテクチャのシステムコール番号一覧です。

| 番号 | 名前 | 説明 |
|------|------|------|
| 0 | read | ファイルディスクリプタから読み込み |
| 1 | write | ファイルディスクリプタに書き込み |
| 2 | open | ファイルを開く |
| 3 | close | ファイルディスクリプタを閉じる |
| ... | ... | ... |

### 12.2 トークン種別一覧

レキサーで使用されるトークン種別の一覧です。

| 種別 | 値 | 説明 |
|------|------|------|
| NC_TOKEN | 1001 | 変数宣言キーワード「nc」 |
| FUNCTION_TOKEN | 1002 | 関数定義キーワード「function」 |
| MODULE_TOKEN | 1003 | モジュール定義キーワード「module」 |
| THEN_TOKEN | 1004 | ブロック開始キーワード「then」 |
| END_TOKEN | 1005 | ブロック終了キーワード「end」 |
| ... | ... | ... |

### 12.3 参考資料

- Opal言語仕様書: `docs/language_specification.md`
- システムコールリファレンス: `docs/syscall_reference.md`
- コンパイラ設計ドキュメント: `docs/compiler_design.md`
