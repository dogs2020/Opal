# Opal言語仕様書

## 1. 概要

Opal言語は、純粋性と一貫性を重視した新しいプログラミング言語です。本仕様書では、Opal言語の構文、セマンティクス、および主要な機能について詳細に説明します。

## 2. 字句構造

### 2.1 トークン

Opal言語のソースコードは、以下のトークンに分解されます。

- 識別子
- キーワード
- リテラル
- 演算子
- 区切り記号

### 2.2 識別子

識別子は、アルファベット（a-z, A-Z）またはアンダースコア（_）で始まり、その後にアルファベット、数字（0-9）、またはアンダースコアが続く文字列です。

```
identifier = [a-zA-Z_][a-zA-Z0-9_]*
```

### 2.3 キーワード

以下のキーワードは予約語であり、識別子として使用することはできません。

```
module, function, nc, if, else, then, end, while, for, do, return, true, false, null
```

### 2.4 リテラル

#### 2.4.1 整数リテラル

整数リテラルは、10進数、16進数、8進数、2進数で表現できます。

```
decimal_integer = [0-9]+
hex_integer = 0x[0-9a-fA-F]+
octal_integer = 0o[0-7]+
binary_integer = 0b[01]+
```

#### 2.4.2 浮動小数点リテラル

浮動小数点リテラルは、小数点または指数表記で表現できます。

```
float = [0-9]+\.[0-9]+([eE][+-]?[0-9]+)?
```

#### 2.4.3 文字列リテラル

文字列リテラルは、ダブルクォート（"）で囲まれた文字列です。

```
string = "[^"]*"
```

エスケープシーケンスとして、以下が使用できます。

- `\"` - ダブルクォート
- `\\` - バックスラッシュ
- `\n` - 改行
- `\t` - タブ
- `\r` - キャリッジリターン

#### 2.4.4 ブール値リテラル

ブール値リテラルは、`true`または`false`です。

#### 2.4.5 null値リテラル

null値リテラルは、`null`です。

### 2.5 演算子

#### 2.5.1 算術演算子

- `+` - 加算
- `-` - 減算
- `*` - 乗算
- `/` - 除算
- `%` - 剰余

#### 2.5.2 比較演算子

- `==` - 等しい
- `!=` - 等しくない
- `<` - より小さい
- `>` - より大きい
- `<=` - 以下
- `>=` - 以上

#### 2.5.3 論理演算子

- `&&` - 論理積（AND）
- `||` - 論理和（OR）
- `!` - 論理否定（NOT）

#### 2.5.4 代入演算子

- `<-` - 代入

### 2.6 区切り記号

- `(` `)` - 括弧
- `{` `}` - 中括弧
- `[` `]` - 角括弧
- `,` - カンマ
- `;` - セミコロン
- `:` - コロン
- `->` - 矢印

### 2.7 コメント

単一行コメントは、`//`で始まり、行末まで続きます。

```
// これは単一行コメントです
```

複数行コメントは、`/*`で始まり、`*/`で終わります。

```
/*
 これは
 複数行コメント
 です
*/
```

## 3. 構文

### 3.1 プログラム構造

Opal言語のプログラムは、1つ以上のモジュール定義で構成されます。

```
program = module_definition+
```

### 3.2 モジュール定義

モジュールは、関連する関数と型の集合です。

```
module_definition = "module" identifier "then" module_body "end"
module_body = (function_definition | type_definition)*
```

### 3.3 関数定義

関数は、名前、パラメータリスト、戻り値の型、および本体で構成されます。

```
function_definition = "function" identifier "(" parameter_list? ")" "->" type "then" function_body "end"
parameter_list = parameter ("," parameter)*
parameter = identifier ":" type
function_body = statement*
```

### 3.4 型定義

型は、名前とメンバーで構成されます。

```
type_definition = "type" identifier "then" type_body "end"
type_body = (field_definition | method_definition)*
field_definition = identifier ":" type ";"
method_definition = function_definition
```

### 3.5 変数宣言

変数は、`nc`キーワードを使用して宣言します。

```
variable_declaration = "nc" identifier "<-" expression ";"
```

### 3.6 制御構造

#### 3.6.1 if文

if文は、条件に基づいて実行するコードブロックを選択します。

```
if_statement = "if" expression "then" statement* ("else" "if" expression "then" statement*)* ("else" statement*)? "end"
```

#### 3.6.2 while文

while文は、条件が真である間、コードブロックを繰り返し実行します。

```
while_statement = "while" expression "do" statement* "end"
```

#### 3.6.3 for文

for文は、指定された範囲の値に対して、コードブロックを繰り返し実行します。

```
for_statement = "for" identifier "<-" expression "to" expression "do" statement* "end"
```

### 3.7 式

式は、値を生成するコードの一部です。

```
expression = literal | identifier | binary_expression | unary_expression | function_call | array_access | member_access | "(" expression ")"
```

#### 3.7.1 バイナリ式

バイナリ式は、2つの式を演算子で結合します。

```
binary_expression = expression operator expression
```

#### 3.7.2 ユナリ式

ユナリ式は、1つの式に演算子を適用します。

```
unary_expression = operator expression
```

#### 3.7.3 関数呼び出し

関数呼び出しは、関数名と引数リストで構成されます。

```
function_call = identifier "(" argument_list? ")"
argument_list = expression ("," expression)*
```

#### 3.7.4 配列アクセス

配列アクセスは、配列名とインデックスで構成されます。

```
array_access = identifier "[" expression "]"
```

#### 3.7.5 メンバーアクセス

メンバーアクセスは、オブジェクト名とメンバー名で構成されます。

```
member_access = expression "." identifier
```

### 3.8 文

文は、プログラムの実行単位です。

```
statement = variable_declaration | if_statement | while_statement | for_statement | return_statement | expression_statement
```

#### 3.8.1 return文

return文は、関数から値を返します。

```
return_statement = "return" expression? ";"
```

#### 3.8.2 式文

式文は、式の後にセミコロンが続く文です。

```
expression_statement = expression ";"
```

## 4. セマンティクス

### 4.1 型システム

Opal言語は、静的型付け言語です。すべての変数と式には、コンパイル時に型が割り当てられます。

#### 4.1.1 基本型

- `Integer` - 整数型
- `Float` - 浮動小数点型
- `Boolean` - ブール型
- `String` - 文字列型
- `Null` - null型

#### 4.1.2 複合型

- `Array<T>` - 要素型Tの配列
- `Map<K, V>` - キー型Kと値型Vのマップ
- ユーザー定義型

### 4.2 変数

変数は、`nc`キーワードを使用して宣言します。変数は不変（immutable）であり、一度値が代入されると変更できません。

```opal
nc x <- 10;  // 整数型の変数
nc name <- "Opal";  // 文字列型の変数
```

### 4.3 関数

関数は、名前、パラメータリスト、戻り値の型、および本体で構成されます。関数は、`return`文を使用して値を返します。

```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end
```

### 4.4 エントリーポイント

Opal言語のプログラムは、`first`関数から実行が開始されます。

```opal
function first() -> Integer then
    // プログラムの開始点
    return 0;
end
```

### 4.5 モジュール

モジュールは、関連する関数と型の集合です。モジュールは、名前空間として機能します。

```opal
module Mathematics then
    function square(x: Integer) -> Integer then
        return x * x;
    end
end
```

### 4.6 スコープ

変数のスコープは、宣言されたブロック内に限定されます。内部ブロックは、外部ブロックの変数にアクセスできますが、外部ブロックは内部ブロックの変数にアクセスできません。

```opal
function example() -> Integer then
    nc x <- 10;
    
    if x > 5 then
        nc y <- 20;  // yのスコープはif文のブロック内
        return x + y;  // x + y = 30
    end
    
    return x;  // yはここではアクセスできない
end
```

## 5. 標準ライブラリ

### 5.1 システムコール層

システムコール層は、OSとの直接通信を行うための関数を提供します。

#### 5.1.1 ファイル操作

```opal
// ファイル読み込み
function read_file(filename: String) -> String

// ファイル書き込み
function write_file(filename: String, content: String) -> Boolean

// ファイル存在確認
function file_exists(filename: String) -> Boolean

// ファイルサイズ取得
function file_size(filename: String) -> Integer
```

#### 5.1.2 プロセス管理

```opal
// コマンド実行
function system(command: String) -> Integer

// プロセス生成
function fork() -> Integer

// プロセス終了
function exit(status: Integer) -> Null
```

#### 5.1.3 時間関連

```opal
// 現在時刻の取得
function time() -> Integer

// ミリ秒単位の現在時刻
function time_ms() -> Integer

// スリープ
function sleep_ms(milliseconds: Integer) -> Null
```

### 5.2 文字列操作

```opal
// 文字列長の取得
function string_length(str: String) -> Integer

// 部分文字列の取得
function substring(str: String, start: Integer, length: Integer) -> String

// 文字列の結合
function concat(str1: String, str2: String) -> String

// 文字列の分割
function split(str: String, delimiter: String) -> Array<String>
```

### 5.3 配列操作

```opal
// 配列の長さ取得
function array_length(array: Array<T>) -> Integer

// 配列の要素取得
function array_get(array: Array<T>, index: Integer) -> T

// 配列の要素設定
function array_set(array: Array<T>, index: Integer, value: T) -> Array<T>

// 配列の結合
function array_concat(array1: Array<T>, array2: Array<T>) -> Array<T>
```

### 5.4 数学関数

```opal
// 絶対値
function abs(x: Integer) -> Integer

// 最大値
function max(a: Integer, b: Integer) -> Integer

// 最小値
function min(a: Integer, b: Integer) -> Integer

// 平方根
function sqrt(x: Float) -> Float
```

## 6. 例

### 6.1 Hello, World!

```opal
module HelloWorld then
    function first() -> Integer then
        OpalSystemCall.println("Hello, World!");
        return 0;
    end
end
```

### 6.2 フィボナッチ数列

```opal
module Fibonacci then
    function first() -> Integer then
        nc n <- 10;
        OpalSystemCall.println("Fibonacci(" + n + ") = " + fibonacci(n));
        return 0;
    end
    
    function fibonacci(n: Integer) -> Integer then
        if n <= 1 then
            return n;
        end
        return fibonacci(n - 1) + fibonacci(n - 2);
    end
end
```

### 6.3 クイックソート

```opal
module QuickSort then
    function first() -> Integer then
        nc array <- [5, 3, 8, 4, 2, 1, 9, 7, 6];
        quicksort(array, 0, array_length(array) - 1);
        
        for i <- 0 to array_length(array) - 1 do
            OpalSystemCall.print(array_get(array, i) + " ");
        end
        OpalSystemCall.println("");
        
        return 0;
    end
    
    function quicksort(array: Array<Integer>, low: Integer, high: Integer) -> Null then
        if low < high then
            nc pivot_index <- partition(array, low, high);
            quicksort(array, low, pivot_index - 1);
            quicksort(array, pivot_index + 1, high);
        end
    end
    
    function partition(array: Array<Integer>, low: Integer, high: Integer) -> Integer then
        nc pivot <- array_get(array, high);
        nc i <- low - 1;
        
        for j <- low to high - 1 do
            if array_get(array, j) <= pivot then
                i <- i + 1;
                swap(array, i, j);
            end
        end
        
        swap(array, i + 1, high);
        return i + 1;
    end
    
    function swap(array: Array<Integer>, i: Integer, j: Integer) -> Null then
        nc temp <- array_get(array, i);
        array_set(array, i, array_get(array, j));
        array_set(array, j, temp);
    end
end
```

## 7. 文法（EBNF）

```ebnf
program = module_definition+

module_definition = "module" identifier "then" module_body "end"
module_body = (function_definition | type_definition)*

function_definition = "function" identifier "(" parameter_list? ")" "->" type "then" function_body "end"
parameter_list = parameter ("," parameter)*
parameter = identifier ":" type
function_body = statement*

type_definition = "type" identifier "then" type_body "end"
type_body = (field_definition | method_definition)*
field_definition = identifier ":" type ";"
method_definition = function_definition

variable_declaration = "nc" identifier "<-" expression ";"

if_statement = "if" expression "then" statement* ("else" "if" expression "then" statement*)* ("else" statement*)? "end"
while_statement = "while" expression "do" statement* "end"
for_statement = "for" identifier "<-" expression "to" expression "do" statement* "end"

expression = literal | identifier | binary_expression | unary_expression | function_call | array_access | member_access | "(" expression ")"
binary_expression = expression operator expression
unary_expression = operator expression
function_call = identifier "(" argument_list? ")"
argument_list = expression ("," expression)*
array_access = identifier "[" expression "]"
member_access = expression "." identifier

statement = variable_declaration | if_statement | while_statement | for_statement | return_statement | expression_statement
return_statement = "return" expression? ";"
expression_statement = expression ";"

literal = integer_literal | float_literal | string_literal | boolean_literal | null_literal
integer_literal = decimal_integer | hex_integer | octal_integer | binary_integer
decimal_integer = [0-9]+
hex_integer = "0x" [0-9a-fA-F]+
octal_integer = "0o" [0-7]+
binary_integer = "0b" [01]+
float_literal = [0-9]+ "." [0-9]+ ([eE] [+-]? [0-9]+)?
string_literal = "\"" [^"]* "\""
boolean_literal = "true" | "false"
null_literal = "null"

identifier = [a-zA-Z_] [a-zA-Z0-9_]*
type = identifier | array_type | map_type
array_type = "Array" "<" type ">"
map_type = "Map" "<" type "," type ">"

operator = "+" | "-" | "*" | "/" | "%" | "==" | "!=" | "<" | ">" | "<=" | ">=" | "&&" | "||" | "!" | "<-"
```

## 8. 付録

### 8.1 予約語一覧

```
module, function, nc, if, else, then, end, while, for, do, return, true, false, null
```

### 8.2 演算子優先順位

| 優先順位 | 演算子 | 結合性 |
|---------|-------|-------|
| 1 | `!` | 右から左 |
| 2 | `*`, `/`, `%` | 左から右 |
| 3 | `+`, `-` | 左から右 |
| 4 | `<`, `>`, `<=`, `>=` | 左から右 |
| 5 | `==`, `!=` | 左から右 |
| 6 | `&&` | 左から右 |
| 7 | `\|\|` | 左から右 |
| 8 | `<-` | 右から左 |

### 8.3 エスケープシーケンス

| エスケープシーケンス | 意味 |
|-------------------|------|
| `\"` | ダブルクォート |
| `\\` | バックスラッシュ |
| `\n` | 改行 |
| `\t` | タブ |
| `\r` | キャリッジリターン |
