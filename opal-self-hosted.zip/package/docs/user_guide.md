# Opal自己ホスティング実装 - ユーザーガイド

## 1. はじめに

Opal言語は、純粋性と一貫性を重視した新しいプログラミング言語です。この自己ホスティング実装は、Python依存関係を完全に排除し、Opal言語自身でコンパイラを実装することで、真の意味での独立した言語環境を実現しています。

本ドキュメントでは、Opal自己ホスティング実装のインストール方法、使用方法、および主要な機能について説明します。

## 2. インストール

### 2.1 システム要件

- Linux、macOS、またはWindows（WSL推奨）
- 最小メモリ: 2GB RAM
- ディスク容量: 100MB以上

### 2.2 インストール手順

1. パッケージを解凍します。
   ```
   unzip opal-self-hosted.zip
   cd opal-self-hosted
   ```

2. インストールスクリプトを実行します。
   ```
   ./install.sh
   ```

3. 環境変数を設定します。
   ```
   echo "source $HOME/opal-self-hosted/env.sh" >> ~/.bashrc
   source ~/.bashrc
   ```

4. インストールを確認します。
   ```
   opal --version
   ```

## 3. 基本的な使用方法

### 3.1 Opalプログラムの実行

Opalプログラムを実行するには、`opal`コマンドを使用します。

```
opal examples/hello_world.opal
```

### 3.2 コマンドライン引数の渡し方

Opalプログラムにコマンドライン引数を渡すには、ファイル名の後に引数を指定します。

```
opal examples/command_line_args.opal arg1 arg2 arg3
```

### 3.3 主要なコマンド

| コマンド | 説明 |
|---------|------|
| `opal <ファイル名>` | Opalファイルをコンパイルして実行 |
| `opal-benchmark` | ベンチマークスイートを実行 |
| `opal-visualize` | パフォーマンス可視化ツールを起動 |
| `opal-compare` | 言語間パフォーマンス比較を実行 |

## 4. 言語仕様

### 4.1 基本構文

Opal言語の基本構文は以下の通りです。

```opal
module MyModule then
    // モジュール定義

    function first() -> Integer then
        // プログラムのエントリーポイント
        OpalSystemCall.println("Hello, World!");
        return 0;
    end

    function fibonacci(n: Integer) -> Integer then
        // 再帰関数の例
        if n <= 1 then
            return n;
        end
        return fibonacci(n - 1) + fibonacci(n - 2);
    end
end
```

### 4.2 変数宣言

変数は`nc`キーワードを使用して宣言します。`nc`は「not changeable」の略で、変数が不変（immutable）であることを示します。

```opal
nc x <- 10;  // 整数型の変数
nc name <- "Opal";  // 文字列型の変数
nc values <- [1, 2, 3, 4, 5];  // 配列
```

### 4.3 制御構造

条件分岐と繰り返しの構文は以下の通りです。

```opal
// if文
if condition then
    // 条件が真の場合の処理
else if another_condition then
    // 別の条件が真の場合の処理
else
    // どの条件も真でない場合の処理
end

// while文
while condition do
    // 繰り返し処理
end

// for文
for i <- 0 to 10 do
    // 繰り返し処理
end
```

### 4.4 関数定義

関数は`function`キーワードを使用して定義します。

```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end
```

### 4.5 モジュールシステム

モジュールは`module`キーワードを使用して定義します。

```opal
module Mathematics then
    function square(x: Integer) -> Integer then
        return x * x;
    end
end
```

## 5. システムコール層

Opal自己ホスティング実装では、OSとの直接通信を行うシステムコール層を提供しています。これにより、Python依存関係なしでファイル操作やプロセス管理などの機能を利用できます。

### 5.1 ファイル操作

```opal
// ファイル読み込み
nc file_content <- OpalSystemCall.read_file("example.txt");

// ファイル書き込み
OpalSystemCall.write_file("output.txt", "Hello, Opal!");
```

### 5.2 プロセス管理

```opal
// コマンド実行
nc result <- OpalSystemCall.system("ls -la");

// プロセス生成
nc pid <- OpalSystemCall.fork();
if pid == 0 then
    // 子プロセスの処理
else
    // 親プロセスの処理
end
```

### 5.3 時間関連機能

```opal
// 現在時刻の取得
nc current_time <- OpalSystemCall.time();

// スリープ
OpalSystemCall.sleep_ms(1000);  // 1秒間スリープ
```

## 6. ベンチマークスイート

Opal自己ホスティング実装には、パフォーマンス評価のためのベンチマークスイートが含まれています。

### 6.1 ベンチマークの実行

```
opal-benchmark
```

特定のベンチマークのみを実行する場合：

```
opal-benchmark fibonacci
```

カテゴリ別にベンチマークを実行する場合：

```
opal-benchmark -c computation
```

### 6.2 ベンチマークカテゴリ

- **計算集約型**: フィボナッチ数列、素数計算、行列乗算
- **メモリ集約型**: 大規模配列操作、ツリー構造操作、ハッシュマップ操作
- **I/O集約型**: ファイル読み書き、ディレクトリ走査
- **アルゴリズム**: クイックソート、ダイクストラ最短経路、文字列処理
- **並行処理**: プロセス生成と通信

## 7. 言語比較ツール

Opal言語と他のプログラミング言語（JavaScript、Python、Rust）のパフォーマンスを比較するためのツールが用意されています。

### 7.1 比較の実行

```
opal-compare opal javascript fibonacci
```

すべての言語とベンチマークで比較を実行する場合：

```
opal-compare -a
```

### 7.2 比較結果の可視化

比較結果を可視化するには、以下のコマンドを実行します。

```
opal-visualize
```

これにより、ブラウザが開き、グラフィカルな比較結果が表示されます。

## 8. トラブルシューティング

### 8.1 一般的な問題と解決策

- **「コマンドが見つかりません」エラー**
  環境変数が正しく設定されているか確認してください。
  ```
  source $HOME/opal-self-hosted/env.sh
  ```

- **実行権限エラー**
  バイナリに実行権限があるか確認してください。
  ```
  chmod +x $HOME/opal-self-hosted/bin/*
  ```

- **メモリ不足エラー**
  大きなベンチマークを実行する場合は、十分なメモリがあることを確認してください。

### 8.2 サポートとフィードバック

問題が解決しない場合や、フィードバックがある場合は、GitHubリポジトリのIssueセクションに報告してください。

## 9. 付録

### 9.1 サンプルプログラム

以下のサンプルプログラムが`examples`ディレクトリに用意されています。

- `hello_world.opal`: 基本的な「Hello, World!」プログラム
- `fibonacci.opal`: フィボナッチ数列の計算
- `quicksort.opal`: クイックソートアルゴリズムの実装
- `command_line_args.opal`: コマンドライン引数の処理

### 9.2 参考資料

- Opal言語仕様書: `docs/language_specification.md`
- 実装詳細: `docs/implementation_details.md`
- ベンチマーク詳細: `docs/benchmark_details.md`
