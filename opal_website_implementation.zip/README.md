# Opal言語ウェブサイト実装

このプロジェクトは、Opal言語を使用してベンチマークウェブサイトを実装したものです。

## 概要

Opal言語の特性を活かし、ウェブサーバーとHTMLコンテンツ生成を完全にOpal言語で実装しています。このプロジェクトでは、以下の機能を実装しています：

1. HTTPサーバーの基本構造
2. リクエスト・レスポンスの処理
3. HTMLコンテンツの動的生成
4. ルーティング機能
5. ベンチマークデータの表示

## ファイル構造

- `opal_benchmark_website.opal`: メインのOpalソースコード

## 実装詳細

### HTTPサーバー

Opal言語でHTTPサーバーを実装し、クライアントからのリクエストを処理します。サーバーはポート8080でリッスンし、設定されたルートに基づいてレスポンスを返します。

```opal
class HttpServer then
    private var port: Int;
    private var routes: Map<String, (Request) -> Response>;
    
    function constructor(port: Int) -> Void then
        this.port = port;
        this.routes = Map<String, (Request) -> Response>.new();
    end
    
    function addRoute(path: String, handler: (Request) -> Response) -> Void then
        this.routes.put(path, handler);
    end
    
    function start() -> Void then
        OpalSystemCall.("Starting Opal Web Server on port " + this.port.toString()) => out;
        // 実際のサーバー起動コードはここに実装
    end
end
```

### HTMLビルダー

Opal言語でHTMLコンテンツを動的に生成するためのユーティリティクラスを実装しています。

```opal
class HtmlBuilder then
    private var content: String;
    
    function constructor() -> Void then
        this.content = "";
    end
    
    function addElement(tag: String, content: String, attributes: Map<String, String>) -> Void then
        var attributeStr = "";
        for (key, value) in attributes then
            attributeStr = attributeStr + " " + key + "=\"" + value + "\"";
        end
        
        this.content = this.content + "<" + tag + attributeStr + ">" + content + "</" + tag + ">";
    end
    
    function addRawHtml(html: String) -> Void then
        this.content = this.content + html;
    end
    
    function toString() -> String then
        return this.content;
    end
end
```

### ページ生成

各ページのコンテンツはOpal言語で動的に生成されます。例えば、ホームページは以下のように生成されます：

```opal
function createHomePage() -> String then
    var html = OpalWebServer.HtmlBuilder.new();
    
    // HTML5ドキュメント構造
    html.addRawHtml("<!DOCTYPE html>");
    html.addRawHtml("<html lang=\"ja\">");
    
    // ヘッド部分
    html.addRawHtml("<head>");
    // ...
    html.addRawHtml("</head>");
    
    // ボディ部分
    html.addRawHtml("<body>");
    // ...
    html.addRawHtml("</body>");
    html.addRawHtml("</html>");
    
    return html.toString();
end
```

## 実行方法

Opalコンパイラを使用してコードをコンパイルし、実行します：

```
opal compile opal_benchmark_website.opal
./opal_benchmark_website
```

その後、ブラウザで `http://localhost:8080` にアクセスすると、ウェブサイトが表示されます。

## 特徴

- **純粋なOpal実装**: フロントエンドとバックエンドの両方がOpal言語で実装されています
- **静的型付け**: Opal言語の静的型システムにより、実行時エラーを防止します
- **高性能**: Opal言語の高速な実行性能により、効率的なウェブサーバーを実現しています
- **モジュール化**: コードは機能ごとにモジュール化され、保守性が高くなっています

## 今後の拡張

- データベース連携機能の追加
- ユーザー認証システムの実装
- リアルタイムベンチマーク実行機能の追加
- レスポンシブデザインの強化
