# Opal言語 - 完全実装パッケージ

このパッケージには、Opal言語の完全な実装が含まれています。Opal言語は高性能で安全なプログラミング言語であり、科学計算、Web開発、金融分析、深層学習など様々な分野で利用できます。

## インストール方法

1. パッケージを任意のディレクトリに展開します。
2. 環境変数を設定します：

```bash
export OPAL_HOME=/path/to/opal_complete_package_updated
export PATH=$OPAL_HOME/bin:$PATH
export LD_LIBRARY_PATH=$OPAL_HOME/lib:$LD_LIBRARY_PATH
```

3. インストールを確認します：

```bash
opal version
```

「Opal言語 バージョン 1.0.0」と表示されれば、インストールは成功です。

## 使用方法

### Opalプログラムのコンパイル

Opalプログラムをコンパイルするには、`opalc`コマンドを使用します：

```bash
opalc source.opal -o output
```

オプション：
- `-o [出力ファイル]` - 出力ファイル名を指定
- `-O[最適化レベル]` - 最適化レベルを指定 (0-3)
- `-v` - 詳細な出力を表示
- `-h` - ヘルプメッセージを表示

### Opalプログラムの実行

Opalプログラムを実行するには、`opal run`コマンドを使用します：

```bash
opal run program.opal
```

### 対話型実行環境（REPL）の起動

対話型実行環境を起動するには、`opal repl`コマンドを使用します：

```bash
opal repl
```

## Hello Worldプログラム

以下は、Opal言語での基本的なHello Worldプログラムの例です：

```opal
module HelloWorld then
    function first() -> Void then
        OpalSystemCall.("Hello, World!") -> out;
    end
end
```

このプログラムを`hello.opal`として保存し、以下のコマンドで実行できます：

```bash
opal run hello.opal
```

## ライブラリの使用

Opalには多数の標準ライブラリが含まれています。以下は、いくつかの主要なライブラリの使用例です：

### 深層学習ライブラリ

```opal
module NeuralNetworkExample then
    import OpalStdlib.DeepLearning.Tensor
    import OpalStdlib.DeepLearning.Layers
    import OpalStdlib.DeepLearning.Activations
    import OpalStdlib.DeepLearning.Optimizers
    
    function first() -> Void then
        // テンソルの作成
        nc x <- Tensor.randn([64, 10])
        nc y <- Tensor.randn([64, 5])
        
        // モデルの定義
        nc model <- Sequential()
        model.add(Dense(10, 20))
        model.add(ReLU())
        model.add(Dense(20, 5))
        
        // モデルのトレーニング
        nc optimizer <- Adam(0.01)
        nc loss <- MSELoss()
        
        for epoch <- 0 to 100 then
            nc output <- model.forward(x)
            nc l <- loss.forward(output, y)
            model.backward(loss.backward())
            optimizer.step()
            
            if epoch % 10 == 0 then
                OpalSystemCall.("Epoch " + epoch.toString() + ", Loss: " + l.toString()) => out
            end
        end
    end
end
```

### Web開発ライブラリ

```opal
module WebServerExample then
    import OpalStdlib.Web.Server.HttpServer
    import OpalStdlib.Web.Server.Routing
    
    function first() -> Void then
        nc server <- HttpServer(8080)
        nc router <- Router()
        
        router.get("/", function(req, res) -> Void then
            res.send("<h1>Hello from Opal Web Server!</h1>")
        end)
        
        router.get("/api/data", function(req, res) -> Void then
            nc data <- Map<String, String>()
            data.put("message", "Hello, World!")
            data.put("status", "success")
            
            res.json(data)
        end)
        
        server.useRouter(router)
        server.start()
        
        OpalSystemCall.("Server running at http://localhost:8080") => out
    end
end
```

### 金融データライブラリ

```opal
module FinanceExample then
    import OpalStdlib.Finance.Core.FinancialMath
    import OpalStdlib.Finance.Technical.Indicators
    import OpalStdlib.Finance.MarketData.TimeSeries
    
    function first() -> Void then
        // 時系列データの作成
        nc prices <- TimeSeries<Float64>()
        // データの追加...
        
        // テクニカル指標の計算
        nc indicators <- Indicators()
        nc sma <- indicators.sma(prices, 20)
        nc rsi <- indicators.rsi(prices, 14)
        
        // 結果の表示
        OpalSystemCall.("SMA(20): " + sma.getLatest().toString()) => out
        OpalSystemCall.("RSI(14): " + rsi.getLatest().toString()) => out
    end
end
```

## ディレクトリ構造

- `bin/` - 実行可能ファイル（opal, opalc）
- `lib/` - ライブラリファイル
- `src/` - ソースコード
  - `compiler/` - コンパイラのソースコード
  - `stdlib/` - 標準ライブラリのソースコード
  - `runtime/` - ランタイムのソースコード
  - `jit/` - JITコンパイラのソースコード
  - `optimizer/` - 最適化パイプラインのソースコード
  - `hal/` - ハードウェア抽象化層のソースコード
- `docs/` - ドキュメント
- `examples/` - サンプルプログラム
- `tests/` - テストスイート

## ライセンス

Opal言語は、オープンソースソフトウェアとして提供されています。詳細については、LICENSEファイルを参照してください。

## サポート

問題や質問がある場合は、以下の方法でサポートを受けることができます：

- GitHub Issues: https://github.com/opal-lang/opal/issues
- メーリングリスト: support@opal-lang.org
- ドキュメント: https://docs.opal-lang.org

---

© 2025 Opal言語開発チーム
