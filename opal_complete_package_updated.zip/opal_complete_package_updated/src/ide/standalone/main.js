const { app, BrowserWindow, Menu, dialog, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

// グローバル変数として保持するメインウィンドウ
let mainWindow;

// アプリケーションの設定を保存するパス
const userDataPath = app.getPath('userData');
const configPath = path.join(userDataPath, 'config.json');

// デフォルト設定
let config = {
  recentProjects: [],
  opalPath: 'opal', // Opalコンパイラへのパス
  theme: 'light',
  fontSize: 14,
  tabSize: 4,
  autoSave: true
};

// 設定の読み込み
function loadConfig() {
  try {
    if (fs.existsSync(configPath)) {
      const data = fs.readFileSync(configPath, 'utf8');
      const loadedConfig = JSON.parse(data);
      config = { ...config, ...loadedConfig };
    }
  } catch (err) {
    console.error('設定の読み込みに失敗しました:', err);
  }
}

// 設定の保存
function saveConfig() {
  try {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
  } catch (err) {
    console.error('設定の保存に失敗しました:', err);
  }
}

// アプリケーションの初期化
function createWindow() {
  // メインウィンドウの作成
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.join(__dirname, 'assets/icons/opal-icon.png')
  });

  // メインページの読み込み
  mainWindow.loadFile(path.join(__dirname, 'renderer/index.html'));

  // 開発ツールを開く（開発時のみ）
  // mainWindow.webContents.openDevTools();

  // ウィンドウが閉じられたときの処理
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // メニューの作成
  createMenu();
}

// メニューの作成
function createMenu() {
  const template = [
    {
      label: 'ファイル',
      submenu: [
        {
          label: '新規プロジェクト',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            mainWindow.webContents.send('menu-new-project');
          }
        },
        {
          label: '開く',
          accelerator: 'CmdOrCtrl+O',
          click: () => {
            openProject();
          }
        },
        {
          label: '最近使ったプロジェクト',
          submenu: buildRecentProjectsMenu()
        },
        { type: 'separator' },
        {
          label: '保存',
          accelerator: 'CmdOrCtrl+S',
          click: () => {
            mainWindow.webContents.send('menu-save');
          }
        },
        {
          label: '名前を付けて保存',
          accelerator: 'CmdOrCtrl+Shift+S',
          click: () => {
            mainWindow.webContents.send('menu-save-as');
          }
        },
        { type: 'separator' },
        {
          label: '設定',
          click: () => {
            mainWindow.webContents.send('menu-settings');
          }
        },
        { type: 'separator' },
        {
          label: '終了',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: '編集',
      submenu: [
        { role: 'undo', label: '元に戻す' },
        { role: 'redo', label: 'やり直す' },
        { type: 'separator' },
        { role: 'cut', label: '切り取り' },
        { role: 'copy', label: 'コピー' },
        { role: 'paste', label: '貼り付け' },
        { role: 'delete', label: '削除' },
        { type: 'separator' },
        { role: 'selectAll', label: 'すべて選択' },
        { type: 'separator' },
        {
          label: '検索',
          accelerator: 'CmdOrCtrl+F',
          click: () => {
            mainWindow.webContents.send('menu-find');
          }
        },
        {
          label: '置換',
          accelerator: 'CmdOrCtrl+H',
          click: () => {
            mainWindow.webContents.send('menu-replace');
          }
        }
      ]
    },
    {
      label: '表示',
      submenu: [
        {
          label: 'テーマ切替',
          click: () => {
            config.theme = config.theme === 'light' ? 'dark' : 'light';
            saveConfig();
            mainWindow.webContents.send('theme-changed', config.theme);
          }
        },
        { type: 'separator' },
        { role: 'reload', label: '再読み込み' },
        { role: 'forceReload', label: '強制再読み込み' },
        { role: 'toggleDevTools', label: '開発者ツール' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'ズームをリセット' },
        { role: 'zoomIn', label: 'ズームイン' },
        { role: 'zoomOut', label: 'ズームアウト' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'フルスクリーン' }
      ]
    },
    {
      label: 'プロジェクト',
      submenu: [
        {
          label: 'ビルド',
          accelerator: 'F7',
          click: () => {
            mainWindow.webContents.send('menu-build');
          }
        },
        {
          label: '実行',
          accelerator: 'F5',
          click: () => {
            mainWindow.webContents.send('menu-run');
          }
        },
        {
          label: 'デバッグ',
          accelerator: 'F9',
          click: () => {
            mainWindow.webContents.send('menu-debug');
          }
        },
        { type: 'separator' },
        {
          label: 'プロジェクト設定',
          click: () => {
            mainWindow.webContents.send('menu-project-settings');
          }
        }
      ]
    },
    {
      label: 'ツール',
      submenu: [
        {
          label: 'コード整形',
          accelerator: 'CmdOrCtrl+Shift+F',
          click: () => {
            mainWindow.webContents.send('menu-format-code');
          }
        },
        {
          label: 'リファクタリング',
          submenu: [
            {
              label: '変数名の変更',
              click: () => {
                mainWindow.webContents.send('menu-rename-variable');
              }
            },
            {
              label: '関数の抽出',
              click: () => {
                mainWindow.webContents.send('menu-extract-function');
              }
            }
          ]
        },
        { type: 'separator' },
        {
          label: 'パフォーマンス分析',
          click: () => {
            mainWindow.webContents.send('menu-performance-analysis');
          }
        }
      ]
    },
    {
      label: 'ヘルプ',
      submenu: [
        {
          label: 'Opalドキュメント',
          click: () => {
            mainWindow.webContents.send('menu-documentation');
          }
        },
        {
          label: 'APIリファレンス',
          click: () => {
            mainWindow.webContents.send('menu-api-reference');
          }
        },
        { type: 'separator' },
        {
          label: 'バージョン情報',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              title: 'Opal IDE',
              message: 'Opal IDE',
              detail: 'バージョン: 1.0.0\n© 2025 Opal言語開発チーム',
              buttons: ['OK']
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// 最近使ったプロジェクトのメニュー構築
function buildRecentProjectsMenu() {
  const recentProjects = config.recentProjects || [];
  
  if (recentProjects.length === 0) {
    return [{ label: '最近使ったプロジェクトはありません', enabled: false }];
  }
  
  return recentProjects.map(project => ({
    label: project.name,
    click: () => {
      openRecentProject(project.path);
    }
  }));
}

// プロジェクトを開く
function openProject() {
  dialog.showOpenDialog(mainWindow, {
    title: 'プロジェクトを開く',
    properties: ['openDirectory']
  }).then(result => {
    if (!result.canceled && result.filePaths.length > 0) {
      const projectPath = result.filePaths[0];
      openRecentProject(projectPath);
    }
  }).catch(err => {
    console.error('プロジェクトを開く際にエラーが発生しました:', err);
  });
}

// 最近使ったプロジェクトを開く
function openRecentProject(projectPath) {
  // プロジェクト情報を取得
  const projectName = path.basename(projectPath);
  
  // 最近使ったプロジェクトリストを更新
  const recentProjects = config.recentProjects || [];
  const existingIndex = recentProjects.findIndex(p => p.path === projectPath);
  
  if (existingIndex !== -1) {
    // 既存のプロジェクトを削除
    recentProjects.splice(existingIndex, 1);
  }
  
  // 新しいプロジェクトを先頭に追加
  recentProjects.unshift({
    name: projectName,
    path: projectPath
  });
  
  // 最大10件まで保持
  config.recentProjects = recentProjects.slice(0, 10);
  saveConfig();
  
  // メニューを更新
  createMenu();
  
  // プロジェクトを読み込む
  mainWindow.webContents.send('load-project', { name: projectName, path: projectPath });
}

// Opalファイルを実行
function runOpalFile(filePath) {
  return new Promise((resolve, reject) => {
    const opalProcess = spawn(config.opalPath, [filePath]);
    
    let stdout = '';
    let stderr = '';
    
    opalProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    opalProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    opalProcess.on('close', (code) => {
      if (code === 0) {
        resolve(stdout);
      } else {
        reject(stderr || `プロセスはコード ${code} で終了しました`);
      }
    });
    
    opalProcess.on('error', (err) => {
      reject(`プロセスの起動に失敗しました: ${err.message}`);
    });
  });
}

// IPCイベントリスナーの設定
function setupIpcListeners() {
  // 設定の取得
  ipcMain.handle('get-config', () => {
    return config;
  });
  
  // 設定の保存
  ipcMain.on('save-config', (event, newConfig) => {
    config = { ...config, ...newConfig };
    saveConfig();
  });
  
  // ファイルを開く
  ipcMain.handle('open-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'ファイルを開く',
      filters: [
        { name: 'Opalファイル', extensions: ['opal'] },
        { name: 'すべてのファイル', extensions: ['*'] }
      ],
      properties: ['openFile']
    });
    
    if (!result.canceled && result.filePaths.length > 0) {
      const filePath = result.filePaths[0];
      const content = fs.readFileSync(filePath, 'utf8');
      return { path: filePath, content };
    }
    
    return null;
  });
  
  // ファイルを保存
  ipcMain.handle('save-file', async (event, { path, content }) => {
    if (!path) {
      const result = await dialog.showSaveDialog(mainWindow, {
        title: 'ファイルを保存',
        filters: [
          { name: 'Opalファイル', extensions: ['opal'] },
          { name: 'すべてのファイル', extensions: ['*'] }
        ]
      });
      
      if (result.canceled) {
        return null;
      }
      
      path = result.filePath;
    }
    
    fs.writeFileSync(path, content, 'utf8');
    return path;
  });
  
  // Opalファイルを実行
  ipcMain.handle('run-opal-file', async (event, filePath) => {
    try {
      const output = await runOpalFile(filePath);
      return { success: true, output };
    } catch (error) {
      return { success: false, error: error.toString() };
    }
  });
  
  // 新規プロジェクト作成
  ipcMain.handle('create-project', async (event, { type, name }) => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'プロジェクトの作成場所を選択',
      properties: ['openDirectory']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
      return null;
    }
    
    const parentDir = result.filePaths[0];
    const projectPath = path.join(parentDir, name);
    
    // プロジェクトディレクトリが既に存在するか確認
    if (fs.existsSync(projectPath)) {
      const overwriteResult = await dialog.showMessageBox(mainWindow, {
        type: 'question',
        buttons: ['上書き', 'キャンセル'],
        title: '確認',
        message: `フォルダ "${name}" は既に存在します。上書きしますか？`
      });
      
      if (overwriteResult.response === 1) {
        return null;
      }
    } else {
      fs.mkdirSync(projectPath);
    }
    
    // プロジェクトタイプに応じたテンプレートを作成
    createProjectTemplate(projectPath, type, name);
    
    // 最近使ったプロジェクトに追加
    openRecentProject(projectPath);
    
    return { path: projectPath, name };
  });
}

// プロジェクトテンプレートの作成
function createProjectTemplate(projectPath, type, name) {
  // 共通ディレクトリ構造
  fs.mkdirSync(path.join(projectPath, 'src'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'docs'), { recursive: true });
  
  // プロジェクト設定ファイル
  const projectConfig = {
    name: name,
    version: '0.1.0',
    type: type,
    entryPoint: 'src/main.opal'
  };
  
  fs.writeFileSync(
    path.join(projectPath, 'project.json'),
    JSON.stringify(projectConfig, null, 2),
    'utf8'
  );
  
  // README.md
  fs.writeFileSync(
    path.join(projectPath, 'README.md'),
    `# ${name}\n\nOpal言語で作成された${getProjectTypeDescription(type)}プロジェクト。\n`,
    'utf8'
  );
  
  // プロジェクトタイプ別のテンプレート
  switch (type) {
    case 'console':
      createConsoleProjectTemplate(projectPath, name);
      break;
    case 'web':
      createWebProjectTemplate(projectPath, name);
      break;
    case 'mobile':
      createMobileProjectTemplate(projectPath, name);
      break;
    case 'library':
      createLibraryProjectTemplate(projectPath, name);
      break;
  }
}

// プロジェクトタイプの説明を取得
function getProjectTypeDescription(type) {
  switch (type) {
    case 'console': return 'コンソール';
    case 'web': return 'ウェブ';
    case 'mobile': return 'モバイル';
    case 'library': return 'ライブラリ';
    default: return '';
  }
}

// コンソールプロジェクトテンプレートの作成
function createConsoleProjectTemplate(projectPath, name) {
  const mainFilePath = path.join(projectPath, 'src', 'main.opal');
  const mainFileContent = `module ${name} then
    function first() -> Void then
        OpalSystemCall.("Hello, World from ${name}!") => out;
    end
end`;
  
  fs.writeFileSync(mainFilePath, mainFileContent, 'utf8');
}

// ウェブプロジェクトテンプレートの作成
function createWebProjectTemplate(projectPath, name) {
  // ディレクトリ構造
  fs.mkdirSync(path.join(projectPath, 'public'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'src', 'controllers'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'src', 'views'), { recursive: true });
  
  // メインファイル
  const mainFilePath = path.join(projectPath, 'src', 'main.opal');
  const mainFileContent = `module ${name} then
    import OpalStdlib.Web.Server
    import OpalStdlib.Web.Router
    
    function first() -> Void then
        nc server <- new Server(8080);
        nc router <- new Router();
        
        // ルートの定義
        router.get("/", function(req, res) -> Void then
            res.render("index", { title: "${name}" });
        end);
        
        // 静的ファイルの提供
        server.useStatic("public");
        
        // ルーターの設定
        server.use(router);
        
        // サーバーの起動
        OpalSystemCall.("サーバーを起動しました: http://localhost:8080") => out;
        server.start();
    end
end`;
  
  fs.writeFileSync(mainFilePath, mainFileContent, 'utf8');
  
  // インデックスビュー
  const indexViewPath = path.join(projectPath, 'src', 'views', 'index.opal');
  const indexViewContent = `module ${name}.Views.Index then
    function render(data) -> String then
        return \`<!DOCTYPE html>
<html>
<head>
    <title>\${data.title}</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/styles.css">
</head>
<body>
    <div class="container">
        <h1>\${data.title}</h1>
        <p>Opal言語で作成されたウェブアプリケーションへようこそ！</p>
    </div>
    <script src="/app.js"></script>
</body>
</html>\`;
    end
end`;
  
  fs.writeFileSync(indexViewPath, indexViewContent, 'utf8');
  
  // 静的ファイル
  const stylesPath = path.join(projectPath, 'public', 'styles.css');
  const stylesContent = `body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    color: #333;
}

.container {
    width: 80%;
    margin: 0 auto;
    padding: 20px;
}

h1 {
    color: #0066cc;
}`;
  
  fs.writeFileSync(stylesPath, stylesContent, 'utf8');
  
  const appJsPath = path.join(projectPath, 'public', 'app.js');
  const appJsContent = `// クライアントサイドのJavaScriptコード
console.log('${name} アプリケーションが読み込まれました');`;
  
  fs.writeFileSync(appJsPath, appJsContent, 'utf8');
}

// モバイルプロジェクトテンプレートの作成
function createMobileProjectTemplate(projectPath, name) {
  // ディレクトリ構造
  fs.mkdirSync(path.join(projectPath, 'src', 'screens'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'src', 'components'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'assets'), { recursive: true });
  
  // メインファイル
  const mainFilePath = path.join(projectPath, 'src', 'main.opal');
  const mainFileContent = `module ${name} then
    import OpalStdlib.Mobile.App
    import OpalStdlib.Mobile.Navigation
    import ${name}.Screens.HomeScreen
    
    function first() -> Void then
        nc app <- new App("${name}");
        nc navigator <- new Navigation.StackNavigator();
        
        // 画面の登録
        navigator.registerScreen("Home", HomeScreen);
        
        // 初期画面の設定
        navigator.initialScreen("Home");
        
        // アプリの起動
        app.setNavigator(navigator);
        app.run();
    end
end`;
  
  fs.writeFileSync(mainFilePath, mainFileContent, 'utf8');
  
  // ホーム画面
  const homeScreenPath = path.join(projectPath, 'src', 'screens', 'HomeScreen.opal');
  const homeScreenContent = `module ${name}.Screens.HomeScreen then
    import OpalStdlib.Mobile.UI
    
    class HomeScreen then
        function render() -> UI.View then
            return UI.View(
                UI.VStack(
                    UI.Text("${name}").fontSize(24).bold(),
                    UI.Spacer().height(20),
                    UI.Text("Opal言語で作成されたモバイルアプリへようこそ！"),
                    UI.Spacer().height(20),
                    UI.Button("クリックしてください", function() -> Void then
                        UI.alert("こんにちは", "Opalモバイルアプリからのメッセージです");
                    end)
                ).padding(20)
            );
        end
    end
end`;
  
  fs.writeFileSync(homeScreenPath, homeScreenContent, 'utf8');
}

// ライブラリプロジェクトテンプレートの作成
function createLibraryProjectTemplate(projectPath, name) {
  // ディレクトリ構造
  fs.mkdirSync(path.join(projectPath, 'src', 'lib'), { recursive: true });
  fs.mkdirSync(path.join(projectPath, 'tests'), { recursive: true });
  
  // メインライブラリファイル
  const libFilePath = path.join(projectPath, 'src', 'lib', `${name.toLowerCase()}.opal`);
  const libFileContent = `module ${name} then
    // 例: 文字列の挨拶を返す関数
    function greet(name: String) -> String then
        return "Hello, " + name + "!";
    end
    
    // 例: 数値計算を行うクラス
    class Calculator then
        function add(a: Integer, b: Integer) -> Integer then
            return a + b;
        end
        
        function subtract(a: Integer, b: Integer) -> Integer then
            return a - b;
        end
        
        function multiply(a: Integer, b: Integer) -> Integer then
            return a * b;
        end
        
        function divide(a: Integer, b: Integer) -> Integer then
            if b == 0 then
                OpalSystemCall.("エラー: ゼロによる除算") => out;
                return 0;
            end
            
            return a / b;
        end
    end
end`;
  
  fs.writeFileSync(libFilePath, libFileContent, 'utf8');
  
  // テストファイル
  const testFilePath = path.join(projectPath, 'tests', `${name.toLowerCase()}_test.opal`);
  const testFileContent = `module ${name}Test then
    import ${name}
    import OpalStdlib.Test
    
    class GreetTest then
        function testGreet() -> Void then
            nc result <- ${name}.greet("World");
            Test.assertEqual(result, "Hello, World!");
        end
    end
    
    class CalculatorTest then
        nc calculator: ${name}.Calculator;
        
        function setup() -> Void then
            calculator <- new ${name}.Calculator();
        end
        
        function testAdd() -> Void then
            nc result <- calculator.add(2, 3);
            Test.assertEqual(result, 5);
        end
        
        function testSubtract() -> Void then
            nc result <- calculator.subtract(5, 3);
            Test.assertEqual(result, 2);
        end
        
        function testMultiply() -> Void then
            nc result <- calculator.multiply(2, 3);
            Test.assertEqual(result, 6);
        end
        
        function testDivide() -> Void then
            nc result <- calculator.divide(6, 3);
            Test.assertEqual(result, 2);
        end
    end
    
    function first() -> Void then
        Test.runTests();
    end
end`;
  
  fs.writeFileSync(testFilePath, testFileContent, 'utf8');
}

// アプリケーションの起動
app.whenReady().then(() => {
  // 設定の読み込み
  loadConfig();
  
  // メインウィンドウの作成
  createWindow();
  
  // IPCイベントリスナーの設定
  setupIpcListeners();
  
  // macOSでのウィンドウ再作成
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// すべてのウィンドウが閉じられたときの処理
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
