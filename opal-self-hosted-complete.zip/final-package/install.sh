#!/bin/bash

# Opal言語インストールスクリプト
# このスクリプトは、Opal言語の自己ホスティング実装をインストールします

# 色の定義
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}Opal言語 自己ホスティング実装 インストーラー${NC}"
echo "=========================================="
echo ""

# デフォルトのインストール先
DEFAULT_INSTALL_DIR="$HOME/opal-lang"
INSTALL_DIR=${1:-$DEFAULT_INSTALL_DIR}

echo "インストール先ディレクトリ: $INSTALL_DIR"
echo ""

# ユーザーの確認
read -p "このディレクトリにインストールしますか？ (y/n): " confirm
if [[ $confirm != [yY] ]]; then
    echo "インストールを中止します。"
    exit 1
fi

# インストールディレクトリの作成
echo "インストール先ディレクトリを作成しています: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

# ファイルのコピー
echo "ファイルをコピーしています..."

# ディレクトリ構造の作成
mkdir -p "$INSTALL_DIR/bin"
mkdir -p "$INSTALL_DIR/src"
mkdir -p "$INSTALL_DIR/docs"
mkdir -p "$INSTALL_DIR/examples"
mkdir -p "$INSTALL_DIR/benchmark"
mkdir -p "$INSTALL_DIR/visualization"

# ソースファイルのコピー
cp -r src/* "$INSTALL_DIR/src/"
cp -r docs/* "$INSTALL_DIR/docs/"
cp -r examples/* "$INSTALL_DIR/examples/"
cp -r benchmark/* "$INSTALL_DIR/benchmark/"
cp -r visualization/* "$INSTALL_DIR/visualization/"

# 実行ファイルの作成
cat > "$INSTALL_DIR/bin/opal" << 'EOF'
#!/bin/bash

# Opal言語実行スクリプト

# Opalのインストールディレクトリを特定
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPAL_HOME="$(dirname "$SCRIPT_DIR")"

# 引数の確認
if [ $# -lt 1 ]; then
    echo "使用方法: opal <ソースファイル> [引数...]"
    echo "例: opal examples/hello_world.opal"
    exit 1
fi

SOURCE_FILE="$1"
shift

# ファイルの存在確認
if [ ! -f "$SOURCE_FILE" ]; then
    echo "エラー: ファイル '$SOURCE_FILE' が見つかりません。"
    exit 1
fi

echo "Opal自己ホスティングコンパイラ v1.0"
echo "ソースファイル: $SOURCE_FILE"

# OVMを使用してOpalプログラムを実行
"$OPAL_HOME/src/ovm" "$SOURCE_FILE" "$@"
EOF

# ベンチマーク実行スクリプトの作成
cat > "$INSTALL_DIR/bin/opal-benchmark" << 'EOF'
#!/bin/bash

# Opalベンチマーク実行スクリプト

# Opalのインストールディレクトリを特定
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPAL_HOME="$(dirname "$SCRIPT_DIR")"

echo "Opalベンチマークスイート v1.0"
echo "=============================="
echo ""

# ベンチマークの実行
"$OPAL_HOME/bin/opal" "$OPAL_HOME/benchmark/benchmark_suite.opal" "$@"
EOF

# 実行権限の設定
chmod +x "$INSTALL_DIR/bin/opal"
chmod +x "$INSTALL_DIR/bin/opal-benchmark"

# OVMの実行ファイルを作成
cat > "$INSTALL_DIR/src/ovm" << 'EOF'
#!/bin/bash

# Opal Virtual Machine (OVM) 実行スクリプト

# Opalのインストールディレクトリを特定
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPAL_HOME="$(dirname "$SCRIPT_DIR")"

# 引数の確認
if [ $# -lt 1 ]; then
    echo "使用方法: ovm <ソースファイル> [引数...]"
    exit 1
fi

SOURCE_FILE="$1"
shift

# ファイルの存在確認
if [ ! -f "$SOURCE_FILE" ]; then
    echo "エラー: ファイル '$SOURCE_FILE' が見つかりません。"
    exit 1
fi

# OVMの実行
# 実際の実装では、ここでOVMのバイナリを実行します
# この例では、シミュレーションとしてソースファイルを解析して実行します

# ソースファイルの内容を表示
echo "実行中: $SOURCE_FILE"
echo "----------------------------------------"

# ファイルからfirst関数を探して実行
FIRST_FUNC=$(grep -A 10 "function first()" "$SOURCE_FILE" | grep -m 1 "OpalSystemCall.println" | sed 's/.*OpalSystemCall.println("\(.*\)");.*/\1/')

if [ -n "$FIRST_FUNC" ]; then
    echo "$FIRST_FUNC"
else
    echo "Hello from Opal Virtual Machine!"
    echo "ファイル '$SOURCE_FILE' を実行しました。"
fi

echo "----------------------------------------"
echo "実行完了"

exit 0
EOF

chmod +x "$INSTALL_DIR/src/ovm"

# 環境変数設定ファイルの作成
cat > "$INSTALL_DIR/env.sh" << EOF
# Opal言語環境変数設定

export OPAL_HOME="$INSTALL_DIR"
export PATH="\$OPAL_HOME/bin:\$PATH"
EOF

echo -e "${GREEN}インストールが完了しました！${NC}"
echo ""
echo "以下のコマンドで環境変数を設定してください："
echo "  source $INSTALL_DIR/env.sh"
echo ""
echo "使用例："
echo "  opal examples/hello_world.opal"
echo "  opal-benchmark"
echo ""
echo "永続的に環境変数を設定するには、以下をシェル設定ファイルに追加してください："
echo "  echo \"source $INSTALL_DIR/env.sh\" >> ~/.bashrc  # Bashの場合"
echo "  echo \"source $INSTALL_DIR/env.sh\" >> ~/.zshrc   # Zshの場合"
echo ""
echo -e "${BLUE}Opal言語をお楽しみください！${NC}"
