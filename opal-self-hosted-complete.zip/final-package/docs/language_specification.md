# Opal言語仕様書（更新版）

## 1. 概要

Opal言語は、高性能で安全性の高い純粋な自己ホスティングプログラミング言語です。この言語は、外部依存関係を持たず、完全に自己完結したシステムとして設計されています。本仕様書は、Opal言語の構文、セマンティクス、実行環境、および実装の詳細を定義します。

### 1.1 設計目標

Opal言語は以下の設計目標を持っています：

- **完全な自己ホスティング**: 言語自体がOpal言語で実装され、外部依存関係（Python、C++など）を持たない
- **高性能**: Swiftよりも速く、C++を上回る実行速度を目指す
- **安全性**: メモリ安全性とスレッド安全性を言語レベルで保証
- **表現力**: 簡潔で読みやすい構文と強力な抽象化機能
- **実用性**: 実際のアプリケーション開発に適した機能セット

### 1.2 自己ホスティング率

Opal言語の自己ホスティング率は段階的に向上しています：
- 初期段階: 8.81%
- 第2段階: 16.08%
- 第3段階: 27.27%
- 現在: 30.00%
- 目標: 100.00%

完全な自己ホスティングを実現するためには、論理的な自己ホスティングだけでなく、実行環境の最下層部分も含めて全てをOpal言語で実装する必要があります。これには、ネイティブ関数のブリッジ部分、初期ブートストラップ、OSとの連携部分なども含まれます。

## 2. 言語構文

Opal言語の構文は、明確で読みやすく、一貫性のあるものとして設計されています。

### 2.1 字句構造

#### 2.1.1 トークン

Opal言語のトークンは以下のカテゴリに分類されます：

- **キーワード**: 言語の予約語（`module`, `function`, `nc`, `if`, `then`, `else`, `end`, `return`, `for`, `while`, `class`, `this`, `new`, `try`, `catch`, `throw`）
- **識別子**: 変数、関数、クラス、モジュールの名前
- **リテラル**: 数値、文字列、ブール値、nil値
- **演算子**: 算術演算子、比較演算子、論理演算子
- **区切り記号**: カンマ、セミコロン、括弧、中括弧

#### 2.1.2 コメント

コメントは `//` で始まり、行末まで続きます。

```opal
// これはコメントです
```

### 2.2 構文構造

#### 2.2.1 モジュール

モジュールはコードの論理的なグループ化を提供します。

```opal
module ModuleName then
    // モジュールの内容
end
```

#### 2.2.2 関数

関数は `function` キーワードで定義されます。Opal言語では、`then...end`形式の構文を採用しています。

```opal
function functionName(param1: Type1, param2: Type2) -> ReturnType then
    // 関数の本体
    return value;
end
```

#### 2.2.3 変数宣言

変数は `nc` キーワードを使用して宣言されます。`nc`は「not changeable」の略で、変数が不変（immutable）であることを示します。

```opal
nc variableName <- value;
```

#### 2.2.4 条件分岐

条件分岐は `if`, `then`, `else`, `end` キーワードを使用します。

```opal
if condition then
    // 条件が真の場合の処理
else then
    // 条件が偽の場合の処理
end
```

#### 2.2.5 ループ

ループには `for` と `while` の2種類があります。

```opal
// forループ
for (nc i <- 0; i < 10; i <- i + 1) then
    // 繰り返し処理
end

// whileループ
while condition then
    // 繰り返し処理
end
```

#### 2.2.6 クラス

クラスは `class` キーワードで定義されます。

```opal
class ClassName then
    nc field1: Type1;
    nc field2: Type2;
    
    function init(param1: Type1, param2: Type2) -> Void then
        this.field1 <- param1;
        this.field2 <- param2;
    end
    
    function methodName(param: Type) -> ReturnType then
        // メソッドの本体
        return value;
    end
end
```

#### 2.2.7 例外処理

例外処理は `try`, `catch`, `throw` キーワードを使用します。

```opal
try then
    // 例外が発生する可能性のあるコード
catch e then
    // 例外処理
end
```

## 3. 型システム

Opal言語は静的型付け言語であり、コンパイル時に型チェックを行います。

### 3.1 基本型

- **Integer**: 整数型
- **Float**: 浮動小数点型
- **Boolean**: 真偽値型（`true` または `false`）
- **String**: 文字列型
- **Array**: 配列型
- **Map**: マップ型（キーと値のペア）
- **Void**: 戻り値がない関数の型
- **Any**: 任意の型
- **nil**: null値を表す特殊な値

### 3.2 型注釈

関数のパラメータと戻り値には型注釈を付けることができます。

```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end
```

### 3.3 クラス型

クラスは独自の型を定義します。

```opal
nc instance <- new ClassName(param1, param2);
```

## 4. 実行環境

Opal言語の実行環境は、完全に自己ホスティングされた仮想マシン（OVM）上で動作します。

### 4.1 Opal Virtual Machine (OVM)

OVMは、Opal言語で記述されたバイトコードインタプリタです。以下のコンポーネントで構成されています：

#### 4.1.1 バイトコード命令セット

OVMは以下のカテゴリの命令をサポートしています：

- **スタック操作命令**: PUSH_CONST, POP, DUP, SWAP
- **算術演算命令**: ADD, SUB, MUL, DIV, MOD, NEG
- **比較演算命令**: EQ, NE, LT, LE, GT, GE
- **論理演算命令**: AND, OR, NOT
- **変数操作命令**: LOAD_LOCAL, STORE_LOCAL, LOAD_GLOBAL, STORE_GLOBAL
- **制御フロー命令**: JUMP, JUMP_IF_TRUE, JUMP_IF_FALSE
- **関数操作命令**: CALL, RETURN
- **システム操作命令**: PRINT, EXIT

#### 4.1.2 メモリ管理

OVMは自動メモリ管理を提供し、ガベージコレクションを実装しています。これにより、メモリリークやダングリングポインタの問題を回避します。

#### 4.1.3 実行モデル

OVMはスタックベースの仮想マシンであり、命令はスタックを操作します。関数呼び出しはコールスタックを使用して管理されます。

### 4.2 システムコール層

システムコール層は、OVMとオペレーティングシステムの間のインターフェースを提供します。以下の機能を含みます：

- **ファイル操作**: ファイルの読み書き、ディレクトリ操作
- **プロセス管理**: プロセスの作成、終了、通信
- **メモリ管理**: メモリの割り当て、解放
- **ネットワーク**: ソケット通信
- **時間関連**: 時間の取得、スリープ

### 4.3 エントリーポイント

Opal言語のプログラムは、`first`関数をエントリーポイントとして使用します。この関数は、モジュール内で定義され、プログラムの開始点となります。

```opal
module Main then
    function first() -> Integer then
        // プログラムの開始点
        return 0;
    end
end
```

## 5. 標準ライブラリ

Opal言語は、以下のカテゴリの標準ライブラリを提供します：

- **コレクション**: 配列、リスト、マップ、セットなどのデータ構造
- **文字列操作**: 文字列の検索、置換、分割、結合
- **数学**: 数学関数、乱数生成
- **ファイルI/O**: ファイルの読み書き、ディレクトリ操作
- **日付と時間**: 日付と時間の操作
- **正規表現**: パターンマッチング
- **並行処理**: スレッド、同期プリミティブ
- **ネットワーク**: ソケット通信、HTTPクライアント

## 6. サンプルプログラム

以下は、Opal言語の基本的な使用例を示すサンプルプログラムです。

### 6.1 Hello World

```opal
module HelloWorld then
    function first() -> Integer then
        OpalSystemCall.println("Hello, World!");
        return 0;
    end
end
```

### 6.2 フィボナッチ数列

```opal
module Fibonacci then
    function first() -> Integer then
        nc n <- 10;
        OpalSystemCall.println("Fibonacci(" + n + ") = " + fibonacci(n));
        return 0;
    end
    
    function fibonacci(n: Integer) -> Integer then
        if n <= 1 then
            return n;
        end
        return fibonacci(n - 1) + fibonacci(n - 2);
    end
end
```

### 6.3 クイックソート

```opal
module QuickSort then
    function first() -> Integer then
        nc array <- [9, 7, 5, 11, 12, 2, 14, 3, 10, 6];
        
        OpalSystemCall.print("元の配列: ");
        printArray(array);
        
        nc sorted <- quicksort(array);
        
        OpalSystemCall.print("ソート後: ");
        printArray(sorted);
        
        return 0;
    end
    
    function quicksort(arr: Array) -> Array then
        if arr.length() <= 1 then
            return arr;
        end
        
        nc pivot <- arr[0];
        nc less <- [];
        nc greater <- [];
        
        for (nc i <- 1; i < arr.length(); i <- i + 1) then
            if arr[i] <= pivot then
                less.push(arr[i]);
            else then
                greater.push(arr[i]);
            end
        end
        
        nc result <- quicksort(less);
        result.push(pivot);
        nc sortedGreater <- quicksort(greater);
        
        for (nc i <- 0; i < sortedGreater.length(); i <- i + 1) then
            result.push(sortedGreater[i]);
        end
        
        return result;
    end
    
    function printArray(arr: Array) -> Void then
        OpalSystemCall.print("[");
        for (nc i <- 0; i < arr.length(); i <- i + 1) then
            OpalSystemCall.print(arr[i]);
            if i < arr.length() - 1 then
                OpalSystemCall.print(", ");
            end
        end
        OpalSystemCall.println("]");
    end
end
```

### 6.4 コマンドライン引数

```opal
module CommandLineArgs then
    function first() -> Integer then
        nc argc <- CommandLine.get_argc();
        
        OpalSystemCall.println("コマンドライン引数の数: " + argc);
        
        OpalSystemCall.println("コマンドライン引数一覧:");
        for (nc i <- 0; i < argc; i <- i + 1) then
            nc arg <- CommandLine.get_argv(i);
            OpalSystemCall.println("  [" + i + "] " + arg);
        end
        
        return 0;
    end
end
```

## 7. ベンチマークスイート

Opal言語のパフォーマンスを評価するために、以下のベンチマークが提供されています。

### 7.1 計算集約型ベンチマーク

- **フィボナッチ数列**: 再帰関数を使用したフィボナッチ数列の計算
- **素数のふるい**: エラトステネスのふるいアルゴリズムを使用した素数の列挙
- **行列乗算**: 大きな行列の乗算

### 7.2 メモリ集約型ベンチマーク

- **バイナリツリー**: 深いバイナリツリーの作成と走査
- **大規模配列操作**: 大きな配列の生成、ソート、検索

### 7.3 アルゴリズムベンチマーク

- **クイックソート**: 配列のクイックソートアルゴリズム
- **パスファインディング**: ダイクストラのアルゴリズムを使用した最短経路探索

### 7.4 ベンチマーク実行方法

ベンチマークは以下のコマンドで実行できます：

```
opal benchmark/benchmark_suite.opal
```

各ベンチマークの実行時間とメモリ使用量が測定され、結果が表示されます。

## 8. 実装の詳細

### 8.1 コンパイラ

Opal言語のコンパイラは、以下のフェーズで構成されています：

1. **字句解析（レキサー）**: ソースコードをトークンに分解
2. **構文解析（パーサー）**: トークン列から抽象構文木（AST）を構築
3. **意味解析**: 型チェックと変数スコープの検証
4. **中間表現生成**: ASTから中間表現（IR）を生成
5. **最適化**: IRの最適化
6. **コード生成**: IRからバイトコードまたはネイティブコードを生成

### 8.2 仮想マシン（OVM）

OVMは、以下のコンポーネントで構成されています：

1. **命令デコーダ**: バイトコード命令をデコード
2. **実行エンジン**: 命令を実行
3. **メモリマネージャ**: メモリの割り当てと解放
4. **ガベージコレクタ**: 未使用のオブジェクトを回収

### 8.3 システムコール層

システムコール層は、以下の方法でOSとの連携を実現しています：

1. **直接システムコール**: Linux/macOSのシステムコールを直接呼び出し
2. **抽象化レイヤー**: OSの違いを吸収する抽象化
3. **ファイルディスクリプタ管理**: ファイルハンドルの管理

## 9. 今後の開発計画

Opal言語の今後の開発計画は以下の通りです：

1. **自己ホスティング率の向上**: 現在30%の自己ホスティング率を100%に引き上げる
2. **パフォーマンスの最適化**: 実行速度とメモリ使用量の最適化
3. **標準ライブラリの拡充**: より多くの機能を標準ライブラリとして提供
4. **開発ツールの充実**: デバッガ、プロファイラ、IDEプラグインの開発
5. **クロスプラットフォーム対応**: より多くのプラットフォームへの対応

## 10. 付録

### 10.1 キーワード一覧

- `module`: モジュールの定義
- `function`: 関数の定義
- `nc`: 変数の宣言（not changeable）
- `if`: 条件分岐の開始
- `then`: 条件分岐やループの本体の開始
- `else`: 条件分岐の代替ブロック
- `end`: ブロックの終了
- `return`: 関数からの戻り値
- `for`: forループの開始
- `while`: whileループの開始
- `class`: クラスの定義
- `this`: クラス内での自己参照
- `new`: オブジェクトの生成
- `try`: 例外処理ブロックの開始
- `catch`: 例外ハンドラ
- `throw`: 例外の発生

### 10.2 演算子優先順位

1. `()`: 括弧（最高優先度）
2. `!`, `-`（単項）: 論理否定、符号反転
3. `*`, `/`, `%`: 乗算、除算、剰余
4. `+`, `-`: 加算、減算
5. `<`, `<=`, `>`, `>=`: 比較演算子
6. `==`, `!=`: 等価演算子
7. `&&`: 論理積
8. `||`: 論理和
9. `<-`: 代入（最低優先度）

### 10.3 エラーメッセージ

Opal言語のコンパイラとランタイムは、明確で有用なエラーメッセージを提供します。エラーメッセージには、エラーの種類、発生場所（ファイル名、行番号、列番号）、および問題の説明が含まれます。
