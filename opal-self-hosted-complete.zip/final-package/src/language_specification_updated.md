# Opal言語仕様書 v1.0

## 1. 概要

Opal（オパール）は高速で効率的なプログラミング言語として設計されています。手動メモリ管理と最小限のランタイムオーバーヘッドを特徴とし、SwiftやC++よりも高速な実行速度を目指しています。

Opalは以下の特徴を持ちます：
- 静的型付け
- 手動メモリ管理
- 関数型プログラミングの要素
- 最小限のランタイムオーバーヘッド
- 自己ホスティングコンパイラ

## 2. 字句構造

### 2.1 トークン

Opalのソースコードは以下のトークンから構成されます：
- 識別子
- キーワード
- リテラル
- 演算子
- 区切り記号

### 2.2 識別子

識別子は英字または下線で始まり、英数字または下線が続きます。

```
identifier = (letter | "_") {letter | digit | "_"};
letter = "A" | "B" | ... | "Z" | "a" | "b" | ... | "z";
digit = "0" | "1" | ... | "9";
```

### 2.3 キーワード

以下はOpalの予約キーワードです：

```
function  end  return  if  then  else  while  do  for  nc
module  class  import  export  external  null  true  false
```

### 2.4 リテラル

#### 2.4.1 整数リテラル

```
integer_literal = decimal_literal | hex_literal | binary_literal;
decimal_literal = digit {digit};
hex_literal = "0x" hex_digit {hex_digit};
binary_literal = "0b" binary_digit {binary_digit};
hex_digit = digit | "A" | ... | "F" | "a" | ... | "f";
binary_digit = "0" | "1";
```

例：
```
42      // 10進数
0xFF    // 16進数
0b1010  // 2進数
```

#### 2.4.2 浮動小数点リテラル

```
float_literal = decimal_literal "." decimal_literal [exponent];
exponent = ("e" | "E") ["+" | "-"] decimal_literal;
```

例：
```
3.14
2.71e-10
```

#### 2.4.3 文字列リテラル

```
string_literal = '"' {string_character} '"';
string_character = any_character_except_double_quote | escape_sequence;
escape_sequence = "\" ("n" | "t" | "r" | "\" | '"');
```

例：
```
"Hello, Opal!"
"Line 1\nLine 2"
```

### 2.5 演算子

```
operator = "+" | "-" | "*" | "/" | "%" | "==" | "!=" | "<" | ">" | "<=" | ">=" | "&&" | "||" | "!" | "=" | "<-" | "=>";
```

### 2.6 コメント

```
single_line_comment = "//" {any_character_except_newline};
multi_line_comment = "/*" {any_character} "*/";
```

例：
```
// これは単一行コメントです

/*
 これは
 複数行コメント
 です
*/
```

## 3. 型システム

### 3.1 基本型

- `Integer`: 整数型
- `Float`: 浮動小数点型
- `Boolean`: 真偽値型
- `String`: 文字列型
- `Void`: 値を持たない型

### 3.2 複合型

- 配列型: `Array<T>`
- マップ型: `Map<K, V>`
- ポインタ型: `Pointer<T>`
- 関数型: `Function<P1, P2, ..., R>`

### 3.3 ユーザー定義型

```
class_definition = "class" identifier ["<" type_parameters ">"] "then" {class_member} "end";
type_parameters = identifier {"," identifier};
class_member = field_declaration | method_declaration;
```

例：
```opal
class Point then
    nc x: Integer;
    nc y: Integer;
    
    function init(x: Integer, y: Integer) then
        this.x <- x;
        this.y <- y;
    end
    
    function distance_from_origin() -> Float then
        return sqrt(this.x * this.x + this.y * this.y);
    end
end
```

## 4. 式

### 4.1 リテラル式

```
literal_expression = integer_literal | float_literal | string_literal | "true" | "false" | "null";
```

### 4.2 識別子式

```
identifier_expression = identifier;
```

### 4.3 演算子式

```
binary_expression = expression operator expression;
unary_expression = operator expression;
```

### 4.4 関数呼び出し式

```
function_call = expression "(" [argument_list] ")";
argument_list = expression {"," expression};
```

### 4.5 メンバーアクセス式

```
member_access = expression "." identifier;
```

### 4.6 配列アクセス式

```
array_access = expression "[" expression "]";
```

### 4.7 条件式

```
conditional_expression = "if" expression "then" expression "else" expression;
```

## 5. 文

### 5.1 変数宣言文

```
variable_declaration = "nc" identifier [":" type] ["=" | "<-" expression] ";";
```

例：
```opal
nc x: Integer = 42;
nc y <- 3.14;  // 型推論
```

### 5.2 代入文

```
assignment = expression ("<-" | "=") expression ";";
```

例：
```opal
x <- 10;
```

### 5.3 条件文

```
if_statement = "if" expression "then" statement_block ["else" statement_block] "end";
```

例：
```opal
if x > 0 then
    println("Positive");
else
    println("Non-positive");
end
```

### 5.4 ループ文

```
while_loop = "while" expression "do" statement_block "end";
do_while_loop = "do" statement_block "while" expression "end";
for_loop = "for" [variable_declaration] ";" expression ";" expression "then" statement_block "end";
```

例：
```opal
// whileループ
while i < 10 do
    println(i);
    i <- i + 1;
end

// do-whileループ
do
    println(i);
    i <- i + 1;
while i < 10 end

// forループ
for nc i <- 0; i < 10; i <- i + 1 then
    println(i);
end
```

### 5.5 関数定義文

```
function_declaration = "function" identifier ["<" type_parameters ">"] "(" [parameter_list] ")" ["->" return_type] "then" statement_block "end";
parameter_list = parameter {"," parameter};
parameter = identifier ":" type;
return_type = type;
```

例：
```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end

function generic_max<T>(a: T, b: T) -> T then
    if a > b then
        return a;
    else
        return b;
    end
end
```

### 5.6 モジュール定義文

```
module_declaration = "module" identifier "then" {declaration} "end";
```

例：
```opal
module Math then
    function sqrt(x: Float) -> Float then
        // 実装
    end
    
    function pow(base: Float, exponent: Float) -> Float then
        // 実装
    end
end
```

### 5.7 クラス定義文

```
class_definition = "class" identifier ["<" type_parameters ">"] "then" {class_member} "end";
```

例：
```opal
class Stack<T> then
    nc items: Array<T>;
    
    function init() then
        this.items <- Array<T>.new();
    end
    
    function push(item: T) -> Void then
        this.items.push(item);
    end
    
    function pop() -> T then
        return this.items.pop();
    end
    
    function is_empty() -> Boolean then
        return this.items.size() == 0;
    end
end
```

### 5.8 インポート文

```
import_statement = "import" identifier ["as" identifier] ";";
```

例：
```opal
import Math;
import IO as InputOutput;
```

### 5.9 外部関数宣言

```
external_function = "external" "function" identifier "(" [parameter_list] ")" ["->" return_type] ";";
```

例：
```opal
external function printf(format: Pointer, args: Any) -> Integer;
```

## 6. メモリ管理

Opalは手動メモリ管理を採用しています。メモリの割り当てと解放は明示的に行う必要があります。

```opal
// メモリ割り当て
nc ptr <- Memory.allocate(size);

// メモリ解放
Memory.free(ptr);
```

## 7. 標準ライブラリ

Opalの標準ライブラリには以下のモジュールが含まれます：

- `Memory`: メモリ管理
- `IO`: 入出力操作
- `System`: システムコール
- `Math`: 数学関数
- `String`: 文字列操作
- `Array`: 配列操作
- `Map`: マップ操作

## 8. 演算子優先順位

| 優先順位 | 演算子 | 結合性 |
|---------|-------|-------|
| 1 | `()` `.` `[]` | 左から右 |
| 2 | `!` `-` (単項) | 右から左 |
| 3 | `*` `/` `%` | 左から右 |
| 4 | `+` `-` | 左から右 |
| 5 | `<` `>` `<=` `>=` | 左から右 |
| 6 | `==` `!=` | 左から右 |
| 7 | `&&` | 左から右 |
| 8 | `\|\|` | 左から右 |
| 9 | `<-` `=>` | 右から左 |

## 9. 文法

以下はOpal言語の文法をEBNF（拡張バッカス・ナウア記法）で表現したものです：

```
program = {declaration};

declaration = variable_declaration
            | function_declaration
            | class_definition
            | module_declaration
            | import_statement
            | external_function;

variable_declaration = "nc" identifier [":" type] ["=" | "<-" expression] ";";

function_declaration = "function" identifier ["<" type_parameters ">"] "(" [parameter_list] ")" ["->" return_type] "then" statement_block "end";
parameter_list = parameter {"," parameter};
parameter = identifier ":" type;
return_type = type;

class_definition = "class" identifier ["<" type_parameters ">"] "then" {class_member} "end";
type_parameters = identifier {"," identifier};
class_member = field_declaration | method_declaration;
field_declaration = "nc" identifier ":" type ";";
method_declaration = function_declaration;

module_declaration = "module" identifier "then" {declaration} "end";

import_statement = "import" identifier ["as" identifier] ";";

external_function = "external" "function" identifier "(" [parameter_list] ")" ["->" return_type] ";";

statement_block = {statement};

statement = variable_declaration
          | assignment
          | if_statement
          | while_loop
          | do_while_loop
          | for_loop
          | return_statement
          | expression_statement;

assignment = expression ("<-" | "=") expression ";";

if_statement = "if" expression "then" statement_block ["else" statement_block] "end";

while_loop = "while" expression "do" statement_block "end";

do_while_loop = "do" statement_block "while" expression "end";

for_loop = "for" [variable_declaration] ";" expression ";" expression "then" statement_block "end";

return_statement = "return" [expression] ";";

expression_statement = expression ";";

expression = literal_expression
           | identifier_expression
           | binary_expression
           | unary_expression
           | function_call
           | member_access
           | array_access
           | conditional_expression;

literal_expression = integer_literal | float_literal | string_literal | "true" | "false" | "null";

identifier_expression = identifier;

binary_expression = expression operator expression;

unary_expression = operator expression;

function_call = expression "(" [argument_list] ")";
argument_list = expression {"," expression};

member_access = expression "." identifier;

array_access = expression "[" expression "]";

conditional_expression = "if" expression "then" expression "else" expression;

type = identifier ["<" type_list ">"] | "Void" | "Integer" | "Float" | "Boolean" | "String" | "Pointer" ["<" type ">"];
type_list = type {"," type};
```

## 10. 実装ノート

Opal言語の実装は以下のコンポーネントで構成されています：

1. レキサー（字句解析器）
2. パーサー（構文解析器）
3. 意味解析器
4. 中間表現（IR）生成器
5. 最適化器
6. コード生成器
7. ランタイムライブラリ

Opalコンパイラは自己ホスティング能力を持ち、Opal言語自身で記述されています。初期のブートストラップコンパイラはPythonで実装されています。

## 11. 将来の拡張

将来のバージョンでは以下の機能の追加を検討しています：

- パターンマッチング
- 代数的データ型
- 並行処理のサポート
- ガベージコレクション（オプション）
- JITコンパイル
- LLVM IRの生成

## 12. 付録

### 12.1 キーワード一覧

```
function  end  return  if  then  else  while  do  for  nc
module  class  import  export  external  null  true  false
```

### 12.2 演算子一覧

```
+  -  *  /  %  ==  !=  <  >  <=  >=  &&  ||  !  =  <-  =>
```

### 12.3 エスケープシーケンス

```
\n  改行
\t  タブ
\r  キャリッジリターン
\\  バックスラッシュ
\"  ダブルクォート
```

### 12.4 エントリーポイント関数

Opal言語では、プログラムのエントリーポイントとして`first`関数を使用します。これは従来の多くのプログラミング言語で使用される`main`関数に相当するものです。

`first`関数は以下の形式で定義する必要があります：

```opal
// 引数なしのバージョン
function first() -> Integer then
    // プログラムのメインロジック
    return 0;  // 成功時は0、エラー時は非0の値を返す
end

// または、コマンドライン引数を受け取るバージョン
function first(args: Array<String>) -> Integer then
    // プログラムのメインロジック
    // args[0]はプログラム名、args[1]以降が実際の引数
    return 0;  // 成功時は0、エラー時は非0の値を返す
end
```
