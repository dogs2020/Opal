# Opal言語 自己ホスティング実装

このパッケージは、Opal言語の完全な自己ホスティング実装を提供します。Python依存関係を排除し、「nc」キーワードを一貫して使用し、first関数をエントリーポイントとする純粋なOpal実装です。

## インストール方法

以下の手順でインストールしてください：

```bash
# インストールスクリプトを実行
chmod +x install.sh
./install.sh

# 環境変数を設定
source ~/opal-lang/env.sh
```

永続的に環境変数を設定するには：

```bash
# Bashの場合
echo "source ~/opal-lang/env.sh" >> ~/.bashrc

# Zshの場合
echo "source ~/opal-lang/env.sh" >> ~/.zshrc
```

## 使用方法

### Opalプログラムの実行

```bash
opal examples/hello_world.opal
```

### ベンチマークの実行

```bash
opal-benchmark
```

## ディレクトリ構造

- `bin/` - 実行ファイル
- `src/` - ソースコード
  - `system_call_layer.opal` - システムコール層
  - `lexer.opal` - 字句解析器
  - `parser.opal` - 構文解析器
  - `ovm.opal` - Opal仮想マシン
- `docs/` - ドキュメント
  - `language_specification.md` - 言語仕様書
- `examples/` - サンプルプログラム
  - `hello_world.opal` - Hello Worldプログラム
  - `fibonacci.opal` - フィボナッチ数列
  - `quicksort.opal` - クイックソート
  - `command_line_args.opal` - コマンドライン引数
- `benchmark/` - ベンチマークスイート
  - `benchmark_suite.opal` - ベンチマークプログラム

## 特徴

- **完全な自己ホスティング**: Python依存関係を排除
- **「nc」キーワード**: 変数宣言に「nc」キーワードを一貫して使用
- **first関数**: すべてのプログラムのエントリーポイントとしてfirst関数を使用
- **OVM**: Opal仮想マシンによる実行環境
- **システムコール層**: OSとの直接通信を実現

## トラブルシューティング

問題が発生した場合は、以下を確認してください：

1. 環境変数が正しく設定されているか
   ```bash
   echo $OPAL_HOME
   ```

2. 実行ファイルに実行権限があるか
   ```bash
   ls -la ~/opal-lang/bin/
   ```

3. ソースファイルが存在するか
   ```bash
   ls -la ~/opal-lang/examples/
   ```

詳細については、`docs/language_specification.md`を参照してください。
