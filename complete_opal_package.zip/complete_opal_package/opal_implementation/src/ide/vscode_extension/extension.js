// Opal Language Extension for VS Code

const vscode = require('vscode');
const path = require('path');
const { exec } = require('child_process');
const fs = require('fs');

/**
 * @param {vscode.ExtensionContext} context
 */
function activate(context) {
    console.log('Opal Language Extension is now active!');

    // Register the run command
    let runCommand = vscode.commands.registerCommand('opal.runFile', function () {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found');
            return;
        }

        const document = editor.document;
        if (document.languageId !== 'opal') {
            vscode.window.showErrorMessage('Not an Opal file');
            return;
        }

        // Save the file before running
        document.save().then(() => {
            const filePath = document.fileName;
            const opalPath = vscode.workspace.getConfiguration('opal').get('path');
            
            // Create terminal if it doesn't exist
            let terminal = vscode.window.terminals.find(t => t.name === 'Opal');
            if (!terminal) {
                terminal = vscode.window.createTerminal('Opal');
            }
            
            terminal.show();
            terminal.sendText(`${opalPath} ${filePath}`);
        });
    });

    // Register the debug command
    let debugCommand = vscode.commands.registerCommand('opal.debugFile', function () {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found');
            return;
        }

        const document = editor.document;
        if (document.languageId !== 'opal') {
            vscode.window.showErrorMessage('Not an Opal file');
            return;
        }

        // Save the file before debugging
        document.save().then(() => {
            const filePath = document.fileName;
            const opalPath = vscode.workspace.getConfiguration('opal').get('path');
            
            // Create terminal if it doesn't exist
            let terminal = vscode.window.terminals.find(t => t.name === 'Opal Debug');
            if (!terminal) {
                terminal = vscode.window.createTerminal('Opal Debug');
            }
            
            terminal.show();
            terminal.sendText(`${opalPath} --debug ${filePath}`);
        });
    });

    // Register the create project command
    let createProjectCommand = vscode.commands.registerCommand('opal.createProject', async function () {
        const projectName = await vscode.window.showInputBox({
            placeHolder: 'Project name',
            prompt: 'Enter a name for your Opal project'
        });

        if (!projectName) {
            return;
        }

        const projectType = await vscode.window.showQuickPick([
            { label: 'Console Application', description: 'A simple console application' },
            { label: 'Web Application', description: 'A web application using the Opal web framework' },
            { label: 'Mobile Application', description: 'A mobile application using the Opal mobile framework' },
            { label: 'Library', description: 'A reusable library' }
        ], {
            placeHolder: 'Select project type'
        });

        if (!projectType) {
            return;
        }

        const folderUri = await vscode.window.showOpenDialog({
            canSelectFiles: false,
            canSelectFolders: true,
            canSelectMany: false,
            openLabel: 'Select folder'
        });

        if (!folderUri || folderUri.length === 0) {
            return;
        }

        const projectPath = path.join(folderUri[0].fsPath, projectName);
        
        // Create project directory
        if (!fs.existsSync(projectPath)) {
            fs.mkdirSync(projectPath);
        }

        // Create project structure based on type
        switch (projectType.label) {
            case 'Console Application':
                createConsoleProject(projectPath, projectName);
                break;
            case 'Web Application':
                createWebProject(projectPath, projectName);
                break;
            case 'Mobile Application':
                createMobileProject(projectPath, projectName);
                break;
            case 'Library':
                createLibraryProject(projectPath, projectName);
                break;
        }

        // Open the project in VS Code
        vscode.commands.executeCommand('vscode.openFolder', vscode.Uri.file(projectPath));
    });

    // Register code completion provider
    const completionProvider = vscode.languages.registerCompletionItemProvider('opal', {
        provideCompletionItems(document, position) {
            const linePrefix = document.lineAt(position).text.substr(0, position.character);
            
            // Basic completion items
            const completionItems = [];
            
            // Keywords
            const keywords = ['if', 'else', 'then', 'end', 'for', 'while', 'do', 'return', 'when', 'case', 'import', 'module', 'class', 'function', 'nc'];
            keywords.forEach(keyword => {
                const item = new vscode.CompletionItem(keyword, vscode.CompletionItemKind.Keyword);
                completionItems.push(item);
            });
            
            // Types
            const types = ['Void', 'Integer', 'Float32', 'Float64', 'Boolean', 'String', 'Array', 'Map', 'Any'];
            types.forEach(type => {
                const item = new vscode.CompletionItem(type, vscode.CompletionItemKind.TypeParameter);
                completionItems.push(item);
            });
            
            // Standard library functions
            const stdlibFunctions = ['OpalSystemCall'];
            stdlibFunctions.forEach(func => {
                const item = new vscode.CompletionItem(func, vscode.CompletionItemKind.Function);
                completionItems.push(item);
            });
            
            return completionItems;
        }
    });

    // Register hover provider
    const hoverProvider = vscode.languages.registerHoverProvider('opal', {
        provideHover(document, position, token) {
            const range = document.getWordRangeAtPosition(position);
            const word = document.getText(range);
            
            // Provide hover information for keywords and standard library
            if (word === 'first') {
                return new vscode.Hover('Entry point function for Opal programs');
            } else if (word === 'OpalSystemCall') {
                return new vscode.Hover('System call function for I/O operations');
            } else if (word === 'out') {
                return new vscode.Hover('Standard output destination');
            } else if (word === 'nc') {
                return new vscode.Hover('Named constant declaration');
            }
            
            return null;
        }
    });

    context.subscriptions.push(runCommand);
    context.subscriptions.push(debugCommand);
    context.subscriptions.push(createProjectCommand);
    context.subscriptions.push(completionProvider);
    context.subscriptions.push(hoverProvider);
}

function deactivate() {}

// Helper functions for project creation
function createConsoleProject(projectPath, projectName) {
    // Create src directory
    const srcPath = path.join(projectPath, 'src');
    if (!fs.existsSync(srcPath)) {
        fs.mkdirSync(srcPath);
    }
    
    // Create main.opal file
    const mainFilePath = path.join(srcPath, 'main.opal');
    const mainFileContent = `module ${projectName} then
    function first() -> Void then
        OpalSystemCall.("Hello from ${projectName}!") => out;
    end
end`;
    
    fs.writeFileSync(mainFilePath, mainFileContent);
    
    // Create project.json file
    const projectJsonPath = path.join(projectPath, 'project.json');
    const projectJsonContent = JSON.stringify({
        name: projectName,
        version: "0.1.0",
        type: "console",
        entryPoint: "src/main.opal",
        dependencies: []
    }, null, 2);
    
    fs.writeFileSync(projectJsonPath, projectJsonContent);
    
    // Create README.md
    const readmePath = path.join(projectPath, 'README.md');
    const readmeContent = `# ${projectName}

A console application written in Opal.

## Running the application

\`\`\`
opal src/main.opal
\`\`\`
`;
    
    fs.writeFileSync(readmePath, readmeContent);
}

function createWebProject(projectPath, projectName) {
    // Create directories
    const srcPath = path.join(projectPath, 'src');
    const publicPath = path.join(projectPath, 'public');
    
    if (!fs.existsSync(srcPath)) {
        fs.mkdirSync(srcPath);
    }
    
    if (!fs.existsSync(publicPath)) {
        fs.mkdirSync(publicPath);
    }
    
    // Create main.opal file
    const mainFilePath = path.join(srcPath, 'main.opal');
    const mainFileContent = `module ${projectName} then
    import OpalStdlib.Web.Server
    import OpalStdlib.Web.Router
    import OpalStdlib.Web.Response
    
    function first() -> Void then
        nc server <- new Server(8080);
        nc router <- new Router();
        
        // Define routes
        router.get("/", function(req, res) -> Void then
            res.send("<h1>Welcome to ${projectName}</h1>");
        end);
        
        router.get("/about", function(req, res) -> Void then
            res.send("<h1>About ${projectName}</h1><p>A web application built with Opal.</p>");
        end);
        
        // Set up the server
        server.use(router);
        
        // Start the server
        OpalSystemCall.("Server running on http://localhost:8080") => out;
        server.start();
    end
end`;
    
    fs.writeFileSync(mainFilePath, mainFileContent);
    
    // Create index.html file
    const indexFilePath = path.join(publicPath, 'index.html');
    const indexFileContent = `<!DOCTYPE html>
<html>
<head>
    <title>${projectName}</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/styles.css">
</head>
<body>
    <div id="app"></div>
    <script src="/app.js"></script>
</body>
</html>`;
    
    fs.writeFileSync(indexFilePath, indexFileContent);
    
    // Create styles.css file
    const stylesFilePath = path.join(publicPath, 'styles.css');
    const stylesFileContent = `body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    line-height: 1.6;
}

h1 {
    color: #333;
}`;
    
    fs.writeFileSync(stylesFilePath, stylesFileContent);
    
    // Create project.json file
    const projectJsonPath = path.join(projectPath, 'project.json');
    const projectJsonContent = JSON.stringify({
        name: projectName,
        version: "0.1.0",
        type: "web",
        entryPoint: "src/main.opal",
        staticDir: "public",
        dependencies: [
            "OpalStdlib.Web"
        ]
    }, null, 2);
    
    fs.writeFileSync(projectJsonPath, projectJsonContent);
    
    // Create README.md
    const readmePath = path.join(projectPath, 'README.md');
    const readmeContent = `# ${projectName}

A web application built with Opal.

## Running the application

\`\`\`
opal src/main.opal
\`\`\`

Then open http://localhost:8080 in your browser.
`;
    
    fs.writeFileSync(readmePath, readmeContent);
}

function createMobileProject(projectPath, projectName) {
    // Create directories
    const srcPath = path.join(projectPath, 'src');
    const assetsPath = path.join(projectPath, 'assets');
    
    if (!fs.existsSync(srcPath)) {
        fs.mkdirSync(srcPath);
    }
    
    if (!fs.existsSync(assetsPath)) {
        fs.mkdirSync(assetsPath);
    }
    
    // Create main.opal file
    const mainFilePath = path.join(srcPath, 'main.opal');
    const mainFileContent = `module ${projectName} then
    import OpalStdlib.Mobile.App
    import OpalStdlib.Mobile.UI
    
    class MainScreen then
        function render() -> UI.View then
            return UI.View(
                UI.VStack(
                    UI.Text("Welcome to ${projectName}").fontSize(24).bold(),
                    UI.Spacer().height(20),
                    UI.Button("Click Me", function() -> Void then
                        UI.alert("Hello", "You clicked the button!");
                    end)
                ).padding(20)
            );
        end
    end
    
    function first() -> Void then
        nc app <- new App("${projectName}");
        app.setMainScreen(new MainScreen());
        app.run();
    end
end`;
    
    fs.writeFileSync(mainFilePath, mainFileContent);
    
    // Create project.json file
    const projectJsonPath = path.join(projectPath, 'project.json');
    const projectJsonContent = JSON.stringify({
        name: projectName,
        version: "0.1.0",
        type: "mobile",
        entryPoint: "src/main.opal",
        assetsDir: "assets",
        dependencies: [
            "OpalStdlib.Mobile"
        ],
        platforms: ["ios", "android"]
    }, null, 2);
    
    fs.writeFileSync(projectJsonPath, projectJsonContent);
    
    // Create README.md
    const readmePath = path.join(projectPath, 'README.md');
    const readmeContent = `# ${projectName}

A mobile application built with Opal.

## Running the application

### iOS Simulator
\`\`\`
opal run --platform ios
\`\`\`

### Android Emulator
\`\`\`
opal run --platform android
\`\`\`
`;
    
    fs.writeFileSync(readmePath, readmeContent);
}

function createLibraryProject(projectPath, projectName) {
    // Create directories
    const srcPath = path.join(projectPath, 'src');
    const testsPath = path.join(projectPath, 'tests');
    
    if (!fs.existsSync(srcPath)) {
        fs.mkdirSync(srcPath);
    }
    
    if (!fs.existsSync(testsPath)) {
        fs.mkdirSync(testsPath);
    }
    
    // Create library.opal file
    const libraryFilePath = path.join(srcPath, 'library.opal');
    const libraryFileContent = `module ${projectName} then
    // Example function
    function greet(name: String) -> String then
        return "Hello, " + name + "!";
    end
    
    // Example class
    class Calculator then
        function add(a: Integer, b: Integer) -> Integer then
            return a + b;
        end
        
        function subtract(a: Integer, b: Integer) -> Integer then
            return a - b;
        end
        
        function multiply(a: Integer, b: Integer) -> Integer then
            return a * b;
        end
        
        function divide(a: Integer, b: Integer) -> Integer then
            if b == 0 then
                OpalSystemCall.("Error: Division by zero") => out;
                return 0;
            end
            
            return a / b;
        end
    end
end`;
    
    fs.writeFileSync(libraryFilePath, libraryFileContent);
    
    // Create test file
    const testFilePath = path.join(testsPath, 'library_test.opal');
    const testFileContent = `module ${projectName}Test then
    import ${projectName}
    import OpalStdlib.Test
    
    class GreetTest then
        function testGreet() -> Void then
            nc result <- ${projectName}.greet("World");
            Test.assertEqual(result, "Hello, World!");
        end
    end
    
    class CalculatorTest then
        nc calculator: ${projectName}.Calculator;
        
        function setup() -> Void then
            calculator <- new ${projectName}.Calculator();
        end
        
        function testAdd() -> Void then
            nc result <- calculator.add(2, 3);
            Test.assertEqual(result, 5);
        end
        
        function testSubtract() -> Void then
            nc result <- calculator.subtract(5, 3);
            Test.assertEqual(result, 2);
        end
        
        function testMultiply() -> Void then
            nc result <- calculator.multiply(2, 3);
            Test.assertEqual(result, 6);
        end
        
        function testDivide() -> Void then
            nc result <- calculator.divide(6, 3);
            Test.assertEqual(result, 2);
        end
    end
    
    function first() -> Void then
        Test.runTests();
    end
end`;
    
    fs.writeFileSync(testFilePath, testFileContent);
    
    // Create project.json file
    const projectJsonPath = path.join(projectPath, 'project.json');
    const projectJsonContent = JSON.stringify({
        name: projectName,
        version: "0.1.0",
        type: "library",
        entryPoint: "src/library.opal",
        testDir: "tests",
        dependencies: [
            "OpalStdlib.Test"
        ]
    }, null, 2);
    
    fs.writeFileSync(projectJsonPath, projectJsonContent);
    
    // Create README.md
    const readmePath = path.join(projectPath, 'README.md');
    const readmeContent = `# ${projectName}

A library built with Opal.

## Using the library

\`\`\`opal
import ${projectName}

function first() -> Void then
    nc greeting <- ${projectName}.greet("World");
    OpalSystemCall.(greeting) => out;
    
    nc calculator <- new ${projectName}.Calculator();
    nc result <- calculator.add(2, 3);
    OpalSystemCall.(result) => out;
end
\`\`\`

## Running tests

\`\`\`
opal tests/library_test.opal
\`\`\`
`;
    
    fs.writeFileSync(readmePath, readmeContent);
}

module.exports = {
    activate,
    deactivate
};
