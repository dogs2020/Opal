# Opal言語ドキュメント

## 目次

1. [はじめに](#はじめに)
2. [インストール](#インストール)
3. [言語の基本](#言語の基本)
4. [型システム](#型システム)
5. [制御構造](#制御構造)
6. [関数](#関数)
7. [モジュールとインポート](#モジュールとインポート)
8. [クラスとオブジェクト指向プログラミング](#クラスとオブジェクト指向プログラミング)
9. [インターフェース](#インターフェース)
10. [標準ライブラリ](#標準ライブラリ)
11. [エラー処理](#エラー処理)
12. [コンパイラとインタプリタの使用方法](#コンパイラとインタプリタの使用方法)
13. [開発ツール](#開発ツール)
14. [パッケージマネージャ](#パッケージマネージャ)
15. [サンプルプログラム](#サンプルプログラム)
16. [言語仕様](#言語仕様)

## はじめに

Opal（オパール）は、静的型付け、型推論、関数型プログラミングの要素を持つ現代的なプログラミング言語です。Opalは読みやすさ、保守性、パフォーマンスを重視して設計されており、幅広いアプリケーション開発に適しています。

Opalの主な特徴：

- **静的型付け**: コンパイル時の型チェックにより、多くのエラーを早期に発見できます
- **型推論**: 明示的な型宣言が不要な場合が多く、コードの簡潔さを保ちます
- **関数型プログラミング**: 高階関数、クロージャ、パターンマッチングをサポート
- **オブジェクト指向プログラミング**: クラス、継承、インターフェースをサポート
- **モジュールシステム**: コードの整理と再利用を促進
- **並行処理**: 軽量スレッドとメッセージパッシングをサポート
- **メモリ安全性**: 自動メモリ管理とガベージコレクション
- **相互運用性**: C/C++との容易な連携

Opalは教育、ウェブ開発、データ分析、システムプログラミング、組み込みシステムなど、様々な分野で使用できます。

## インストール

### システム要件

- Linux、macOS、またはWindows
- 最小2GBのRAM
- 500MB以上の空きディスク容量

### インストール方法

#### パッケージからのインストール

1. インストールパッケージをダウンロードします
2. パッケージを解凍します: `unzip opal_package.zip`
3. インストールスクリプトを実行します: `sudo ./install.sh`

#### ソースからのビルド

1. ソースコードをクローンします: `git clone https://github.com/opal-lang/opal.git`
2. ビルドディレクトリを作成します: `mkdir build && cd build`
3. CMakeを実行します: `cmake ..`
4. ビルドします: `make`
5. インストールします: `sudo make install`

### 動作確認

インストールが完了したら、以下のコマンドでOpalが正しく動作するか確認できます：

```bash
opal --version
```

## 言語の基本

### 基本構文

Opalプログラムは、モジュール、関数、クラス、変数宣言などで構成されます。

```opal
module HelloWorld then
    function main() -> Void then
        IO.println("Hello, World!");
    end
end
```

### コメント

Opalでは、行コメントと複数行コメントをサポートしています。

```opal
// これは行コメントです

/*
 これは
 複数行コメントです
*/
```

### 変数宣言

変数は `nc` キーワードを使用して宣言します。型は明示的に指定することも、型推論に任せることもできます。

```opal
// 型を明示的に指定
nc age: Integer = 30;

// 型推論を使用
nc name = "Opal";

// 定数（再代入不可）
nc PI: Float = 3.14159;
```

### 基本データ型

Opalは以下の基本データ型を提供します：

- `Integer`: 整数型
- `Float`: 浮動小数点型
- `Boolean`: 真偽値型（`true` または `false`）
- `String`: 文字列型
- `Character`: 文字型
- `Null`: null値を表す型

```opal
nc i: Integer = 42;
nc f: Float = 3.14;
nc b: Boolean = true;
nc s: String = "Hello";
nc c: Character = 'A';
nc n: Null = null;
```

### 演算子

Opalは標準的な算術演算子、比較演算子、論理演算子をサポートしています。

```opal
// 算術演算子
nc sum = 10 + 5;      // 加算
nc diff = 10 - 5;     // 減算
nc product = 10 * 5;  // 乗算
nc quotient = 10 / 5; // 除算
nc remainder = 10 % 3; // 剰余

// 比較演算子
nc equal = (10 == 10);       // 等しい
nc notEqual = (10 != 5);     // 等しくない
nc greater = (10 > 5);       // より大きい
nc less = (5 < 10);          // より小さい
nc greaterEqual = (10 >= 10); // 以上
nc lessEqual = (5 <= 10);     // 以下

// 論理演算子
nc and = true and false;  // 論理積
nc or = true or false;    // 論理和
nc not = not true;        // 論理否定
```

## 型システム

### 基本型

Opalの基本型は前述の通りです。これらの型は値型として扱われます。

### 複合型

Opalは以下の複合型をサポートしています：

- `Array<T>`: 配列型
- `Map<K, V>`: マップ型
- `Set<T>`: セット型
- `Tuple<T1, T2, ...>`: タプル型
- `Option<T>`: オプション型
- `Result<T, E>`: 結果型

```opal
// 配列
nc numbers: Array<Integer> = [1, 2, 3, 4, 5];

// マップ
nc ages: Map<String, Integer> = {
    "Alice": 30,
    "Bob": 25,
    "Charlie": 35
};

// セット
nc uniqueNumbers: Set<Integer> = {1, 2, 3, 4, 5};

// タプル
nc person: Tuple<String, Integer, Boolean> = {"Alice", 30, true};

// オプション
nc maybeValue: Option<Integer> = Some(42);
nc noValue: Option<Integer> = None;

// 結果
nc success: Result<Integer, String> = Ok(42);
nc error: Result<Integer, String> = Err("Something went wrong");
```

### 型エイリアス

`type` キーワードを使用して、既存の型に新しい名前を付けることができます。

```opal
type UserId = Integer;
type UserName = String;
type UserMap = Map<UserId, UserName>;

nc users: UserMap = {
    1: "Alice",
    2: "Bob",
    3: "Charlie"
};
```

### ジェネリクス

Opalはジェネリックプログラミングをサポートしており、型パラメータを使用して汎用的なコードを記述できます。

```opal
function identity<T>(value: T) -> T then
    return value;
end

nc intValue = identity<Integer>(42);
nc strValue = identity<String>("Hello");
```

### 型推論

Opalは強力な型推論システムを備えており、多くの場合、明示的な型宣言は不要です。

```opal
// 型推論により、xはIntegerとして推論される
nc x = 42;

// 型推論により、yはStringとして推論される
nc y = "Hello";

// 型推論により、zはArray<Integer>として推論される
nc z = [1, 2, 3, 4, 5];
```

## 制御構造

### 条件分岐

Opalは `if`-`then`-`else` 構文を使用して条件分岐を表現します。

```opal
if x > 10 then
    IO.println("xは10より大きい");
elseif x > 5 then
    IO.println("xは5より大きく10以下");
else
    IO.println("xは5以下");
end
```

### ループ

Opalは `for` と `while` ループをサポートしています。

```opal
// forループ（範囲）
for i = 1; i <= 5; i++ then
    IO.println(i);
end

// forループ（イテレーション）
for item in [1, 2, 3, 4, 5] then
    IO.println(item);
end

// whileループ
nc i = 0;
while i < 5 then
    IO.println(i);
    i <- i + 1;
end
```

### パターンマッチング

Opalは `match` 式を使用してパターンマッチングをサポートしています。

```opal
function describe(value: Any) -> String then
    match value then
        case Integer:
            return "整数: " + value.toString();
        case String:
            return "文字列: " + value;
        case Boolean:
            if value then
                return "真";
            else
                return "偽";
            end
        case Array<Any>:
            return "配列（要素数: " + value.length().toString() + "）";
        default:
            return "不明な型";
    end
end
```

## 関数

### 関数定義

Opalでは、`function` キーワードを使用して関数を定義します。

```opal
function add(a: Integer, b: Integer) -> Integer then
    return a + b;
end
```

### 関数呼び出し

関数は名前と引数リストを使用して呼び出します。

```opal
nc result = add(5, 3);  // 8
```

### 無名関数（ラムダ式）

Opalは無名関数（ラムダ式）をサポートしています。

```opal
nc multiply = (a: Integer, b: Integer) => a * b;
nc result = multiply(5, 3);  // 15
```

### 高階関数

関数は第一級オブジェクトであり、他の関数に渡したり、関数から返したりできます。

```opal
function applyTwice(f: (Integer) -> Integer, x: Integer) -> Integer then
    return f(f(x));
end

function double(x: Integer) -> Integer then
    return x * 2;
end

nc result = applyTwice(double, 3);  // 12 (3を2倍して6、さらに6を2倍して12)
```

### クロージャ

Opalの関数はクロージャであり、外部スコープの変数をキャプチャできます。

```opal
function makeCounter() -> () -> Integer then
    nc count = 0;
    return () => {
        count <- count + 1;
        return count;
    };
end

nc counter = makeCounter();
IO.println(counter());  // 1
IO.println(counter());  // 2
IO.println(counter());  // 3
```

### 再帰関数

Opalは再帰関数をサポートしています。

```opal
function factorial(n: Integer) -> Integer then
    if n <= 1 then
        return 1;
    else
        return n * factorial(n - 1);
    end
end

nc result = factorial(5);  // 120
```

## モジュールとインポート

### モジュール定義

Opalでは、`module` キーワードを使用してコードをモジュールにまとめることができます。

```opal
module Math then
    nc PI = 3.14159;
    
    function square(x: Float) -> Float then
        return x * x;
    end
    
    function cube(x: Float) -> Float then
        return x * x * x;
    end
end
```

### モジュールのインポート

`import` キーワードを使用して、他のモジュールの機能をインポートできます。

```opal
import Math

function main() -> Void then
    IO.println(Math.PI);
    IO.println(Math.square(4.0));  // 16.0
end
```

### 選択的インポート

特定の機能だけをインポートすることもできます。

```opal
import Math.{PI, square}

function main() -> Void then
    IO.println(PI);
    IO.println(square(4.0));  // 16.0
end
```

### エイリアスを使用したインポート

インポート時にエイリアスを指定することもできます。

```opal
import Math as M

function main() -> Void then
    IO.println(M.PI);
    IO.println(M.square(4.0));  // 16.0
end
```

## クラスとオブジェクト指向プログラミング

### クラス定義

Opalでは、`class` キーワードを使用してクラスを定義します。

```opal
nc class Person then
    // プロパティ
    private nc name: String;
    private nc age: Integer;
    
    // コンストラクタ
    function init(name: String, age: Integer) -> Void then
        this.name <- name;
        this.age <- age;
    end
    
    // メソッド
    function getName() -> String then
        return this.name;
    end
    
    function getAge() -> Integer then
        return this.age;
    end
    
    function setAge(age: Integer) -> Void then
        this.age <- age;
    end
    
    function greet() -> String then
        return "こんにちは、" + this.name + "です。" + this.age.toString() + "歳です。";
    end
end
```

### オブジェクトの作成と使用

クラスからオブジェクトを作成し、そのメソッドを呼び出すことができます。

```opal
nc person = Person{name: "Alice", age: 30};
IO.println(person.getName());  // "Alice"
IO.println(person.getAge());   // 30
IO.println(person.greet());    // "こんにちは、Aliceです。30歳です。"

person.setAge(31);
IO.println(person.getAge());   // 31
```

### 継承

Opalでは、`extends` キーワードを使用してクラスの継承を表現します。

```opal
nc class Student extends Person then
    private nc studentId: String;
    
    function init(name: String, age: Integer, studentId: String) -> Void then
        super(name, age);
        this.studentId <- studentId;
    end
    
    function getStudentId() -> String then
        return this.studentId;
    end
    
    // メソッドのオーバーライド
    function greet() -> String then
        return super.greet() + " 学生番号は" + this.studentId + "です。";
    end
end
```

### 抽象クラス

`abstract` キーワードを使用して抽象クラスを定義できます。

```opal
abstract class Shape then
    abstract function area() -> Float;
    abstract function perimeter() -> Float;
    
    function describe() -> String then
        return "面積: " + this.area().toString() + ", 周囲長: " + this.perimeter().toString();
    end
end
```

## インターフェース

### インターフェース定義

Opalでは、`interface` キーワードを使用してインターフェースを定義します。

```opal
interface Drawable then
    function draw() -> Void;
    function getColor() -> String;
end
```

### インターフェースの実装

`implements` キーワードを使用して、クラスがインターフェースを実装することを示します。

```opal
nc class Circle implements Drawable then
    private nc radius: Float;
    private nc color: String;
    
    function init(radius: Float, color: String) -> Void then
        this.radius <- radius;
        this.color <- color;
    end
    
    function getRadius() -> Float then
        return this.radius;
    end
    
    // インターフェースメソッドの実装
    function draw() -> Void then
        IO.println("円を描画（半径: " + this.radius.toString() + ", 色: " + this.color + "）");
    end
    
    function getColor() -> String then
        return this.color;
    end
end
```

### 複数のインターフェース

クラスは複数のインターフェースを実装できます。

```opal
interface Resizable then
    function resize(factor: Float) -> Void;
end

nc class Rectangle implements Drawable, Resizable then
    private nc width: Float;
    private nc height: Float;
    private nc color: String;
    
    function init(width: Float, height: Float, color: String) -> Void then
        this.width <- width;
        this.height <- height;
        this.color <- color;
    end
    
    // Drawableインターフェースの実装
    function draw() -> Void then
        IO.println("長方形を描画（幅: " + this.width.toString() + 
                  ", 高さ: " + this.height.toString() + 
                  ", 色: " + this.color + "）");
    end
    
    function getColor() -> String then
        return this.color;
    end
    
    // Resizableインターフェースの実装
    function resize(factor: Float) -> Void then
        this.width <- this.width * factor;
        this.height <- this.height * factor;
    end
end
```

## 標準ライブラリ

Opalは豊富な標準ライブラリを提供しています。以下は主要なモジュールの概要です。

### Core

基本的なデータ型と操作を提供します。

```opal
import OpalStdlib.Core.String
import OpalStdlib.Core.Array
import OpalStdlib.Core.Map
import OpalStdlib.Core.Set
import OpalStdlib.Core.Math
import OpalStdlib.Core.IO
import OpalStdlib.Core.System
import OpalStdlib.Core.Time
```

### Collections

高度なコレクション操作を提供します。

```opal
import OpalStdlib.Collections.List
import OpalStdlib.Collections.Queue
import OpalStdlib.Collections.Stack
import OpalStdlib.Collections.PriorityQueue
```

### Concurrency

並行処理のためのツールを提供します。

```opal
import OpalStdlib.Concurrency.Thread
import OpalStdlib.Concurrency.Future
import OpalStdlib.Concurrency.Channel
import OpalStdlib.Concurrency.Mutex
```

### IO

入出力操作を提供します。

```opal
import OpalStdlib.IO.File
import OpalStdlib.IO.Directory
import OpalStdlib.IO.Path
import OpalStdlib.IO.Console
```

### Net

ネットワーク操作を提供します。

```opal
import OpalStdlib.Net.HTTP
import OpalStdlib.Net.TCP
import OpalStdlib.Net.UDP
import OpalStdlib.Net.Socket
```

### Text

テキスト処理ツールを提供します。

```opal
import OpalStdlib.Text.Regex
import OpalStdlib.Text.JSON
import OpalStdlib.Text.XML
import OpalStdlib.Text.CSV
```

### DeepLearning

深層学習のためのツールを提供します。

```opal
import OpalStdlib.DeepLearning.Tensor
import OpalStdlib.DeepLearning.NN
import OpalStdlib.DeepLearning.Optimizer
```

### Finance

金融計算のためのツールを提供します。

```opal
import OpalStdlib.Finance.Core.FinancialMath
import OpalStdlib.Finance.Analysis
import OpalStdlib.Finance.Trading
```

## エラー処理

### 例外処理

Opalでは、`try`-`catch`-`finally` 構文を使用して例外を処理します。

```opal
try then
    nc file = File.open("data.txt", "r");
    nc content = file.readAll();
    file.close();
    IO.println(content);
catch FileNotFoundException then
    IO.println("ファイルが見つかりません");
catch IOException as e then
    IO.println("I/Oエラー: " + e.getMessage());
finally
    // クリーンアップコード
    IO.println("処理が完了しました");
end
```

### 例外のスロー

`throw` キーワードを使用して例外をスローできます。

```opal
function divide(a: Integer, b: Integer) -> Integer then
    if b == 0 then
        throw DivisionByZeroException{message: "ゼロによる除算"};
    end
    return a / b;
end
```

### カスタム例外

カスタム例外クラスを定義できます。

```opal
nc class CustomException extends Exception then
    private nc code: Integer;
    
    function init(message: String, code: Integer) -> Void then
        super(message);
        this.code <- code;
    end
    
    function getCode() -> Integer then
        return this.code;
    end
end
```

### Result型

例外の代わりに `Result<T, E>` 型を使用してエラーを処理することもできます。

```opal
function safeDivide(a: Integer, b: Integer) -> Result<Integer, String> then
    if b == 0 then
        return Err("ゼロによる除算");
    end
    return Ok(a / b);
end

// 使用例
match safeDivide(10, 2) then
    case Ok(result):
        IO.println("結果: " + result.toString());
    case Err(error):
        IO.println("エラー: " + error);
end
```

## コンパイラとインタプリタの使用方法

### コンパイラ（opalc）

Opalコンパイラ（opalc）を使用して、Opalソースコードをコンパイルできます。

```bash
# 基本的な使用方法
opalc source.opal

# 出力ファイルを指定
opalc -o output source.opal

# 最適化レベルを指定
opalc -O2 source.opal

# オブジェクトファイルにコンパイル
opalc -c source.opal

# アセンブリを出力
opalc -S source.opal

# デバッグ情報を含める
opalc -g source.opal

# ヘルプを表示
opalc --help
```

### インタプリタ（opal）

Opalインタプリタ（opal）を使用して、Opalスクリプトを直接実行できます。

```bash
# スクリプトを実行
opal script.opal

# 対話モードで起動
opal -i

# 引数をスクリプトに渡す
opal script.opal arg1 arg2

# 詳細な出力
opal -v script.opal

# ヘルプを表示
opal --help
```

## 開発ツール

### IDE（opal_ide）

Opal IDEは、Opalプログラムの開発を支援する統合開発環境です。

```bash
# IDEを起動
opal_ide

# ファイルを指定して起動
opal_ide file.opal

# プロジェクトを指定して起動
opal_ide --project /path/to/project
```

### プレイグラウンド（opal_playground）

Opalプレイグラウンドは、Opalコードを対話的に試すためのツールです。

```bash
# プレイグラウンドを起動
opal_playground
```

### デバッガ

Opalデバッガを使用して、プログラムのデバッグができます。

```bash
# デバッグモードでプログラムを実行
opal --debug script.opal

# ブレークポイントを設定
# デバッガ内で:
# break 10     # 10行目にブレークポイントを設定
# continue     # 実行を継続
# step         # ステップイン
# next         # ステップオーバー
# print x      # 変数xの値を表示
# backtrace    # コールスタックを表示
# quit         # デバッガを終了
```

## パッケージマネージャ

### パッケージマネージャ（opal_pm）

Opalパッケージマネージャ（opal_pm）を使用して、パッケージの管理ができます。

```bash
# パッケージをインストール
opal_pm install package_name

# 特定のバージョンをインストール
opal_pm install package_name@1.0.0

# パッケージをアンインストール
opal_pm uninstall package_name

# パッケージを更新
opal_pm update package_name

# インストール済みパッケージを一覧表示
opal_pm list

# パッケージを検索
opal_pm search keyword

# パッケージ情報を表示
opal_pm info package_name

# 新しいパッケージを作成
opal_pm init

# パッケージを公開
opal_pm publish
```

## サンプルプログラム

### Hello World

```opal
module HelloWorld then
    function main() -> Void then
        IO.println("Hello, World!");
    end
end
```

### 階乗計算

```opal
module Factorial then
    function factorial(n: Integer) -> Integer then
        if n <= 1 then
            return 1;
        else
            return n * factorial(n - 1);
        end
    end
    
    function main() -> Void then
        for i = 1; i <= 10; i++ then
            IO.println(i.toString() + "! = " + factorial(i).toString());
        end
    end
end
```

### オブジェクト指向プログラミング

```opal
module OOPExample then
    interface Shape then
        function area() -> Float;
        function perimeter() -> Float;
        function describe() -> String;
    end
    
    nc class Rectangle implements Shape then
        private nc width: Float;
        private nc height: Float;
        
        function init(width: Float, height: Float) -> Void then
            this.width <- width;
            this.height <- height;
        end
        
        function area() -> Float then
            return this.width * this.height;
        end
        
        function perimeter() -> Float then
            return 2 * (this.width + this.height);
        end
        
        function describe() -> String then
            return "Rectangle(width=" + this.width.toString() + 
                  ", height=" + this.height.toString() + ")";
        end
    end
    
    nc class Circle implements Shape then
        private nc radius: Float;
        
        function init(radius: Float) -> Void then
            this.radius <- radius;
        end
        
        function area() -> Float then
            return Math.PI * this.radius * this.radius;
        end
        
        function perimeter() -> Float then
            return 2 * Math.PI * this.radius;
        end
        
        function describe() -> String then
            return "Circle(radius=" + this.radius.toString() + ")";
        end
    end
    
    function main() -> Void then
        nc shapes: Array<Shape> = [
            Rectangle{width: 5.0, height: 3.0},
            Circle{radius: 4.0}
        ];
        
        for shape in shapes then
            IO.println(shape.describe());
            IO.println("Area: " + shape.area().toString());
            IO.println("Perimeter: " + shape.perimeter().toString());
            IO.println("");
        end
    end
end
```

### 深層学習

```opal
module DeepLearningExample then
    import OpalStdlib.DeepLearning.Tensor
    import OpalStdlib.DeepLearning.NN
    import OpalStdlib.DeepLearning.Optimizer
    
    nc class SimpleNN then
        private nc fc1: NN.Linear;
        private nc fc2: NN.Linear;
        private nc activation: NN.ReLU;
        
        function init(inputSize: Integer, hiddenSize: Integer, outputSize: Integer) -> Void then
            this.fc1 <- NN.Linear{inFeatures: inputSize, outFeatures: hiddenSize};
            this.fc2 <- NN.Linear{inFeatures: hiddenSize, outFeatures: outputSize};
            this.activation <- NN.ReLU{};
        end
        
        function forward(x: Tensor) -> Tensor then
            nc hidden = this.fc1.forward(x);
            hidden <- this.activation.forward(hidden);
            return this.fc2.forward(hidden);
        end
        
        function parameters() -> Array<Tensor> then
            return [
                this.fc1.weight, this.fc1.bias,
                this.fc2.weight, this.fc2.bias
            ];
        end
    end
    
    function main() -> Void then
        // モデルを初期化
        nc model = SimpleNN{
            inputSize: 784,
            hiddenSize: 128,
            outputSize: 10
        };
        
        // 入力テンソルを作成
        nc input = Tensor.randn([1, 784]);
        
        // 順伝播
        nc output = model.forward(input);
        
        IO.println("Input shape: " + input.shape().toString());
        IO.println("Output shape: " + output.shape().toString());
        IO.println("Output: " + output.toString());
    end
end
```

## 言語仕様

### 予約語

Opalの予約語は以下の通りです：

```
abstract    and         as          break       case
catch       class       continue    default     do
else        elseif      end         enum        extends
false       finally     for         function    if
implements  import      in          interface   is
match       module      nc          new         not
null        or          private     protected   public
return      static      super       then        this
throw       true        try         type        while
```

### 演算子の優先順位

演算子の優先順位（高いものから順に）：

1. `()` （括弧）、`[]` （添字）、`.` （メンバーアクセス）
2. `!` （論理否定）、`~` （ビット否定）、`-` （単項マイナス）、`+` （単項プラス）
3. `*` （乗算）、`/` （除算）、`%` （剰余）
4. `+` （加算）、`-` （減算）
5. `<<` （左シフト）、`>>` （右シフト）
6. `<` （より小さい）、`<=` （以下）、`>` （より大きい）、`>=` （以上）
7. `==` （等しい）、`!=` （等しくない）
8. `&` （ビットAND）
9. `^` （ビットXOR）
10. `|` （ビットOR）
11. `and` （論理AND）
12. `or` （論理OR）
13. `=` （代入）、`<-` （代入）、`+=` （加算代入）、`-=` （減算代入）、`*=` （乗算代入）、`/=` （除算代入）、`%=` （剰余代入）

### 文法

Opalの文法はEBNF（拡張バッカス・ナウア記法）で以下のように定義されます：

```
program        ::= module_decl

module_decl    ::= 'module' identifier 'then' declaration* 'end'

declaration    ::= var_decl | function_decl | class_decl | interface_decl | type_decl | import_decl

var_decl       ::= 'nc' identifier [':' type] '=' expression ';'

function_decl  ::= 'function' identifier '(' [param_list] ')' '->' type 'then' statement* 'end'

param_list     ::= param (',' param)*
param          ::= identifier ':' type

class_decl     ::= ['abstract'] ['nc'] 'class' identifier ['extends' identifier] ['implements' identifier_list] 'then' class_member* 'end'

class_member   ::= ['private' | 'protected' | 'public'] ['nc'] (var_decl | function_decl)

interface_decl ::= 'interface' identifier ['extends' identifier_list] 'then' interface_member* 'end'

interface_member ::= function_signature ';'
function_signature ::= 'function' identifier '(' [param_list] ')' '->' type

type_decl      ::= 'type' identifier '=' type ';'

import_decl    ::= 'import' import_path [import_alias] ';'
import_path    ::= identifier ('.' identifier)*
import_alias   ::= 'as' identifier

statement      ::= var_decl | assignment | if_stmt | for_stmt | while_stmt | return_stmt | try_stmt | throw_stmt | match_stmt | expression_stmt

assignment     ::= lvalue ('<-' | '=' | '+=' | '-=' | '*=' | '/=' | '%=') expression ';'
lvalue         ::= identifier | member_access | array_access

if_stmt        ::= 'if' expression 'then' statement* ['elseif' expression 'then' statement*]* ['else' statement*] 'end'

for_stmt       ::= 'for' (for_c | for_each) 'then' statement* 'end'
for_c          ::= identifier '=' expression ';' expression ';' expression
for_each       ::= identifier 'in' expression

while_stmt     ::= 'while' expression 'then' statement* 'end'

return_stmt    ::= 'return' [expression] ';'

try_stmt       ::= 'try' 'then' statement* ('catch' [identifier 'as'] identifier 'then' statement*)* ['finally' 'then' statement*] 'end'

throw_stmt     ::= 'throw' expression ';'

match_stmt     ::= 'match' expression 'then' match_case* 'end'
match_case     ::= 'case' pattern ':' statement*
pattern        ::= type | literal | identifier | '_'

expression_stmt ::= expression ';'

expression     ::= literal | identifier | unary_expr | binary_expr | call_expr | member_access | array_access | array_literal | object_literal | lambda_expr

literal        ::= integer_lit | float_lit | string_lit | char_lit | bool_lit | null_lit

unary_expr     ::= ('-' | '+' | 'not' | '!') expression

binary_expr    ::= expression operator expression
operator       ::= '+' | '-' | '*' | '/' | '%' | '==' | '!=' | '<' | '<=' | '>' | '>=' | 'and' | 'or' | '&' | '|' | '^' | '<<' | '>>'

call_expr      ::= expression '(' [argument_list] ')'
argument_list  ::= expression (',' expression)*

member_access  ::= expression '.' identifier

array_access   ::= expression '[' expression ']'

array_literal  ::= '[' [expression_list] ']'
expression_list ::= expression (',' expression)*

object_literal ::= identifier '{' [field_init_list] '}'
field_init_list ::= field_init (',' field_init)*
field_init     ::= identifier ':' expression

lambda_expr    ::= '(' [param_list] ')' '=>' (expression | '{' statement* '}')

type           ::= basic_type | array_type | map_type | function_type | tuple_type | option_type | result_type | user_type
basic_type     ::= 'Integer' | 'Float' | 'Boolean' | 'String' | 'Character' | 'Null' | 'Any' | 'Void'
array_type     ::= 'Array' '<' type '>'
map_type       ::= 'Map' '<' type ',' type '>'
function_type  ::= '(' [type_list] ')' '->' type
tuple_type     ::= 'Tuple' '<' type_list '>'
option_type    ::= 'Option' '<' type '>'
result_type    ::= 'Result' '<' type ',' type '>'
user_type      ::= identifier
type_list      ::= type (',' type)*

identifier     ::= [a-zA-Z_][a-zA-Z0-9_]*
integer_lit    ::= [0-9]+ | '0x'[0-9a-fA-F]+ | '0b'[01]+
float_lit      ::= [0-9]+'.'[0-9]+ | [0-9]+'.'[0-9]+'e'[+-]?[0-9]+
string_lit     ::= '"' [^"]* '"'
char_lit       ::= "'" . "'"
bool_lit       ::= 'true' | 'false'
null_lit       ::= 'null'
```

以上がOpal言語の基本的なドキュメントです。より詳細な情報や高度な機能については、公式ウェブサイトやリファレンスマニュアルを参照してください。
