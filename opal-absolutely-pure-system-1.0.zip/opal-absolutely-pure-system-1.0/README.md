# 絶対的に純粋なOpalシステム

## 概要

これは、外部言語（Python、C、JavaScript等）への依存関係を一切持たない、完全に自己完結型のOpal言語実装です。

## 特徴

- **100%純粋なOpal実装** - 全てのコンポーネントがOpal言語で実装されています
- **外部依存関係なし** - 外部言語やライブラリに一切依存しません
- **完全な自己ホスティング** - コンパイラが自分自身をコンパイルできます
- **ネイティブコード生成** - 中間言語を介さず直接マシンコードを生成します
- **独自のリンカ** - 外部リンカに依存せずにオブジェクトファイルをリンクします
- **システムコール直接呼び出し** - OSと直接通信します

## システム要件

- x86_64アーキテクチャ
- Linuxオペレーティングシステム

## ビルド方法

```bash
./build.sh
```

## 使用方法

Opalプログラムのコンパイル:
```bash
./bin/opalc examples/hello_world.opal -o hello_world
```

プログラムの実行:
```bash
./hello_world
```

依存関係の検証:
```bash
./bin/dependency_validator <directory>
```

## ドキュメント

詳細なドキュメントは `docs/` ディレクトリにあります:

- `docs/language_specification.md` - Opal言語の仕様
- `docs/ABSOLUTELY_PURE_SYSTEM.md` - 絶対的に純粋なOpalシステムの設計と実装
- `docs/compiler_architecture.md` - コンパイラのアーキテクチャ

## ライセンス

MITライセンスの下で公開されています。詳細は `LICENSE` ファイルを参照してください。
