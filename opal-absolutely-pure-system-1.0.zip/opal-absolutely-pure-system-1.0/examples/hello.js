#!/usr/bin/env node
// Opalコンパイラによって生成されたJavaScriptコード

// コンソール出力関数
function println(message) {
  console.log(message);
}

// main関数
function main() {
  println("Hello, Opal World!");
  return 0;
}

// エントリーポイント
main();
