#!/bin/bash

# 絶対的に純粋なOpalシステムのビルドスクリプト

echo "絶対的に純粋なOpalシステムをビルドしています..."

# ディレクトリの作成
mkdir -p bin
mkdir -p obj
mkdir -p lib

# アセンブリレベルコンパイラのビルド
echo "アセンブリレベルコンパイラをビルドしています..."
./bootstrap/opal_bootstrap src/assembly_level_compiler.opal -o obj/assembly_level_compiler.o
./bootstrap/opal_bootstrap src/elf_generator.opal -o obj/elf_generator.o
./bootstrap/opal_bootstrap src/opal_linker.opal -o obj/opal_linker.o
./bootstrap/opal_bootstrap src/os_loader_interface.opal -o obj/os_loader_interface.o

# 初期コンパイラの構築
echo "初期コンパイラを構築しています..."
./bootstrap/opal_linker obj/assembly_level_compiler.o obj/elf_generator.o obj/opal_linker.o obj/os_loader_interface.o -o bin/opal_compiler_gen1

# 第1世代コンパイラを使って第2世代コンパイラをビルド
echo "第2世代コンパイラをビルドしています..."
./bin/opal_compiler_gen1 src/assembly_level_compiler.opal -o obj/assembly_level_compiler.gen2.o
./bin/opal_compiler_gen1 src/elf_generator.opal -o obj/elf_generator.gen2.o
./bin/opal_compiler_gen1 src/opal_linker.opal -o obj/opal_linker.gen2.o
./bin/opal_compiler_gen1 src/os_loader_interface.opal -o obj/os_loader_interface.gen2.o
./bin/opal_compiler_gen1 src/absolutely_pure_opal_system.opal -o obj/absolutely_pure_opal_system.gen2.o

# 第2世代コンパイラの構築
echo "第2世代コンパイラを構築しています..."
./bin/opal_compiler_gen1 -link obj/assembly_level_compiler.gen2.o obj/elf_generator.gen2.o obj/opal_linker.gen2.o obj/os_loader_interface.gen2.o obj/absolutely_pure_opal_system.gen2.o -o bin/opal_compiler_gen2

# 第2世代コンパイラを使って第3世代コンパイラをビルド
echo "第3世代コンパイラをビルドしています..."
./bin/opal_compiler_gen2 src/assembly_level_compiler.opal -o obj/assembly_level_compiler.gen3.o
./bin/opal_compiler_gen2 src/elf_generator.opal -o obj/elf_generator.gen3.o
./bin/opal_compiler_gen2 src/opal_linker.opal -o obj/opal_linker.gen3.o
./bin/opal_compiler_gen2 src/os_loader_interface.opal -o obj/os_loader_interface.gen3.o
./bin/opal_compiler_gen2 src/absolutely_pure_opal_system.opal -o obj/absolutely_pure_opal_system.gen3.o

# 第3世代コンパイラの構築
echo "第3世代コンパイラを構築しています..."
./bin/opal_compiler_gen2 -link obj/assembly_level_compiler.gen3.o obj/elf_generator.gen3.o obj/opal_linker.gen3.o obj/os_loader_interface.gen3.o obj/absolutely_pure_opal_system.gen3.o -o bin/opal_compiler_gen3

# 第2世代と第3世代のコンパイラを比較して自己ホスティングを検証
echo "自己ホスティングを検証しています..."
if cmp -s bin/opal_compiler_gen2 bin/opal_compiler_gen3; then
    echo "検証成功: 第2世代と第3世代のコンパイラが一致しました！"
    echo "自己ホスティングが完了しました。"
    
    # 最終的なコンパイラをインストール
    cp bin/opal_compiler_gen3 bin/opalc
    chmod +x bin/opalc
    
    # 依存関係検証ツールのビルド
    echo "依存関係検証ツールをビルドしています..."
    ./bin/opalc src/dependency_validator.opal -o bin/dependency_validator
    chmod +x bin/dependency_validator
    
    echo "絶対的に純粋なOpalシステムのビルドが完了しました！"
    echo "使用方法:"
    echo "  ./bin/opalc <source_file.opal> -o <output_file>"
    echo "  ./bin/dependency_validator <directory>"
else
    echo "検証失敗: 第2世代と第3世代のコンパイラが一致しませんでした。"
    echo "自己ホスティングに失敗しました。"
    exit 1
fi

# サンプルプログラムのビルド
echo "サンプルプログラムをビルドしています..."
./bin/opalc examples/hello_world.opal -o examples/hello_world
./bin/opalc examples/fibonacci.opal -o examples/fibonacci
./bin/opalc examples/quicksort.opal -o examples/quicksort

echo "ビルドプロセスが完了しました。"
