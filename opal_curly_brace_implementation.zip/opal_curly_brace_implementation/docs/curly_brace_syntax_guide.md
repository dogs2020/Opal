# Opal言語 中括弧構文ドキュメント

## 概要

Opal言語の構文が更新され、従来の`then`/`end`キーワードによるブロック区切りから、中括弧`{}`によるブロック区切りに変更されました。このドキュメントでは、新しい中括弧構文の使用方法と、既存コードの移行方法について説明します。

## 中括弧構文の基本

従来のOpal言語では、ブロックの開始と終了を`then`と`end`キーワードで表していましたが、新しい構文では中括弧`{}`を使用します。

### 旧構文（then/end）:

```
module HelloWorld then
  function first() -> Void then
    OpalSystemCall.("Hello, Opal!") -> out;
  end
end
```

### 新構文（中括弧）:

```
module HelloWorld {
  function first() -> Void {
    OpalSystemCall.("Hello, Opal!") -> out;
  }
}
```

## 構文要素ごとの変更点

### モジュール定義

**旧構文:**
```
module ModuleName then
  // モジュール内容
end
```

**新構文:**
```
module ModuleName {
  // モジュール内容
}
```

### 関数定義

**旧構文:**
```
function functionName(param1: Type1, param2: Type2) -> ReturnType then
  // 関数本体
end
```

**新構文:**
```
function functionName(param1: Type1, param2: Type2) -> ReturnType {
  // 関数本体
}
```

### クラス定義

**旧構文:**
```
class ClassName then
  var property1: Type1;
  
  function constructor(param: Type) -> Void then
    // コンストラクタ本体
  end
  
  function method() -> ReturnType then
    // メソッド本体
  end
end
```

**新構文:**
```
class ClassName {
  var property1: Type1;
  
  function constructor(param: Type) -> Void {
    // コンストラクタ本体
  }
  
  function method() -> ReturnType {
    // メソッド本体
  }
}
```

### 制御構造

#### if文

**旧構文:**
```
if condition then
  // 条件が真の場合の処理
else if anotherCondition then
  // 別の条件が真の場合の処理
else then
  // それ以外の場合の処理
end
```

**新構文:**
```
if (condition) {
  // 条件が真の場合の処理
} else if (anotherCondition) {
  // 別の条件が真の場合の処理
} else {
  // それ以外の場合の処理
}
```

#### while文

**旧構文:**
```
while condition then
  // 繰り返し処理
end
```

**新構文:**
```
while (condition) {
  // 繰り返し処理
}
```

#### for文

**旧構文:**
```
for var i = 0; i < 10; i = i + 1 then
  // 繰り返し処理
end
```

**新構文:**
```
for (var i = 0; i < 10; i = i + 1) {
  // 繰り返し処理
}
```

### 例外処理

**旧構文:**
```
try then
  // 試行する処理
catch error: ErrorType then
  // エラー処理
finally then
  // 最終処理
end
```

**新構文:**
```
try {
  // 試行する処理
} catch (error: ErrorType) {
  // エラー処理
} finally {
  // 最終処理
}
```

### match文

**旧構文:**
```
match (value) then
  case pattern1 then
    // パターン1の処理
  end
  case pattern2 then
    // パターン2の処理
  end
  default then
    // デフォルト処理
  end
end
```

**新構文:**
```
match (value) {
  case pattern1 {
    // パターン1の処理
  }
  case pattern2 {
    // パターン2の処理
  }
  default {
    // デフォルト処理
  }
}
```

## コード移行ガイド

既存のOpal言語コードを新しい中括弧構文に移行するには、以下の手順に従ってください：

1. すべての`then`キーワードを`{`に置き換える
2. すべての`end`キーワードを`}`に置き換える
3. 条件式を持つ構造（if, while, for, match）では、条件を括弧`()`で囲む
4. インデントを適切に調整する

## 注意点

- 新しい構文では、条件式を括弧`()`で囲むことが必須になりました
- 中括弧`{}`の前後には適切なスペースを入れることを推奨します
- セミコロン`;`の使用ルールは変更ありません（文の終わりには必要）
- 変数宣言、代入、関数呼び出しなどの基本的な式の構文は変更ありません

## サンプルコード

### Hello World

```
module HelloWorld {
  function first() -> Void {
    OpalSystemCall.("Hello, Opal!") -> out;
  }
}
```

### クラスと継承

```
module ClassExample {
  class Animal {
    var name: String;
    
    function constructor(name: String) -> Void {
      this.name <- name;
    }
    
    function speak() -> Void {
      OpalSystemCall.("...") -> out;
    }
  }
  
  class Dog extends Animal {
    function constructor(name: String) -> Void {
      super(name);
    }
    
    function speak() -> Void {
      OpalSystemCall.(this.name + " says: Woof!") -> out;
    }
  }
  
  function main() -> Void {
    var dog = new Dog("Pochi");
    dog.speak();
  }
}
```

### 制御構造と例外処理

```
module ControlFlowExample {
  function processValue(value: Integer) -> String {
    try {
      if (value < 0) {
        throw new Error("負の値は処理できません");
      } else if (value == 0) {
        return "ゼロです";
      } else {
        var result = "";
        for (var i = 0; i < value; i = i + 1) {
          result = result + "*";
        }
        return result;
      }
    } catch (error: Error) {
      return "エラー: " + error.message;
    }
  }
}
```

## まとめ

新しい中括弧構文は、多くの主流プログラミング言語で使用されている構文と一致しており、Opal言語の可読性と学習しやすさを向上させます。既存のコードを移行する際には、上記のガイドラインに従って慎重に変換を行ってください。
