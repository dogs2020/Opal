#!/usr/bin/env python3
# Opal言語 - 中括弧構文テストランナー
# このスクリプトは、Opal言語の中括弧構文テストケースを実行するためのテストランナーです

import os
import sys
import subprocess
import glob
import time
from termcolor import colored

# テストディレクトリ
TEST_DIR = "/home/ubuntu/opal_project/test_cases"
# Opalコンパイラのパス
OPAL_COMPILER = "/home/ubuntu/opal_project/opal_enhanced/bin/opal"
# 修正したOpalコンパイラのパス
MODIFIED_COMPILER = "/home/ubuntu/opal_project/bin/opal"

def print_header(text):
    """ヘッダーテキストを表示"""
    print("\n" + "=" * 80)
    print(colored(f" {text} ", "white", "on_blue"))
    print("=" * 80)

def print_success(text):
    """成功メッセージを表示"""
    print(colored(f"✓ {text}", "green"))

def print_error(text):
    """エラーメッセージを表示"""
    print(colored(f"✗ {text}", "red"))

def print_info(text):
    """情報メッセージを表示"""
    print(colored(f"ℹ {text}", "cyan"))

def find_test_files():
    """テストディレクトリからテストファイルを検索"""
    return glob.glob(os.path.join(TEST_DIR, "*.opal"))

def run_test(compiler_path, test_file):
    """指定されたコンパイラでテストファイルを実行"""
    try:
        # コンパイルコマンドを実行
        compile_cmd = [compiler_path, "compile", test_file]
        compile_result = subprocess.run(compile_cmd, capture_output=True, text=True)
        
        if compile_result.returncode != 0:
            return False, f"コンパイルエラー: {compile_result.stderr}"
        
        # 実行ファイルのパスを取得
        base_name = os.path.splitext(os.path.basename(test_file))[0]
        output_file = os.path.join(os.path.dirname(test_file), f"{base_name}.ovm")
        
        # 実行コマンドを実行
        run_cmd = [compiler_path, "run", output_file]
        run_result = subprocess.run(run_cmd, capture_output=True, text=True)
        
        if run_result.returncode != 0:
            return False, f"実行エラー: {run_result.stderr}"
        
        return True, run_result.stdout
    except Exception as e:
        return False, f"テスト実行中にエラーが発生しました: {str(e)}"

def main():
    """メイン関数"""
    print_header("Opal言語 中括弧構文テストランナー")
    
    # テストファイルを検索
    test_files = find_test_files()
    if not test_files:
        print_error("テストファイルが見つかりませんでした")
        return
    
    print_info(f"{len(test_files)}個のテストファイルが見つかりました")
    
    # 修正したコンパイラが存在するか確認
    if not os.path.exists(MODIFIED_COMPILER):
        print_error(f"修正したコンパイラが見つかりません: {MODIFIED_COMPILER}")
        print_info("修正したコンパイラをビルドしてください")
        return
    
    # 各テストファイルを実行
    success_count = 0
    failure_count = 0
    
    for test_file in test_files:
        test_name = os.path.basename(test_file)
        print_info(f"\nテスト実行中: {test_name}")
        
        # 修正したコンパイラでテスト実行
        success, result = run_test(MODIFIED_COMPILER, test_file)
        
        if success:
            print_success(f"テスト成功: {test_name}")
            print(result)
            success_count += 1
        else:
            print_error(f"テスト失敗: {test_name}")
            print(result)
            failure_count += 1
    
    # 結果サマリーを表示
    print_header("テスト結果サマリー")
    print_info(f"合計テスト数: {len(test_files)}")
    print_success(f"成功: {success_count}")
    print_error(f"失敗: {failure_count}")
    
    if failure_count == 0:
        print_success("\nすべてのテストが成功しました！")
    else:
        print_error("\nいくつかのテストが失敗しました。詳細を確認してください。")

if __name__ == "__main__":
    main()
