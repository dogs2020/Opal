# Opal言語 中括弧構文実装 README

## 概要

このパッケージは、Opal言語の構文を従来の`then`/`end`キーワードによるブロック区切りから、中括弧`{}`によるブロック区切りに変更した実装です。

## パッケージ内容

```
opal_curly_brace_implementation/
├── docs/                      # ドキュメント
│   └── curly_brace_syntax_guide.md  # 中括弧構文ガイド
├── examples/                  # サンプルプログラム
│   └── todo_app.opal          # ToDoアプリケーションの例
├── src/                       # ソースコード
│   └── compiler/              # コンパイラ実装
│       ├── lexer.opal         # 字句解析器（中括弧対応版）
│       ├── parser.opal        # 構文解析器（中括弧対応版）
│       ├── bytecode_generator.opal  # バイトコードジェネレーター（中括弧対応版）
│       └── error_messages.opal      # エラーメッセージ定義
├── test_cases/                # テストケース
│   ├── hello_world.opal       # Hello Worldテスト
│   ├── control_flow.opal      # 制御構造テスト
│   ├── class_test.opal        # クラスとオブジェクト指向テスト
│   ├── exception_test.opal    # 例外処理テスト
│   └── module_import_test.opal # モジュールとインポートテスト
└── test_runner.py            # テストランナー
```

## 主な変更点

1. **レキサー（字句解析器）の変更**:
   - 中括弧 `{` と `}` をトークンとして認識するよう更新
   - `LEFT_BRACE` と `RIGHT_BRACE` トークンタイプを追加

2. **パーサー（構文解析器）の変更**:
   - `then` キーワードの代わりに `{` を使用するよう変更
   - `end` キーワードの代わりに `}` を使用するよう変更
   - 条件式を括弧 `()` で囲むよう要求する構文規則を追加
   - ブロック構造の解析方法を更新

3. **バイトコードジェネレーターの変更**:
   - 中括弧構文に対応するよう更新
   - すべての `then`/`end` 構文を `{`/`}` に置き換え

4. **エラーメッセージの更新**:
   - 中括弧構文に関連するエラーメッセージを追加
   - 「thenキーワードが必要です」を「{が必要です」に変更するなど

## 使用方法

### 中括弧構文の基本

```
module HelloWorld {
  function first() -> Void {
    OpalSystemCall.("Hello, Opal!") -> out;
  }
}
```

詳細な構文ガイドは `docs/curly_brace_syntax_guide.md` を参照してください。

### テストの実行

テストランナーを使用してテストケースを実行するには:

```
python3 test_runner.py
```

### サンプルプログラム

`examples/todo_app.opal` には、中括弧構文を使用した実用的なToDoアプリケーションの例が含まれています。

## 既存コードの移行

既存のOpal言語コードを新しい中括弧構文に移行するには、以下の手順に従ってください：

1. すべての `then` キーワードを `{` に置き換える
2. すべての `end` キーワードを `}` に置き換える
3. 条件式を持つ構造（if, while, for, match）では、条件を括弧 `()` で囲む
4. インデントを適切に調整する

詳細な移行ガイドは `docs/curly_brace_syntax_guide.md` を参照してください。

## 注意点

- この実装は、Opal言語の構文のみを変更しており、言語の機能や意味論は変更していません
- 中括弧構文は、多くの主流プログラミング言語で使用されている構文と一致しており、Opal言語の可読性と学習しやすさを向上させます
