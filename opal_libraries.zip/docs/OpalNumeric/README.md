# OpalNumeric ライブラリドキュメント

## 概要

OpalNumericは、Julia風の科学計算と数値処理機能を提供するOpal言語用ライブラリです。このライブラリは、行列演算、統計関数、最適化アルゴリズム、数値積分、微分方程式ソルバー、乱数生成など、科学技術計算に必要な高性能な機能を提供します。

## モジュール構成

OpalNumericライブラリは以下のサブモジュールで構成されています：

1. **LinearAlgebra** - 行列演算と線形代数
2. **Statistics** - 統計関数と確率分布
3. **Optimization** - 最適化アルゴリズム
4. **Integration** - 数値積分
5. **DifferentialEquations** - 微分方程式ソルバー
6. **RandomNumbers** - 乱数生成

## インストール方法

OpalNumericライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalNumeric`ディレクトリとそのサブディレクトリをプロジェクトにコピーします
2. Opalプログラムの先頭で`OpalNumeric`モジュールをインポートします

```opal
// OpalNumericモジュールをインポート
import OpalNumeric;

module MyApp then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalNumeric!") -> out;
    end
end
```

## API リファレンス

### コアモジュール

#### `OpalNumeric.initialize() -> Boolean`

OpalNumericライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalNumeric.initialize();
```

#### `OpalNumeric.VERSION -> String`

OpalNumericライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.0.0"）

**使用例**:
```opal
OpalSystemCall.("OpalNumeric version: " + OpalNumeric.VERSION) -> out;
```

#### `OpalNumeric.PI -> Float`

円周率の値を取得します。

**戻り値**: 円周率（π）の値

**使用例**:
```opal
nc area <- OpalNumeric.PI * radius * radius;
```

#### `OpalNumeric.E -> Float`

自然対数の底（ネイピア数）の値を取得します。

**戻り値**: 自然対数の底（e）の値

**使用例**:
```opal
nc value <- OpalNumeric.pow(OpalNumeric.E, x);
```

#### `OpalNumeric.INFINITY -> Float`

無限大を表す値を取得します。

**戻り値**: 無限大を表す値

**使用例**:
```opal
nc maxValue <- OpalNumeric.INFINITY;
```

#### `OpalNumeric.abs(x: Number) -> Number`

数値の絶対値を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 絶対値

**使用例**:
```opal
nc absValue <- OpalNumeric.abs(-5);
// 5
```

#### `OpalNumeric.max(...values: Number) -> Number`

複数の数値の最大値を取得します。

**パラメータ**:
- `...values`: 数値（可変長引数）

**戻り値**: 最大値

**使用例**:
```opal
nc maximum <- OpalNumeric.max(3, 7, 2, 9, 5);
// 9
```

#### `OpalNumeric.min(...values: Number) -> Number`

複数の数値の最小値を取得します。

**パラメータ**:
- `...values`: 数値（可変長引数）

**戻り値**: 最小値

**使用例**:
```opal
nc minimum <- OpalNumeric.min(3, 7, 2, 9, 5);
// 2
```

#### `OpalNumeric.round(x: Number) -> Integer`

数値を最も近い整数に丸めます。

**パラメータ**:
- `x`: 数値

**戻り値**: 丸められた整数

**使用例**:
```opal
nc rounded <- OpalNumeric.round(3.7);
// 4
```

#### `OpalNumeric.floor(x: Number) -> Integer`

数値を切り捨てます。

**パラメータ**:
- `x`: 数値

**戻り値**: 切り捨てられた整数

**使用例**:
```opal
nc floored <- OpalNumeric.floor(3.7);
// 3
```

#### `OpalNumeric.ceil(x: Number) -> Integer`

数値を切り上げます。

**パラメータ**:
- `x`: 数値

**戻り値**: 切り上げられた整数

**使用例**:
```opal
nc ceiled <- OpalNumeric.ceil(3.2);
// 4
```

#### `OpalNumeric.pow(base: Number, exponent: Number) -> Number`

べき乗を計算します。

**パラメータ**:
- `base`: 底
- `exponent`: 指数

**戻り値**: べき乗の結果

**使用例**:
```opal
nc squared <- OpalNumeric.pow(2, 3);
// 8
```

#### `OpalNumeric.sqrt(x: Number) -> Number`

平方根を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 平方根

**使用例**:
```opal
nc root <- OpalNumeric.sqrt(16);
// 4
```

#### `OpalNumeric.exp(x: Number) -> Number`

指数関数（e^x）を計算します。

**パラメータ**:
- `x`: 指数

**戻り値**: e^x

**使用例**:
```opal
nc result <- OpalNumeric.exp(2);
// e^2 ≈ 7.389
```

#### `OpalNumeric.log(x: Number) -> Number`

自然対数（底eの対数）を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 自然対数

**使用例**:
```opal
nc result <- OpalNumeric.log(10);
// ln(10) ≈ 2.303
```

#### `OpalNumeric.log10(x: Number) -> Number`

常用対数（底10の対数）を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 常用対数

**使用例**:
```opal
nc result <- OpalNumeric.log10(100);
// log10(100) = 2
```

#### `OpalNumeric.sin(x: Number) -> Number`

正弦（サイン）を計算します。

**パラメータ**:
- `x`: ラジアン単位の角度

**戻り値**: 正弦値

**使用例**:
```opal
nc result <- OpalNumeric.sin(OpalNumeric.PI / 2);
// sin(π/2) = 1
```

#### `OpalNumeric.cos(x: Number) -> Number`

余弦（コサイン）を計算します。

**パラメータ**:
- `x`: ラジアン単位の角度

**戻り値**: 余弦値

**使用例**:
```opal
nc result <- OpalNumeric.cos(OpalNumeric.PI);
// cos(π) = -1
```

#### `OpalNumeric.tan(x: Number) -> Number`

正接（タンジェント）を計算します。

**パラメータ**:
- `x`: ラジアン単位の角度

**戻り値**: 正接値

**使用例**:
```opal
nc result <- OpalNumeric.tan(OpalNumeric.PI / 4);
// tan(π/4) = 1
```

#### `OpalNumeric.random() -> Float`

0以上1未満のランダムな浮動小数点数を生成します。

**戻り値**: ランダムな浮動小数点数

**使用例**:
```opal
nc randomValue <- OpalNumeric.random();
```

### LinearAlgebra モジュール

#### `OpalNumeric.LinearAlgebra.createMatrix(rows: Integer, cols: Integer, initialValue: Number = 0) -> Matrix`

指定された行数と列数の行列を作成します。

**パラメータ**:
- `rows`: 行数
- `cols`: 列数
- `initialValue`: 初期値（デフォルト: 0）

**戻り値**: 新しい行列

**使用例**:
```opal
nc matrix <- OpalNumeric.LinearAlgebra.createMatrix(3, 3);
```

#### `OpalNumeric.LinearAlgebra.createMatrix(data: Array) -> Matrix`

2次元配列から行列を作成します。

**パラメータ**:
- `data`: 2次元配列

**戻り値**: 新しい行列

**使用例**:
```opal
nc matrix <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]);
```

#### `OpalNumeric.LinearAlgebra.identity(size: Integer) -> Matrix`

単位行列を作成します。

**パラメータ**:
- `size`: 行列のサイズ

**戻り値**: 単位行列

**使用例**:
```opal
nc identityMatrix <- OpalNumeric.LinearAlgebra.identity(3);
```

#### `OpalNumeric.LinearAlgebra.zeros(rows: Integer, cols: Integer) -> Matrix`

すべての要素が0の行列を作成します。

**パラメータ**:
- `rows`: 行数
- `cols`: 列数

**戻り値**: ゼロ行列

**使用例**:
```opal
nc zeroMatrix <- OpalNumeric.LinearAlgebra.zeros(3, 3);
```

#### `OpalNumeric.LinearAlgebra.ones(rows: Integer, cols: Integer) -> Matrix`

すべての要素が1の行列を作成します。

**パラメータ**:
- `rows`: 行数
- `cols`: 列数

**戻り値**: 1で満たされた行列

**使用例**:
```opal
nc onesMatrix <- OpalNumeric.LinearAlgebra.ones(3, 3);
```

#### `Matrix.get(row: Integer, col: Integer) -> Number`

行列の指定された位置の要素を取得します。

**パラメータ**:
- `row`: 行インデックス
- `col`: 列インデックス

**戻り値**: 要素の値

**使用例**:
```opal
nc value <- matrix.get(1, 2);
```

#### `Matrix.set(row: Integer, col: Integer, value: Number) -> Void`

行列の指定された位置に値を設定します。

**パラメータ**:
- `row`: 行インデックス
- `col`: 列インデックス
- `value`: 設定する値

**使用例**:
```opal
matrix.set(1, 2, 42);
```

#### `Matrix.rows() -> Integer`

行列の行数を取得します。

**戻り値**: 行数

**使用例**:
```opal
nc numRows <- matrix.rows();
```

#### `Matrix.cols() -> Integer`

行列の列数を取得します。

**戻り値**: 列数

**使用例**:
```opal
nc numCols <- matrix.cols();
```

#### `Matrix.add(other: Matrix) -> Matrix`

行列の加算を行います。

**パラメータ**:
- `other`: 加算する行列

**戻り値**: 加算結果の新しい行列

**使用例**:
```opal
nc result <- matrixA.add(matrixB);
```

#### `Matrix.subtract(other: Matrix) -> Matrix`

行列の減算を行います。

**パラメータ**:
- `other`: 減算する行列

**戻り値**: 減算結果の新しい行列

**使用例**:
```opal
nc result <- matrixA.subtract(matrixB);
```

#### `Matrix.multiply(other: Matrix) -> Matrix`

行列の乗算を行います。

**パラメータ**:
- `other`: 乗算する行列

**戻り値**: 乗算結果の新しい行列

**使用例**:
```opal
nc result <- matrixA.multiply(matrixB);
```

#### `Matrix.transpose() -> Matrix`

行列の転置を行います。

**戻り値**: 転置された新しい行列

**使用例**:
```opal
nc transposed <- matrix.transpose();
```

#### `Matrix.inverse() -> Matrix`

行列の逆行列を計算します。

**戻り値**: 逆行列

**使用例**:
```opal
nc inverted <- matrix.inverse();
```

#### `Matrix.determinant() -> Number`

行列式を計算します。

**戻り値**: 行列式の値

**使用例**:
```opal
nc det <- matrix.determinant();
```

#### `Matrix.eigenvalues() -> Array`

行列の固有値を計算します。

**戻り値**: 固有値の配列

**使用例**:
```opal
nc eigenvals <- matrix.eigenvalues();
```

#### `Matrix.eigenvectors() -> Map`

行列の固有ベクトルを計算します。

**戻り値**: 固有値と対応する固有ベクトルのマップ

**使用例**:
```opal
nc eigenvecs <- matrix.eigenvectors();
```

### Statistics モジュール

#### `OpalNumeric.Statistics.mean(data: Array) -> Number`

データの平均値を計算します。

**パラメータ**:
- `data`: 数値の配列

**戻り値**: 平均値

**使用例**:
```opal
nc average <- OpalNumeric.Statistics.mean([1, 2, 3, 4, 5]);
// 3
```

#### `OpalNumeric.Statistics.median(data: Array) -> Number`

データの中央値を計算します。

**パラメータ**:
- `data`: 数値の配列

**戻り値**: 中央値

**使用例**:
```opal
nc med <- OpalNumeric.Statistics.median([1, 3, 5, 7, 9]);
// 5
```

#### `OpalNumeric.Statistics.mode(data: Array) -> Array`

データの最頻値を計算します。

**パラメータ**:
- `data`: 数値の配列

**戻り値**: 最頻値の配列（複数の場合もある）

**使用例**:
```opal
nc modes <- OpalNumeric.Statistics.mode([1, 2, 2, 3, 3, 3, 4]);
// [3]
```

#### `OpalNumeric.Statistics.variance(data: Array) -> Number`

データの分散を計算します。

**パラメータ**:
- `data`: 数値の配列

**戻り値**: 分散

**使用例**:
```opal
nc var <- OpalNumeric.Statistics.variance([1, 2, 3, 4, 5]);
```

#### `OpalNumeric.Statistics.standardDeviation(data: Array) -> Number`

データの標準偏差を計算します。

**パラメータ**:
- `data`: 数値の配列

**戻り値**: 標準偏差

**使用例**:
```opal
nc std <- OpalNumeric.Statistics.standardDeviation([1, 2, 3, 4, 5]);
```

#### `OpalNumeric.Statistics.correlation(x: Array, y: Array) -> Number`

2つのデータセット間の相関係数を計算します。

**パラメータ**:
- `x`: 1つ目のデータセット
- `y`: 2つ目のデータセット

**戻り値**: 相関係数

**使用例**:
```opal
nc corr <- OpalNumeric.Statistics.correlation([1, 2, 3, 4], [2, 3, 5, 8]);
```

#### `OpalNumeric.Statistics.normalPDF(x: Number, mean: Number = 0, std: Number = 1) -> Number`

正規分布の確率密度関数（PDF）を計算します。

**パラメータ**:
- `x`: 評価する点
- `mean`: 平均（デフォルト: 0）
- `std`: 標準偏差（デフォルト: 1）

**戻り値**: PDF値

**使用例**:
```opal
nc pdf <- OpalNumeric.Statistics.normalPDF(1.5, 0, 1);
```

#### `OpalNumeric.Statistics.normalCDF(x: Number, mean: Number = 0, std: Number = 1) -> Number`

正規分布の累積分布関数（CDF）を計算します。

**パラメータ**:
- `x`: 評価する点
- `mean`: 平均（デフォルト: 0）
- `std`: 標準偏差（デフォルト: 1）

**戻り値**: CDF値

**使用例**:
```opal
nc cdf <- OpalNumeric.Statistics.normalCDF(1.5, 0, 1);
```

#### `OpalNumeric.Statistics.tTest(sample1: Array, sample2: Array) -> Map`

2つのサンプル間のt検定を実行します。

**パラメータ**:
- `sample1`: 1つ目のサンプル
- `sample2`: 2つ目のサンプル

**戻り値**: t値、p値、自由度を含むマップ

**使用例**:
```opal
nc result <- OpalNumeric.Statistics.tTest([1, 2, 3, 4, 5], [2, 3, 4, 5, 6]);
OpalSystemCall.("t値: " + result.tValue) -> out;
OpalSystemCall.("p値: " + result.pValue) -> out;
```

### Optimization モジュール

#### `OpalNumeric.Optimization.gradientDescent(func: Function, initialGuess: Array, learningRate: Number = 0.01, maxIterations: Integer = 1000, tolerance: Number = 1e-6) -> Map`

勾配降下法を使用して関数の最小値を見つけます。

**パラメータ**:
- `func`: 最小化する関数
- `initialGuess`: 初期推定値
- `learningRate`: 学習率（デフォルト: 0.01）
- `maxIterations`: 最大反復回数（デフォルト: 1000）
- `tolerance`: 収束許容誤差（デフォルト: 1e-6）

**戻り値**: 最適解、関数値、反復回数を含むマップ

**使用例**:
```opal
// x^2 + y^2 を最小化
nc func <- function(params: Array) -> Number then
    nc x <- params[0];
    nc y <- params[1];
    return x * x + y * y;
end;

nc result <- OpalNumeric.Optimization.gradientDescent(func, [10, 10]);
OpalSystemCall.("最適解: " + result.solution) -> out;
OpalSystemCall.("最小値: " + result.value) -> out;
```

#### `OpalNumeric.Optimization.newtonMethod(func: Function, initialGuess: Number, maxIterations: Integer = 100, tolerance: Number = 1e-6) -> Number`

ニュートン法を使用して関数の根を見つけます。

**パラメータ**:
- `func`: 根を見つける関数
- `initialGuess`: 初期推定値
- `maxIterations`: 最大反復回数（デフォルト: 100）
- `tolerance`: 収束許容誤差（デフォルト: 1e-6）

**戻り値**: 関数の根

**使用例**:
```opal
// x^2 - 4 = 0 の根を見つける
nc func <- function(x: Number) -> Number then
    return x * x - 4;
end;

nc root <- OpalNumeric.Optimization.newtonMethod(func, 1.0);
OpalSystemCall.("根: " + root) -> out;
```

#### `OpalNumeric.Optimization.linearProgramming(objectiveFunction: Array, constraints: Array, maximization: Boolean = true) -> Map`

線形計画問題を解きます。

**パラメータ**:
- `objectiveFunction`: 目的関数の係数
- `constraints`: 制約条件
- `maximization`: 最大化問題の場合は`true`、最小化問題の場合は`false`（デフォルト: `true`）

**戻り値**: 最適解、最適値を含むマップ

**使用例**:
```opal
// 最大化: 3x + 4y
// 制約: x + y <= 10, x >= 0, y >= 0
nc objective <- [3, 4];
nc constraints <- [
    { "coefficients": [1, 1], "operator": "<=", "value": 10 },
    { "coefficients": [1, 0], "operator": ">=", "value": 0 },
    { "coefficients": [0, 1], "operator": ">=", "value": 0 }
];

nc result <- OpalNumeric.Optimization.linearProgramming(objective, constraints);
OpalSystemCall.("最適解: " + result.solution) -> out;
OpalSystemCall.("最適値: " + result.value) -> out;
```

### Integration モジュール

#### `OpalNumeric.Integration.trapezoid(func: Function, a: Number, b: Number, n: Integer = 100) -> Number`

台形則を使用して定積分を計算します。

**パラメータ**:
- `func`: 積分する関数
- `a`: 下限
- `b`: 上限
- `n`: 分割数（デフォルト: 100）

**戻り値**: 積分値

**使用例**:
```opal
// ∫(0→1) x^2 dx を計算
nc func <- function(x: Number) -> Number then
    return x * x;
end;

nc integral <- OpalNumeric.Integration.trapezoid(func, 0, 1);
OpalSystemCall.("積分値: " + integral) -> out;
```

#### `OpalNumeric.Integration.simpson(func: Function, a: Number, b: Number, n: Integer = 100) -> Number`

シンプソン則を使用して定積分を計算します。

**パラメータ**:
- `func`: 積分する関数
- `a`: 下限
- `b`: 上限
- `n`: 分割数（デフォルト: 100）

**戻り値**: 積分値

**使用例**:
```opal
// ∫(0→π) sin(x) dx を計算
nc func <- function(x: Number) -> Number then
    return OpalNumeric.sin(x);
end;

nc integral <- OpalNumeric.Integration.simpson(func, 0, OpalNumeric.PI);
OpalSystemCall.("積分値: " + integral) -> out;
```

#### `OpalNumeric.Integration.gaussLegendre(func: Function, a: Number, b: Number, n: Integer = 5) -> Number`

ガウス・ルジャンドル積分を使用して定積分を計算します。

**パラメータ**:
- `func`: 積分する関数
- `a`: 下限
- `b`: 上限
- `n`: 積分点の数（デフォルト: 5）

**戻り値**: 積分値

**使用例**:
```opal
// ∫(0→1) e^x dx を計算
nc func <- function(x: Number) -> Number then
    return OpalNumeric.exp(x);
end;

nc integral <- OpalNumeric.Integration.gaussLegendre(func, 0, 1);
OpalSystemCall.("積分値: " + integral) -> out;
```

#### `OpalNumeric.Integration.monteCarlo(func: Function, a: Number, b: Number, samples: Integer = 10000) -> Number`

モンテカルロ法を使用して定積分を計算します。

**パラメータ**:
- `func`: 積分する関数
- `a`: 下限
- `b`: 上限
- `samples`: サンプル数（デフォルト: 10000）

**戻り値**: 積分値

**使用例**:
```opal
// ∫(0→1) sqrt(1-x^2) dx を計算（円の4分の1の面積）
nc func <- function(x: Number) -> Number then
    return OpalNumeric.sqrt(1 - x * x);
end;

nc integral <- OpalNumeric.Integration.monteCarlo(func, 0, 1, 100000);
OpalSystemCall.("積分値: " + integral) -> out;
```

### DifferentialEquations モジュール

#### `OpalNumeric.DifferentialEquations.eulerMethod(func: Function, y0: Number, t0: Number, t1: Number, h: Number) -> Map`

オイラー法を使用して常微分方程式を解きます。

**パラメータ**:
- `func`: 微分方程式の右辺（dy/dt = f(t, y)）
- `y0`: 初期値
- `t0`: 開始時間
- `t1`: 終了時間
- `h`: ステップサイズ

**戻り値**: 時間と解の配列を含むマップ

**使用例**:
```opal
// dy/dt = y, y(0) = 1 を解く（解析解: y = e^t）
nc func <- function(t: Number, y: Number) -> Number then
    return y;
end;

nc solution <- OpalNumeric.DifferentialEquations.eulerMethod(func, 1, 0, 1, 0.1);
OpalSystemCall.("時間: " + solution.t) -> out;
OpalSystemCall.("解: " + solution.y) -> out;
```

#### `OpalNumeric.DifferentialEquations.rungeKutta4(func: Function, y0: Number, t0: Number, t1: Number, h: Number) -> Map`

4次のルンゲ・クッタ法を使用して常微分方程式を解きます。

**パラメータ**:
- `func`: 微分方程式の右辺（dy/dt = f(t, y)）
- `y0`: 初期値
- `t0`: 開始時間
- `t1`: 終了時間
- `h`: ステップサイズ

**戻り値**: 時間と解の配列を含むマップ

**使用例**:
```opal
// dy/dt = -y, y(0) = 1 を解く（解析解: y = e^(-t)）
nc func <- function(t: Number, y: Number) -> Number then
    return -y;
end;

nc solution <- OpalNumeric.DifferentialEquations.rungeKutta4(func, 1, 0, 1, 0.1);
OpalSystemCall.("時間: " + solution.t) -> out;
OpalSystemCall.("解: " + solution.y) -> out;
```

#### `OpalNumeric.DifferentialEquations.solveSystem(funcs: Array, initialValues: Array, t0: Number, t1: Number, h: Number) -> Map`

連立常微分方程式を解きます。

**パラメータ**:
- `funcs`: 各方程式の右辺を表す関数の配列
- `initialValues`: 初期値の配列
- `t0`: 開始時間
- `t1`: 終了時間
- `h`: ステップサイズ

**戻り値**: 時間と解の配列を含むマップ

**使用例**:
```opal
// dx/dt = y, dy/dt = -x, x(0) = 0, y(0) = 1 を解く（単振動）
nc funcs <- [
    function(t: Number, x: Number, y: Number) -> Number then
        return y;
    end,
    function(t: Number, x: Number, y: Number) -> Number then
        return -x;
    end
];

nc solution <- OpalNumeric.DifferentialEquations.solveSystem(funcs, [0, 1], 0, 10, 0.1);
OpalSystemCall.("時間: " + solution.t) -> out;
OpalSystemCall.("x: " + solution.y[0]) -> out;
OpalSystemCall.("y: " + solution.y[1]) -> out;
```

### RandomNumbers モジュール

#### `OpalNumeric.RandomNumbers.uniform(min: Number = 0, max: Number = 1) -> Number`

一様分布からランダムな数値を生成します。

**パラメータ**:
- `min`: 最小値（デフォルト: 0）
- `max`: 最大値（デフォルト: 1）

**戻り値**: ランダムな数値

**使用例**:
```opal
nc randomValue <- OpalNumeric.RandomNumbers.uniform(1, 10);
```

#### `OpalNumeric.RandomNumbers.normal(mean: Number = 0, std: Number = 1) -> Number`

正規分布からランダムな数値を生成します。

**パラメータ**:
- `mean`: 平均（デフォルト: 0）
- `std`: 標準偏差（デフォルト: 1）

**戻り値**: ランダムな数値

**使用例**:
```opal
nc randomValue <- OpalNumeric.RandomNumbers.normal(5, 2);
```

#### `OpalNumeric.RandomNumbers.exponential(lambda: Number = 1) -> Number`

指数分布からランダムな数値を生成します。

**パラメータ**:
- `lambda`: レート（デフォルト: 1）

**戻り値**: ランダムな数値

**使用例**:
```opal
nc randomValue <- OpalNumeric.RandomNumbers.exponential(0.5);
```

#### `OpalNumeric.RandomNumbers.poisson(lambda: Number = 1) -> Integer`

ポアソン分布からランダムな整数を生成します。

**パラメータ**:
- `lambda`: 平均（デフォルト: 1）

**戻り値**: ランダムな整数

**使用例**:
```opal
nc randomValue <- OpalNumeric.RandomNumbers.poisson(3);
```

#### `OpalNumeric.RandomNumbers.seed(value: Integer) -> Void`

乱数生成器のシードを設定します。

**パラメータ**:
- `value`: シード値

**使用例**:
```opal
OpalNumeric.RandomNumbers.seed(12345);
```

#### `OpalNumeric.RandomNumbers.createArray(size: Integer, distribution: String = "uniform", params: Map = {}) -> Array`

指定された分布からランダムな数値の配列を生成します。

**パラメータ**:
- `size`: 配列のサイズ
- `distribution`: 分布の種類（"uniform"、"normal"、"exponential"、"poisson"）
- `params`: 分布のパラメータ

**戻り値**: ランダムな数値の配列

**使用例**:
```opal
nc randomArray <- OpalNumeric.RandomNumbers.createArray(10, "normal", { "mean": 0, "std": 1 });
```

## 使用例

### 行列演算の例

```opal
module MatrixExample then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // 行列の作成
        nc matrixA <- OpalNumeric.LinearAlgebra.createMatrix([
            [1, 2],
            [3, 4]
        ]);
        
        nc matrixB <- OpalNumeric.LinearAlgebra.createMatrix([
            [5, 6],
            [7, 8]
        ]);
        
        // 行列の加算
        nc sum <- matrixA.add(matrixB);
        OpalSystemCall.("A + B:") -> out;
        OpalSystemCall.(sum.toString()) -> out;
        
        // 行列の乗算
        nc product <- matrixA.multiply(matrixB);
        OpalSystemCall.("A * B:") -> out;
        OpalSystemCall.(product.toString()) -> out;
        
        // 行列の転置
        nc transposed <- matrixA.transpose();
        OpalSystemCall.("A^T:") -> out;
        OpalSystemCall.(transposed.toString()) -> out;
        
        // 行列式
        nc det <- matrixA.determinant();
        OpalSystemCall.("det(A): " + det) -> out;
        
        // 逆行列
        nc inverse <- matrixA.inverse();
        OpalSystemCall.("A^(-1):") -> out;
        OpalSystemCall.(inverse.toString()) -> out;
        
        // 固有値と固有ベクトル
        nc eigenvalues <- matrixA.eigenvalues();
        OpalSystemCall.("固有値: " + eigenvalues) -> out;
    end
end
```

### 統計計算の例

```opal
module StatisticsExample then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // データセット
        nc data <- [12, 15, 18, 22, 25, 28, 30, 35, 40, 45];
        
        // 基本統計量
        nc mean <- OpalNumeric.Statistics.mean(data);
        nc median <- OpalNumeric.Statistics.median(data);
        nc variance <- OpalNumeric.Statistics.variance(data);
        nc std <- OpalNumeric.Statistics.standardDeviation(data);
        
        OpalSystemCall.("データセット: " + data) -> out;
        OpalSystemCall.("平均: " + mean) -> out;
        OpalSystemCall.("中央値: " + median) -> out;
        OpalSystemCall.("分散: " + variance) -> out;
        OpalSystemCall.("標準偏差: " + std) -> out;
        
        // 正規分布
        nc x <- 1.5;
        nc pdf <- OpalNumeric.Statistics.normalPDF(x);
        nc cdf <- OpalNumeric.Statistics.normalCDF(x);
        
        OpalSystemCall.("標準正規分布 (x = " + x + "):") -> out;
        OpalSystemCall.("PDF: " + pdf) -> out;
        OpalSystemCall.("CDF: " + cdf) -> out;
        
        // 相関係数
        nc x_data <- [1, 2, 3, 4, 5];
        nc y_data <- [2, 4, 5, 4, 5];
        nc correlation <- OpalNumeric.Statistics.correlation(x_data, y_data);
        
        OpalSystemCall.("相関係数: " + correlation) -> out;
    end
end
```

### 最適化の例

```opal
module OptimizationExample then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // 勾配降下法
        // f(x, y) = x^2 + y^2 を最小化
        nc func <- function(params: Array) -> Number then
            nc x <- params[0];
            nc y <- params[1];
            return x * x + y * y;
        end;
        
        nc result <- OpalNumeric.Optimization.gradientDescent(func, [10, 10]);
        
        OpalSystemCall.("勾配降下法:") -> out;
        OpalSystemCall.("最適解: " + result.solution) -> out;
        OpalSystemCall.("最小値: " + result.value) -> out;
        OpalSystemCall.("反復回数: " + result.iterations) -> out;
        
        // ニュートン法
        // f(x) = x^2 - 4 = 0 の根を見つける
        nc rootFunc <- function(x: Number) -> Number then
            return x * x - 4;
        end;
        
        nc root <- OpalNumeric.Optimization.newtonMethod(rootFunc, 1.0);
        
        OpalSystemCall.("ニュートン法:") -> out;
        OpalSystemCall.("根: " + root) -> out;
    end
end
```

### 微分方程式の例

```opal
module DifferentialEquationsExample then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // dy/dt = y, y(0) = 1 を解く（解析解: y = e^t）
        nc func <- function(t: Number, y: Number) -> Number then
            return y;
        end;
        
        // オイラー法
        nc eulerSolution <- OpalNumeric.DifferentialEquations.eulerMethod(func, 1, 0, 1, 0.1);
        
        OpalSystemCall.("オイラー法:") -> out;
        OpalSystemCall.("t = 1 での y の値: " + eulerSolution.y[eulerSolution.y.length() - 1]) -> out;
        OpalSystemCall.("解析解: " + OpalNumeric.exp(1)) -> out;
        
        // ルンゲ・クッタ法
        nc rkSolution <- OpalNumeric.DifferentialEquations.rungeKutta4(func, 1, 0, 1, 0.1);
        
        OpalSystemCall.("ルンゲ・クッタ法:") -> out;
        OpalSystemCall.("t = 1 での y の値: " + rkSolution.y[rkSolution.y.length() - 1]) -> out;
        
        // 連立微分方程式（単振動）
        // dx/dt = y, dy/dt = -x, x(0) = 0, y(0) = 1
        nc systemFuncs <- [
            function(t: Number, x: Number, y: Number) -> Number then
                return y;
            end,
            function(t: Number, x: Number, y: Number) -> Number then
                return -x;
            end
        ];
        
        nc systemSolution <- OpalNumeric.DifferentialEquations.solveSystem(systemFuncs, [0, 1], 0, 2 * OpalNumeric.PI, 0.1);
        
        OpalSystemCall.("単振動:") -> out;
        OpalSystemCall.("t = 2π での x の値: " + systemSolution.y[0][systemSolution.y[0].length() - 1]) -> out;
        OpalSystemCall.("t = 2π での y の値: " + systemSolution.y[1][systemSolution.y[1].length() - 1]) -> out;
    end
end
```

### 乱数生成の例

```opal
module RandomNumbersExample then
    function first() -> Void then
        // OpalNumericを初期化
        OpalNumeric.initialize();
        
        // シードを設定
        OpalNumeric.RandomNumbers.seed(12345);
        
        // 一様分布
        OpalSystemCall.("一様分布:") -> out;
        for (nc i <- 0; i < 5; i <- i + 1) then
            nc value <- OpalNumeric.RandomNumbers.uniform(1, 10);
            OpalSystemCall.("  " + value) -> out;
        end
        
        // 正規分布
        OpalSystemCall.("正規分布 (平均 = 5, 標準偏差 = 2):") -> out;
        for (nc i <- 0; i < 5; i <- i + 1) then
            nc value <- OpalNumeric.RandomNumbers.normal(5, 2);
            OpalSystemCall.("  " + value) -> out;
        end
        
        // ポアソン分布
        OpalSystemCall.("ポアソン分布 (λ = 3):") -> out;
        for (nc i <- 0; i < 5; i <- i + 1) then
            nc value <- OpalNumeric.RandomNumbers.poisson(3);
            OpalSystemCall.("  " + value) -> out;
        end
        
        // ランダム配列
        nc randomArray <- OpalNumeric.RandomNumbers.createArray(10, "normal", { "mean": 0, "std": 1 });
        OpalSystemCall.("正規分布のランダム配列:") -> out;
        OpalSystemCall.("  " + randomArray) -> out;
    end
end
```

## ライセンス

OpalNumericライブラリはMITライセンスの下で提供されています。
