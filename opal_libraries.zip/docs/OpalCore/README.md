# OpalCore ライブラリドキュメント

## 概要

OpalCoreは、Opal言語の基本機能と共通ユーティリティを提供するライブラリです。このライブラリは、コレクション操作、テキスト処理、日付時間処理、ファイルシステム操作、並行処理、ネットワーク通信、関数型プログラミングユーティリティなど、アプリケーション開発に必要な基本的な機能を提供します。

## モジュール構成

OpalCoreライブラリは以下のサブモジュールで構成されています：

1. **Collections** - 拡張配列、マップ、セットなどのコレクション操作
2. **Text** - 文字列操作、検索、置換、分割、結合など
3. **DateTime** - 日付と時間の処理、期間計算など
4. **FileSystem** - ファイルとディレクトリの操作
5. **OVM** - Opal Virtual Machine（バイトコードインタプリタとコンパイラ）
6. **Concurrency** - 並行処理、Future、Promise、Mutexなど
7. **Network** - HTTP、WebSocket、TCP、UDP通信
8. **Functional** - 関数型プログラミングユーティリティ

## インストール方法

OpalCoreライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalCore`ディレクトリとそのサブディレクトリをプロジェクトにコピーします
2. Opalプログラムの先頭で`OpalCore`モジュールをインポートします

```opal
// OpalCoreモジュールをインポート
import OpalCore;

module MyApp then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalCore!") -> out;
    end
end
```

## API リファレンス

### コアモジュール

#### `OpalCore.initialize() -> Boolean`

OpalCoreライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalCore.initialize();
```

#### `OpalCore.VERSION -> String`

OpalCoreライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.0.0"）

**使用例**:
```opal
OpalSystemCall.("OpalCore version: " + OpalCore.VERSION) -> out;
```

#### `OpalCore.isInitialized() -> Boolean`

OpalCoreライブラリが初期化されているかどうかを確認します。

**戻り値**: 初期化されている場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if (!OpalCore.isInitialized()) then
    OpalCore.initialize();
end
```

### Collections モジュール

#### `OpalCore.Collections.createArray(...items: Any) -> Array`

新しい拡張配列を作成します。

**パラメータ**:
- `...items`: 配列に追加する要素（可変長引数）

**戻り値**: 新しい拡張配列

**使用例**:
```opal
nc myArray <- OpalCore.Collections.createArray(1, 2, 3, 4, 5);
```

#### `OpalCore.Collections.range(start: Integer, end: Integer, step: Integer = 1) -> Array`

指定された範囲の整数値を含む配列を生成します。

**パラメータ**:
- `start`: 開始値（含む）
- `end`: 終了値（含まない）
- `step`: ステップ値（デフォルト: 1）

**戻り値**: 指定された範囲の整数値を含む配列

**使用例**:
```opal
nc numbers <- OpalCore.Collections.range(0, 10, 2);
// [0, 2, 4, 6, 8]
```

#### `OpalCore.Collections.shuffle(array: Array) -> Array`

配列の要素をランダムに並べ替えます。

**パラメータ**:
- `array`: 並べ替える配列

**戻り値**: 要素がランダムに並べ替えられた新しい配列

**使用例**:
```opal
nc shuffled <- OpalCore.Collections.shuffle(myArray);
```

#### `Array.map(callback: Function) -> Array`

配列の各要素に対してコールバック関数を適用し、その結果から新しい配列を作成します。

**パラメータ**:
- `callback`: 各要素に適用する関数 `function(item: Any, index: Integer, array: Array) -> Any`

**戻り値**: コールバック関数の結果を含む新しい配列

**使用例**:
```opal
nc doubled <- myArray.map(function(x: Integer) -> Integer then
    return x * 2;
end);
```

#### `Array.filter(callback: Function) -> Array`

コールバック関数が`true`を返す要素のみを含む新しい配列を作成します。

**パラメータ**:
- `callback`: 各要素をテストする関数 `function(item: Any, index: Integer, array: Array) -> Boolean`

**戻り値**: 条件を満たす要素のみを含む新しい配列

**使用例**:
```opal
nc evenNumbers <- myArray.filter(function(x: Integer) -> Boolean then
    return x % 2 == 0;
end);
```

#### `Array.reduce(callback: Function, initialValue: Any) -> Any`

配列の各要素に対してコールバック関数を適用し、単一の値に集約します。

**パラメータ**:
- `callback`: 集約関数 `function(accumulator: Any, currentValue: Any, index: Integer, array: Array) -> Any`
- `initialValue`: 初期値

**戻り値**: 集約された値

**使用例**:
```opal
nc sum <- myArray.reduce(function(acc: Integer, val: Integer) -> Integer then
    return acc + val;
end, 0);
```

### Text モジュール

#### `OpalCore.Text.format(template: String, ...args: Any) -> String`

テンプレート文字列と引数を使用して書式設定された文字列を作成します。

**パラメータ**:
- `template`: テンプレート文字列（`{}`をプレースホルダとして使用）
- `...args`: プレースホルダを置き換える値

**戻り値**: 書式設定された文字列

**使用例**:
```opal
nc name <- "Opal";
nc age <- 30;
nc message <- OpalCore.Text.format("名前: {}, 年齢: {}", name, age);
// "名前: Opal, 年齢: 30"
```

#### `OpalCore.Text.padStart(str: String, targetLength: Integer, padString: String = " ") -> String`

文字列の先頭にパディング文字を追加して、指定された長さにします。

**パラメータ**:
- `str`: パディングする文字列
- `targetLength`: 目標の長さ
- `padString`: パディングに使用する文字列（デフォルト: 空白）

**戻り値**: パディングされた文字列

**使用例**:
```opal
nc paddedNumber <- OpalCore.Text.padStart("42", 5, "0");
// "00042"
```

#### `OpalCore.Text.padEnd(str: String, targetLength: Integer, padString: String = " ") -> String`

文字列の末尾にパディング文字を追加して、指定された長さにします。

**パラメータ**:
- `str`: パディングする文字列
- `targetLength`: 目標の長さ
- `padString`: パディングに使用する文字列（デフォルト: 空白）

**戻り値**: パディングされた文字列

**使用例**:
```opal
nc paddedText <- OpalCore.Text.padEnd("Hello", 10, "-");
// "Hello-----"
```

#### `String.split(separator: String) -> Array`

文字列を指定された区切り文字で分割し、配列を返します。

**パラメータ**:
- `separator`: 区切り文字

**戻り値**: 分割された文字列の配列

**使用例**:
```opal
nc parts <- "apple,banana,orange".split(",");
// ["apple", "banana", "orange"]
```

#### `String.replace(searchValue: String, replaceValue: String) -> String`

文字列内の検索文字列をすべて置換文字列に置き換えます。

**パラメータ**:
- `searchValue`: 検索する文字列
- `replaceValue`: 置換する文字列

**戻り値**: 置換後の新しい文字列

**使用例**:
```opal
nc newText <- "Hello, world!".replace("world", "Opal");
// "Hello, Opal!"
```

### DateTime モジュール

#### `OpalCore.DateTime.now() -> Integer`

現在のUNIXタイムスタンプをミリ秒単位で取得します。

**戻り値**: 現在のUNIXタイムスタンプ（ミリ秒）

**使用例**:
```opal
nc timestamp <- OpalCore.DateTime.now();
```

#### `OpalCore.DateTime.createDate(year: Integer, month: Integer, day: Integer, hour: Integer = 0, minute: Integer = 0, second: Integer = 0, millisecond: Integer = 0) -> Map`

指定された日時情報から日付オブジェクトを作成します。

**パラメータ**:
- `year`: 年
- `month`: 月（1〜12）
- `day`: 日
- `hour`: 時（デフォルト: 0）
- `minute`: 分（デフォルト: 0）
- `second`: 秒（デフォルト: 0）
- `millisecond`: ミリ秒（デフォルト: 0）

**戻り値**: 日付オブジェクト

**使用例**:
```opal
nc date <- OpalCore.DateTime.createDate(2023, 4, 15, 14, 30);
```

#### `OpalCore.DateTime.format(date: Map, format: String) -> String`

日付オブジェクトを指定されたフォーマットで文字列に変換します。

**パラメータ**:
- `date`: 日付オブジェクト
- `format`: 日付フォーマット文字列

**戻り値**: フォーマットされた日付文字列

**使用例**:
```opal
nc formattedDate <- OpalCore.DateTime.format(date, "YYYY-MM-DD HH:mm:ss");
// "2023-04-15 14:30:00"
```

#### `OpalCore.DateTime.addDays(date: Map, days: Integer) -> Map`

日付オブジェクトに指定された日数を加算します。

**パラメータ**:
- `date`: 日付オブジェクト
- `days`: 加算する日数

**戻り値**: 新しい日付オブジェクト

**使用例**:
```opal
nc newDate <- OpalCore.DateTime.addDays(date, 7);
```

### FileSystem モジュール

#### `OpalCore.FileSystem.readFile(path: String) -> String`

ファイルの内容を読み込みます。

**パラメータ**:
- `path`: ファイルパス

**戻り値**: ファイルの内容

**使用例**:
```opal
nc content <- OpalCore.FileSystem.readFile("/path/to/file.txt");
```

#### `OpalCore.FileSystem.writeFile(path: String, content: String) -> Boolean`

ファイルに内容を書き込みます。

**パラメータ**:
- `path`: ファイルパス
- `content`: 書き込む内容

**戻り値**: 書き込みが成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalCore.FileSystem.writeFile("/path/to/file.txt", "Hello, Opal!");
```

#### `OpalCore.FileSystem.fileExists(path: String) -> Boolean`

ファイルが存在するかどうかを確認します。

**パラメータ**:
- `path`: ファイルパス

**戻り値**: ファイルが存在する場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if (OpalCore.FileSystem.fileExists("/path/to/file.txt")) then
    // ファイルが存在する場合の処理
end
```

#### `OpalCore.FileSystem.createDirectory(path: String) -> Boolean`

ディレクトリを作成します。

**パラメータ**:
- `path`: ディレクトリパス

**戻り値**: ディレクトリの作成が成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalCore.FileSystem.createDirectory("/path/to/directory");
```

### Concurrency モジュール

#### `OpalCore.Concurrency.setTimeout(callback: Function, delay: Integer) -> Any`

指定された遅延後にコールバック関数を実行します。

**パラメータ**:
- `callback`: 実行する関数
- `delay`: 遅延時間（ミリ秒）

**戻り値**: タイマーID（`clearTimeout`で使用）

**使用例**:
```opal
nc timerId <- OpalCore.Concurrency.setTimeout(function() -> Void then
    OpalSystemCall.("タイマー実行!") -> out;
end, 1000);
```

#### `OpalCore.Concurrency.clearTimeout(id: Any) -> Void`

`setTimeout`で設定されたタイマーをキャンセルします。

**パラメータ**:
- `id`: タイマーID

**使用例**:
```opal
OpalCore.Concurrency.clearTimeout(timerId);
```

#### `OpalCore.Concurrency.createFuture() -> Map`

新しいFutureオブジェクトを作成します。

**戻り値**: Futureオブジェクト（`resolve`、`reject`、`then`、`catch`メソッドを持つ）

**使用例**:
```opal
nc future <- OpalCore.Concurrency.createFuture();

// 非同期処理
OpalCore.Concurrency.setTimeout(function() -> Void then
    future.resolve("成功!");
end, 1000);

// 結果の処理
future.then(function(result: String) -> Void then
    OpalSystemCall.(result) -> out;
end).catch(function(error: Any) -> Void then
    OpalSystemCall.("エラー: " + error) -> out;
end);
```

### Network モジュール

#### `OpalCore.Network.httpRequest(options: Map) -> Map`

HTTPリクエストを送信します。

**パラメータ**:
- `options`: リクエストオプション
  - `url`: リクエストURL
  - `method`: HTTPメソッド（"GET"、"POST"など）
  - `headers`: リクエストヘッダー
  - `body`: リクエストボディ
  - `timeout`: タイムアウト（ミリ秒）

**戻り値**: Futureオブジェクト（レスポンスで解決される）

**使用例**:
```opal
nc requestOptions <- {
    "url": "https://api.example.com/data",
    "method": "GET",
    "headers": {
        "Content-Type": "application/json"
    }
};

nc responseFuture <- OpalCore.Network.httpRequest(requestOptions);

responseFuture.then(function(response: Map) -> Void then
    OpalSystemCall.("ステータス: " + response.status) -> out;
    OpalSystemCall.("データ: " + response.data) -> out;
end).catch(function(error: Any) -> Void then
    OpalSystemCall.("エラー: " + error) -> out;
end);
```

### Functional モジュール

#### `OpalCore.Functional.curry(fn: Function, arity: Integer = null) -> Function`

関数をカリー化します。

**パラメータ**:
- `fn`: カリー化する関数
- `arity`: 関数の引数の数（指定しない場合は関数の引数の数を使用）

**戻り値**: カリー化された関数

**使用例**:
```opal
nc add <- function(a: Integer, b: Integer) -> Integer then
    return a + b;
end;

nc curriedAdd <- OpalCore.Functional.curry(add);
nc add5 <- curriedAdd(5);
nc result <- add5(3); // 8
```

#### `OpalCore.Functional.compose(...fns: Function) -> Function`

複数の関数を合成します。

**パラメータ**:
- `...fns`: 合成する関数（右から左の順に適用）

**戻り値**: 合成された関数

**使用例**:
```opal
nc double <- function(x: Integer) -> Integer then
    return x * 2;
end;

nc addOne <- function(x: Integer) -> Integer then
    return x + 1;
end;

nc doubleThenAddOne <- OpalCore.Functional.compose(addOne, double);
nc result <- doubleThenAddOne(5); // 11
```

#### `OpalCore.Functional.pipe(...fns: Function) -> Function`

複数の関数をパイプラインとして連結します。

**パラメータ**:
- `...fns`: 連結する関数（左から右の順に適用）

**戻り値**: パイプライン関数

**使用例**:
```opal
nc addOne <- function(x: Integer) -> Integer then
    return x + 1;
end;

nc double <- function(x: Integer) -> Integer then
    return x * 2;
end;

nc addOneThenDouble <- OpalCore.Functional.pipe(addOne, double);
nc result <- addOneThenDouble(5); // 12
```

## 使用例

### 基本的な使用例

```opal
module MyApp then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // 配列操作
        nc numbers <- OpalCore.Collections.createArray(1, 2, 3, 4, 5);
        nc doubled <- numbers.map(function(x: Integer) -> Integer then
            return x * 2;
        end);
        
        OpalSystemCall.("元の配列: " + numbers.toString()) -> out;
        OpalSystemCall.("2倍の配列: " + doubled.toString()) -> out;
        
        // 文字列操作
        nc message <- OpalCore.Text.format("こんにちは、{}さん！今日は{}です。", "田中", "月曜日");
        OpalSystemCall.(message) -> out;
        
        // 日付操作
        nc now <- OpalCore.DateTime.now();
        nc date <- OpalCore.DateTime.createDate(2023, 4, 15);
        nc formattedDate <- OpalCore.DateTime.format(date, "YYYY年MM月DD日");
        
        OpalSystemCall.("現在のタイムスタンプ: " + now) -> out;
        OpalSystemCall.("フォーマットされた日付: " + formattedDate) -> out;
    end
end
```

### 非同期処理の例

```opal
module AsyncExample then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        OpalSystemCall.("非同期処理を開始します...") -> out;
        
        // Futureを使用した非同期処理
        nc future <- OpalCore.Concurrency.createFuture();
        
        // 非同期タスクをシミュレート
        OpalCore.Concurrency.setTimeout(function() -> Void then
            future.resolve("非同期処理が完了しました！");
        end, 2000);
        
        // 結果の処理
        future.then(function(result: String) -> Void then
            OpalSystemCall.(result) -> out;
            
            // HTTPリクエストを送信
            return OpalCore.Network.httpRequest({
                "url": "https://jsonplaceholder.typicode.com/todos/1",
                "method": "GET"
            });
        end).then(function(response: Map) -> Void then
            OpalSystemCall.("APIレスポンス: " + response.data) -> out;
        end).catch(function(error: Any) -> Void then
            OpalSystemCall.("エラーが発生しました: " + error) -> out;
        end);
        
        OpalSystemCall.("非同期処理を開始しました。結果を待っています...") -> out;
    end
end
```

### 関数型プログラミングの例

```opal
module FunctionalExample then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // カリー化
        nc add <- function(a: Integer, b: Integer) -> Integer then
            return a + b;
        end;
        
        nc curriedAdd <- OpalCore.Functional.curry(add);
        nc add5 <- curriedAdd(5);
        
        OpalSystemCall.("5 + 3 = " + add5(3)) -> out;
        
        // 関数合成
        nc double <- function(x: Integer) -> Integer then
            return x * 2;
        end;
        
        nc addOne <- function(x: Integer) -> Integer then
            return x + 1;
        end;
        
        nc doubleThenAddOne <- OpalCore.Functional.compose(addOne, double);
        nc addOneThenDouble <- OpalCore.Functional.pipe(addOne, double);
        
        OpalSystemCall.("doubleThenAddOne(5) = " + doubleThenAddOne(5)) -> out;
        OpalSystemCall.("addOneThenDouble(5) = " + addOneThenDouble(5)) -> out;
        
        // 配列の関数型操作
        nc numbers <- OpalCore.Collections.createArray(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        
        nc result <- numbers
            .filter(function(x: Integer) -> Boolean then
                return x % 2 == 0; // 偶数のみ
            end)
            .map(function(x: Integer) -> Integer then
                return x * x; // 2乗
            end)
            .reduce(function(acc: Integer, val: Integer) -> Integer then
                return acc + val; // 合計
            end, 0);
        
        OpalSystemCall.("偶数の2乗の合計: " + result) -> out;
    end
end
```

## ライセンス

OpalCoreライブラリはMITライセンスの下で提供されています。
