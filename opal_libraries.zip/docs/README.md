# Opal ライブラリドキュメント

## 概要

このドキュメントは、Opal言語用に開発された一連のライブラリについて説明します。これらのライブラリは、Julia、Python、JavaScriptの各言語の強みを取り入れつつ、Opal言語の特性を活かした独自の実装となっています。

## ライブラリ構成

Opalライブラリは以下の5つの主要モジュールで構成されています：

1. **OpalCore** - 基本機能と共通ユーティリティ
2. **OpalNumeric** - Julia風の科学計算・数値処理ライブラリ
3. **OpalData** - Python風のデータ処理・分析ライブラリ
4. **OpalUI** - JavaScript風のUI・Webフレームワーク
5. **OpalCross** - 上記ライブラリの機能を統合したクロス言語機能

各ライブラリの詳細なドキュメントは、それぞれのディレクトリにあります：

- [OpalCore ドキュメント](./OpalCore/README.md)
- [OpalNumeric ドキュメント](./OpalNumeric/README.md)
- [OpalData ドキュメント](./OpalData/README.md)
- [OpalUI ドキュメント](./OpalUI/README.md)
- [OpalCross ドキュメント](./OpalCross/README.md)

## インストール方法

Opalライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. ライブラリファイルをプロジェクトディレクトリにコピーします
2. Opalプログラムの先頭で必要なモジュールをインポートします

```opal
// 必要なモジュールをインポート
import OpalCore;
import OpalNumeric;
import OpalData;
import OpalUI;
import OpalCross;

module MyApp then
    function first() -> Void then
        // ライブラリを初期化
        OpalCore.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, Opal Libraries!") -> out;
    end
end
```

## 基本的な使用例

### OpalCore の使用例

```opal
// 拡張配列の使用
nc myArray <- OpalCore.Collections.createArray(1, 2, 3, 4, 5);
nc doubled <- myArray.map(function(x: Integer) -> Integer then
    return x * 2;
end);

OpalSystemCall.(doubled.toString()) -> out; // [2, 4, 6, 8, 10]
```

### OpalNumeric の使用例

```opal
// 行列演算
nc matrixA <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2],
    [3, 4]
]);

nc matrixB <- OpalNumeric.LinearAlgebra.createMatrix([
    [5, 6],
    [7, 8]
]);

nc result <- matrixA.multiply(matrixB);
OpalSystemCall.(result.toString()) -> out;
```

### OpalData の使用例

```opal
// データフレームの作成と操作
nc data <- {
    "名前": ["田中", "佐藤", "鈴木", "高橋"],
    "年齢": [25, 30, 45, 22],
    "給与": [300000, 350000, 450000, 280000]
};

nc df <- OpalData.DataFrame.createDataFrame(data);
nc filtered <- df.filter(function(row: Map) -> Boolean then
    return row.年齢 > 25;
end);

OpalSystemCall.(filtered.toString()) -> out;
```

### OpalUI の使用例

```opal
// シンプルなUIコンポーネント
function MyComponent(props: Map, state: Map) -> Map then
    // カウンター状態
    nc countState <- OpalUI.State.useState(0);
    nc count <- countState[0];
    nc setCount <- countState[1];
    
    // クリックハンドラ
    nc handleClick <- function() -> Void then
        setCount(count + 1);
    end;
    
    // UIを返す
    return OpalUI.createElement("div", {}, [
        OpalUI.createElement("h1", {}, ["カウンター: " + count]),
        OpalUI.createElement("button", {
            "onClick": handleClick
        }, ["増加"])
    ]);
end

// アプリケーションのレンダリング
OpalUI.render(MyComponent, document.getElementById("app"));
```

### OpalCross の使用例

```opal
// 行列からデータフレームへの変換
nc matrix <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]);

nc columnNames <- ["A", "B", "C"];
nc df <- OpalCross.matrixToDataFrame(matrix, columnNames);

// データフレームをUIテーブルに変換
nc tableComponent <- OpalCross.dataFrameToUITable(df, {
    "striped": true,
    "bordered": true
});

// テーブルをレンダリング
OpalUI.render(tableComponent, document.getElementById("table-container"));
```

## ライセンス

これらのライブラリはオープンソースとして提供され、MITライセンスの下で利用可能です。

## 貢献

バグ報告や機能リクエストは、イシュートラッカーを通じてお願いします。プルリクエストも歓迎します。

## 作者

Opalライブラリチーム
