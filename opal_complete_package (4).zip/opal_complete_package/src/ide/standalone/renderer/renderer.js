// Opal言語用のMonacoエディタ設定
require.config({ paths: { vs: '../node_modules/monaco-editor/min/vs' } });

// MonacoエディタとElectronのIPCレンダラーを読み込む
let monaco;
const { ipcRenderer } = nodeRequire('electron');
const path = nodeRequire('path');
const fs = nodeRequire('fs');

// グローバル変数
let editor;
let currentFile = null;
let currentProject = null;
let openFiles = [];
let fileTree = null;
let config = {
  theme: 'light',
  fontSize: 14,
  tabSize: 4,
  wordWrap: 'off',
  autoSave: true,
  opalPath: 'opal',
  opalArgs: ''
};

// DOMが読み込まれたら初期化
document.addEventListener('DOMContentLoaded', () => {
  // 設定を読み込む
  loadConfig();
  
  // MonacoエディタとOpal言語の設定を初期化
  initMonaco();
  
  // UIイベントリスナーを設定
  setupEventListeners();
  
  // 最近のプロジェクトを読み込む
  loadRecentProjects();
});

// 設定を読み込む
async function loadConfig() {
  try {
    const loadedConfig = await ipcRenderer.invoke('get-config');
    config = { ...config, ...loadedConfig };
    
    // UIに設定を適用
    applyConfig();
  } catch (error) {
    console.error('設定の読み込みに失敗しました:', error);
  }
}

// 設定をUIに適用
function applyConfig() {
  // テーマの適用
  document.getElementById('theme-css').href = `../assets/css/themes/${config.theme}.css`;
  document.getElementById('theme').value = config.theme;
  
  // エディタ設定
  document.getElementById('font-size').value = config.fontSize;
  document.getElementById('tab-size').value = config.tabSize;
  document.getElementById('word-wrap').value = config.wordWrap;
  document.getElementById('auto-save').checked = config.autoSave;
  
  // Opal設定
  document.getElementById('opal-path').value = config.opalPath;
  document.getElementById('opal-args').value = config.opalArgs || '';
  
  // エディタが初期化されていれば設定を適用
  if (editor) {
    editor.updateOptions({
      fontSize: config.fontSize,
      tabSize: config.tabSize,
      wordWrap: config.wordWrap
    });
    
    monaco.editor.setTheme(config.theme === 'dark' ? 'vs-dark' : 'vs');
  }
}

// Monacoエディタの初期化
function initMonaco() {
  require(['vs/editor/editor.main'], function() {
    // Opal言語の定義
    monaco = window.monaco;
    
    // Opal言語の構文定義
    monaco.languages.register({ id: 'opal' });
    
    monaco.languages.setMonarchTokensProvider('opal', {
      tokenizer: {
        root: [
          // コメント
          [/\/\/.*$/, 'comment'],
          
          // 文字列
          [/"([^"\\]|\\.)*$/, 'string.invalid'],
          [/"/, { token: 'string.quote', bracket: '@open', next: '@string' }],
          
          // 数値
          [/\d*\.\d+([eE][\-+]?\d+)?/, 'number.float'],
          [/\d+/, 'number'],
          
          // キーワード
          [/\b(module|function|class|if|else|then|end|while|for|in|when|return|import|new|nc|let)\b/, 'keyword'],
          
          // 型
          [/\b(Integer|Float|String|Boolean|Void|Array)\b/, 'type'],
          
          // 特殊なOpal構文
          [/->/, 'operator.arrow'],
          [/=>/, 'operator.double-arrow'],
          [/\bout\b/, 'keyword.output'],
          [/\bfirst\b/, 'keyword.entry-point'],
          
          // 識別子
          [/[a-zA-Z_]\w*/, 'identifier'],
          
          // 演算子
          [/[+\-*\/=<>!&|]+/, 'operator'],
          
          // 括弧
          [/[{}()\[\]]/, '@brackets'],
          
          // その他
          [/[;,.]/, 'delimiter']
        ],
        
        string: [
          [/[^\\"]+/, 'string'],
          [/\\./, 'string.escape'],
          [/"/, { token: 'string.quote', bracket: '@close', next: '@pop' }]
        ]
      }
    });
    
    // Opal言語の補完プロバイダー
    monaco.languages.registerCompletionItemProvider('opal', {
      provideCompletionItems: function(model, position) {
        const suggestions = [
          // キーワード
          { label: 'module', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'module ${1:ModuleName} then\n\t$0\nend' },
          { label: 'function', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'function ${1:name}(${2:params}) -> ${3:ReturnType} then\n\t$0\nend' },
          { label: 'class', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'class ${1:ClassName} then\n\t$0\nend' },
          { label: 'if', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'if ${1:condition} then\n\t$0\nend' },
          { label: 'else', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'else\n\t$0' },
          { label: 'while', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'while ${1:condition} then\n\t$0\nend' },
          { label: 'for', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'for ${1:item} in ${2:collection} then\n\t$0\nend' },
          { label: 'when', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'when ${1:condition} then\n\t$0\nend' },
          { label: 'return', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'return ${1:value};' },
          { label: 'import', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'import ${1:ModuleName}' },
          { label: 'nc', kind: monaco.languages.CompletionItemKind.Keyword, insertText: 'nc ${1:name} <- ${2:value};' },
          
          // 型
          { label: 'Integer', kind: monaco.languages.CompletionItemKind.Class },
          { label: 'Float', kind: monaco.languages.CompletionItemKind.Class },
          { label: 'String', kind: monaco.languages.CompletionItemKind.Class },
          { label: 'Boolean', kind: monaco.languages.CompletionItemKind.Class },
          { label: 'Void', kind: monaco.languages.CompletionItemKind.Class },
          { label: 'Array', kind: monaco.languages.CompletionItemKind.Class },
          
          // スニペット
          { 
            label: 'first',
            kind: monaco.languages.CompletionItemKind.Function,
            insertText: 'function first() -> Void then\n\t$0\nend',
            documentation: 'Opalプログラムのエントリーポイント'
          },
          { 
            label: 'out',
            kind: monaco.languages.CompletionItemKind.Function,
            insertText: 'OpalSystemCall.("${1:Hello, World!}") -> out;',
            documentation: '標準出力（改行なし）'
          },
          { 
            label: 'outln',
            kind: monaco.languages.CompletionItemKind.Function,
            insertText: 'OpalSystemCall.("${1:Hello, World!}") => out;',
            documentation: '標準出力（改行あり）'
          },
          {
            label: 'module-template',
            kind: monaco.languages.CompletionItemKind.Snippet,
            insertText: 'module ${1:ModuleName} then\n\tfunction first() -> Void then\n\t\tOpalSystemCall.("Hello, World!") => out;\n\tend\nend',
            documentation: 'Opalモジュールの基本テンプレート'
          }
        ];
        
        return { suggestions: suggestions };
      }
    });
    
    // エディタの初期化
    editor = monaco.editor.create(document.getElementById('editor-container'), {
      value: '',
      language: 'opal',
      theme: config.theme === 'dark' ? 'vs-dark' : 'vs',
      fontSize: config.fontSize,
      tabSize: config.tabSize,
      wordWrap: config.wordWrap,
      minimap: { enabled: true },
      automaticLayout: true,
      scrollBeyondLastLine: false,
      renderWhitespace: 'boundary',
      renderControlCharacters: true,
      renderIndentGuides: true,
      rulers: [80],
      lineNumbers: 'on',
      glyphMargin: true,
      folding: true
    });
    
    // エディタのイベントリスナー
    editor.onDidChangeModelContent(() => {
      if (currentFile && config.autoSave) {
        saveCurrentFile();
      }
    });
    
    editor.onDidChangeCursorPosition(e => {
      document.getElementById('cursor-position').textContent = `行: ${e.position.lineNumber}, 列: ${e.position.column}`;
    });
    
    // ウェルカムスクリーンを表示
    showWelcomeScreen();
  });
}

// UIイベントリスナーの設定
function setupEventListeners() {
  // 新規プロジェクトボタン
  document.getElementById('new-project-btn').addEventListener('click', () => {
    showModal('new-project-modal');
  });
  
  // プロジェクト作成ボタン
  document.getElementById('create-project-btn').addEventListener('click', createNewProject);
  
  // プロジェクトを開くボタン
  document.getElementById('open-project-btn').addEventListener('click', () => {
    ipcRenderer.invoke('open-project');
  });
  
  // ファイルを開くボタン
  document.getElementById('open-file-btn').addEventListener('click', openFile);
  
  // 設定ボタン
  document.getElementById('settings-btn').addEventListener('click', () => {
    showModal('settings-modal');
  });
  
  // 設定保存ボタン
  document.getElementById('save-settings-btn').addEventListener('click', saveSettings);
  
  // パネルタブ切り替え
  document.querySelectorAll('.panel-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel-view').forEach(v => v.classList.remove('active'));
      
      tab.classList.add('active');
      const panelId = tab.getAttribute('data-panel');
      document.getElementById(`${panelId}-panel`).classList.add('active');
    });
  });
  
  // 設定タブ切り替え
  document.querySelectorAll('.settings-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
      
      tab.classList.add('active');
      const tabId = tab.getAttribute('data-tab');
      document.getElementById(`${tabId}-settings`).classList.add('active');
    });
  });
  
  // モーダルを閉じるボタン
  document.querySelectorAll('.modal-close, .modal-cancel').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
      });
    });
  });
  
  // パネルを閉じるボタン
  document.getElementById('close-panel-btn').addEventListener('click', () => {
    document.getElementById('panel').style.display = 'none';
  });
  
  // パネルをクリアするボタン
  document.getElementById('clear-panel-btn').addEventListener('click', () => {
    const activePanel = document.querySelector('.panel-view.active');
    if (activePanel) {
      const contentElement = activePanel.querySelector('pre, .problems-list, .debug-variables, .debug-callstack, .debug-breakpoints');
      if (contentElement) {
        contentElement.innerHTML = '';
      }
    }
  });
  
  // IPCイベントリスナー
  ipcRenderer.on('menu-new-project', () => {
    showModal('new-project-modal');
  });
  
  ipcRenderer.on('menu-save', () => {
    saveCurrentFile();
  });
  
  ipcRenderer.on('menu-save-as', () => {
    saveFileAs();
  });
  
  ipcRenderer.on('menu-settings', () => {
    showModal('settings-modal');
  });
  
  ipcRenderer.on('menu-find', () => {
    editor.getAction('actions.find').run();
  });
  
  ipcRenderer.on('menu-replace', () => {
    editor.getAction('actions.replace').run();
  });
  
  ipcRenderer.on('menu-build', () => {
    buildProject();
  });
  
  ipcRenderer.on('menu-run', () => {
    runProject();
  });
  
  ipcRenderer.on('menu-debug', () => {
    debugProject();
  });
  
  ipcRenderer.on('theme-changed', (event, theme) => {
    config.theme = theme;
    applyConfig();
  });
  
  ipcRenderer.on('load-project', (event, project) => {
    loadProject(project);
  });
}

// 最近のプロジェクトを読み込む
function loadRecentProjects() {
  const recentProjectsElement = document.getElementById('recent-projects');
  const recentProjects = config.recentProjects || [];
  
  if (recentProjects.length === 0) {
    recentProjectsElement.innerHTML = '<p class="no-recent">最近開いたプロジェクトはありません</p>';
    return;
  }
  
  recentProjectsElement.innerHTML = '';
  
  recentProjects.forEach(project => {
    const projectElement = document.createElement('div');
    projectElement.className = 'recent-project';
    projectElement.innerHTML = `
      <span class="project-name">${project.name}</span>
      <span class="project-path">${project.path}</span>
    `;
    
    projectElement.addEventListener('click', () => {
      loadProject(project);
    });
    
    recentProjectsElement.appendChild(projectElement);
  });
}

// プロジェクトを読み込む
function loadProject(project) {
  currentProject = project;
  
  // ウェルカムスクリーンを非表示
  hideWelcomeScreen();
  
  // プロジェクトエクスプローラーを更新
  updateFileTree(project.path);
  
  // 出力パネルを表示
  document.getElementById('panel').style.display = 'flex';
  
  // プロジェクト情報を出力
  appendToOutput(`プロジェクト "${project.name}" を開きました\n場所: ${project.path}\n`);
  
  // プロジェクト設定ファイルを読み込む
  const projectConfigPath = path.join(project.path, 'project.json');
  if (fs.existsSync(projectConfigPath)) {
    try {
      const projectConfig = JSON.parse(fs.readFileSync(projectConfigPath, 'utf8'));
      
      // エントリーポイントファイルを開く
      if (projectConfig.entryPoint) {
        const entryPointPath = path.join(project.path, projectConfig.entryPoint);
        if (fs.existsSync(entryPointPath)) {
          openFileFromPath(entryPointPath);
        }
      }
    } catch (error) {
      appendToOutput(`プロジェクト設定の読み込みに失敗しました: ${error.message}\n`);
    }
  }
}

// ファイルツリーを更新
function updateFileTree(rootPath) {
  const fileTreeElement = document.getElementById('file-tree');
  fileTreeElement.innerHTML = '';
  
  fileTree = createFileTreeNode(rootPath, path.basename(rootPath), true);
  fileTreeElement.appendChild(fileTree);
}

// ファイルツリーノードを作成
function createFileTreeNode(filePath, fileName, isRoot = false) {
  const stats = fs.statSync(filePath);
  const isDirectory = stats.isDirectory();
  
  const nodeElement = document.createElement('div');
  nodeElement.className = isDirectory ? 'directory' : 'file';
  if (isRoot) {
    nodeElement.classList.add('root');
  }
  
  const nodeContent = document.createElement('div');
  nodeContent.className = 'node-content';
  
  const nodeIcon = document.createElement('span');
  nodeIcon.className = isDirectory ? 'icon icon-folder' : 'icon icon-file';
  if (isDirectory && isRoot) {
    nodeIcon.className = 'icon icon-project';
  } else if (!isDirectory) {
    // ファイル拡張子に基づいてアイコンを設定
    const ext = path.extname(fileName).toLowerCase();
    if (ext === '.opal') {
      nodeIcon.className = 'icon icon-opal-file';
    } else if (ext === '.json') {
      nodeIcon.className = 'icon icon-json-file';
    } else if (ext === '.md') {
      nodeIcon.className = 'icon icon-markdown-file';
    }
  }
  
  const nodeLabel = document.createElement('span');
  nodeLabel.className = 'node-label';
  nodeLabel.textContent = fileName;
  
  nodeContent.appendChild(nodeIcon);
  nodeContent.appendChild(nodeLabel);
  nodeElement.appendChild(nodeContent);
  
  if (isDirectory) {
    nodeElement.classList.add('collapsed');
    
    const childrenContainer = document.createElement('div');
    childrenContainer.className = 'children';
    nodeElement.appendChild(childrenContainer);
    
    // ディレクトリの展開/折りたたみ
    nodeContent.addEventListener('click', () => {
      if (nodeElement.classList.contains('collapsed')) {
        nodeElement.classList.remove('collapsed');
        nodeElement.classList.add('expanded');
        
        // 子要素を読み込む
        if (childrenContainer.children.length === 0) {
          try {
            const children = fs.readdirSync(filePath);
            
            // ディレクトリを先に、次にファイルをアルファベット順に並べる
            const sortedChildren = children.sort((a, b) => {
              const aIsDir = fs.statSync(path.join(filePath, a)).isDirectory();
              const bIsDir = fs.statSync(path.join(filePath, b)).isDirectory();
              
              if (aIsDir && !bIsDir) return -1;
              if (!aIsDir && bIsDir) return 1;
              return a.localeCompare(b);
            });
            
            sortedChildren.forEach(child => {
              try {
                const childPath = path.join(filePath, child);
                const childNode = createFileTreeNode(childPath, child);
                childrenContainer.appendChild(childNode);
              } catch (error) {
                console.error(`ファイルツリーノードの作成に失敗しました: ${child}`, error);
              }
            });
          } catch (error) {
            console.error(`ディレクトリの読み込みに失敗しました: ${filePath}`, error);
          }
        }
      } else {
        nodeElement.classList.remove('expanded');
        nodeElement.classList.add('collapsed');
      }
    });
  } else {
    // ファイルをクリックしたときの処理
    nodeContent.addEventListener('click', () => {
      openFileFromPath(filePath);
    });
  }
  
  return nodeElement;
}

// ファイルを開く
async function openFile() {
  try {
    const result = await ipcRenderer.invoke('open-file');
    if (result) {
      openFileContent(result.path, result.content);
    }
  } catch (error) {
    appendToOutput(`ファイルを開く際にエラーが発生しました: ${error.message}\n`);
  }
}

// パスからファイルを開く
function openFileFromPath(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    openFileContent(filePath, content);
  } catch (error) {
    appendToOutput(`ファイルを開く際にエラーが発生しました: ${error.message}\n`);
  }
}

// ファイルの内容を開く
function openFileContent(filePath, content) {
  // ウェルカムスクリーンを非表示
  hideWelcomeScreen();
  
  // 既に開いているファイルかチェック
  const existingFileIndex = openFiles.findIndex(file => file.path === filePath);
  
  if (existingFileIndex !== -1) {
    // 既に開いているファイルを選択
    selectFile(existingFileIndex);
    return;
  }
  
  // 新しいファイルをオープンファイルリストに追加
  const fileName = path.basename(filePath);
  const fileExt = path.extname(fileName).toLowerCase();
  
  const fileData = {
    path: filePath,
    name: fileName,
    language: fileExt === '.opal' ? 'opal' : 'plaintext',
    model: monaco.editor.createModel(content, fileExt === '.opal' ? 'opal' : 'plaintext')
  };
  
  openFiles.push(fileData);
  
  // タブを作成
  createTab(openFiles.length - 1, fileName);
  
  // 新しいファイルを選択
  selectFile(openFiles.length - 1);
}

// タブを作成
function createTab(index, fileName) {
  const tabBar = document.getElementById('tab-bar');
  
  const tab = document.createElement('div');
  tab.className = 'tab';
  tab.setAttribute('data-index', index);
  
  const tabLabel = document.createElement('span');
  tabLabel.className = 'tab-label';
  tabLabel.textContent = fileName;
  
  const closeButton = document.createElement('button');
  closeButton.className = 'tab-close';
  closeButton.innerHTML = '&times;';
  closeButton.addEventListener('click', (e) => {
    e.stopPropagation();
    closeFile(index);
  });
  
  tab.appendChild(tabLabel);
  tab.appendChild(closeButton);
  
  tab.addEventListener('click', () => {
    selectFile(index);
  });
  
  tabBar.appendChild(tab);
}

// ファイルを選択
function selectFile(index) {
  // タブの選択状態を更新
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });
  
  const tab = document.querySelector(`.tab[data-index="${index}"]`);
  if (tab) {
    tab.classList.add('active');
  }
  
  // 現在のファイルを更新
  currentFile = openFiles[index];
  
  // エディタのモデルを設定
  editor.setModel(currentFile.model);
  
  // 言語モードを更新
  document.getElementById('language-mode').textContent = currentFile.language === 'opal' ? 'Opal' : 'Text';
}

// ファイルを閉じる
function closeFile(index) {
  // モデルを破棄
  openFiles[index].model.dispose();
  
  // タブを削除
  const tab = document.querySelector(`.tab[data-index="${index}"]`);
  if (tab) {
    tab.remove();
  }
  
  // ファイルリストから削除
  openFiles.splice(index, 1);
  
  // タブのインデックスを更新
  document.querySelectorAll('.tab').forEach((tab, i) => {
    tab.setAttribute('data-index', i);
  });
  
  // 他のファイルがあれば選択、なければウェルカムスクリーンを表示
  if (openFiles.length > 0) {
    selectFile(Math.min(index, openFiles.length - 1));
  } else {
    currentFile = null;
    editor.setModel(null);
    showWelcomeScreen();
  }
}

// 現在のファイルを保存
async function saveCurrentFile() {
  if (!currentFile) return;
  
  try {
    const content = editor.getValue();
    await ipcRenderer.invoke('save-file', { path: currentFile.path, content });
    appendToOutput(`ファイルを保存しました: ${currentFile.path}\n`);
  } catch (error) {
    appendToOutput(`ファイルの保存に失敗しました: ${error.message}\n`);
  }
}

// 名前を付けて保存
async function saveFileAs() {
  if (!editor) return;
  
  try {
    const content = editor.getValue();
    const newPath = await ipcRenderer.invoke('save-file', { path: null, content });
    
    if (newPath) {
      if (currentFile) {
        // 既存ファイルの場合は更新
        currentFile.path = newPath;
        currentFile.name = path.basename(newPath);
        
        // タブラベルを更新
        const tab = document.querySelector(`.tab[data-index="${openFiles.indexOf(currentFile)}"]`);
        if (tab) {
          tab.querySelector('.tab-label').textContent = currentFile.name;
        }
      } else {
        // 新規ファイルの場合は開く
        openFileContent(newPath, content);
      }
      
      appendToOutput(`ファイルを保存しました: ${newPath}\n`);
    }
  } catch (error) {
    appendToOutput(`ファイルの保存に失敗しました: ${error.message}\n`);
  }
}

// 新規プロジェクトを作成
async function createNewProject() {
  const projectName = document.getElementById('project-name').value.trim();
  const projectType = document.getElementById('project-type').value;
  
  if (!projectName) {
    alert('プロジェクト名を入力してください');
    return;
  }
  
  try {
    const result = await ipcRenderer.invoke('create-project', { type: projectType, name: projectName });
    
    if (result) {
      // モーダルを閉じる
      document.getElementById('new-project-modal').style.display = 'none';
      
      // フォームをリセット
      document.getElementById('new-project-form').reset();
      
      appendToOutput(`新規プロジェクト "${projectName}" を作成しました\n場所: ${result.path}\n`);
    }
  } catch (error) {
    appendToOutput(`プロジェクトの作成に失敗しました: ${error.message}\n`);
  }
}

// プロジェクトをビルド
function buildProject() {
  if (!currentProject) {
    appendToOutput('ビルドするプロジェクトが開かれていません\n');
    return;
  }
  
  // 現在のファイルを保存
  if (currentFile) {
    saveCurrentFile();
  }
  
  appendToOutput(`プロジェクト "${currentProject.name}" をビルドしています...\n`);
  
  // プロジェクト設定を読み込む
  const projectConfigPath = path.join(currentProject.path, 'project.json');
  if (!fs.existsSync(projectConfigPath)) {
    appendToOutput('プロジェクト設定ファイルが見つかりません\n');
    return;
  }
  
  try {
    const projectConfig = JSON.parse(fs.readFileSync(projectConfigPath, 'utf8'));
    
    // エントリーポイントファイルをビルド
    if (projectConfig.entryPoint) {
      const entryPointPath = path.join(currentProject.path, projectConfig.entryPoint);
      if (!fs.existsSync(entryPointPath)) {
        appendToOutput(`エントリーポイントファイルが見つかりません: ${projectConfig.entryPoint}\n`);
        return;
      }
      
      // ビルドコマンドを実行
      const buildArgs = config.opalArgs ? [entryPointPath, ...config.opalArgs.split(' ')] : [entryPointPath];
      
      ipcRenderer.invoke('run-opal-file', entryPointPath)
        .then(result => {
          if (result.success) {
            appendToOutput('ビルドが成功しました\n');
            appendToOutput(result.output);
          } else {
            appendToOutput('ビルドに失敗しました\n');
            appendToOutput(result.error);
          }
        })
        .catch(error => {
          appendToOutput(`ビルド中にエラーが発生しました: ${error.message}\n`);
        });
    } else {
      appendToOutput('エントリーポイントが設定されていません\n');
    }
  } catch (error) {
    appendToOutput(`プロジェクト設定の読み込みに失敗しました: ${error.message}\n`);
  }
}

// プロジェクトを実行
function runProject() {
  if (!currentProject) {
    appendToOutput('実行するプロジェクトが開かれていません\n');
    return;
  }
  
  // 現在のファイルを保存
  if (currentFile) {
    saveCurrentFile();
  }
  
  appendToOutput(`プロジェクト "${currentProject.name}" を実行しています...\n`);
  
  // プロジェクト設定を読み込む
  const projectConfigPath = path.join(currentProject.path, 'project.json');
  if (!fs.existsSync(projectConfigPath)) {
    appendToOutput('プロジェクト設定ファイルが見つかりません\n');
    return;
  }
  
  try {
    const projectConfig = JSON.parse(fs.readFileSync(projectConfigPath, 'utf8'));
    
    // エントリーポイントファイルを実行
    if (projectConfig.entryPoint) {
      const entryPointPath = path.join(currentProject.path, projectConfig.entryPoint);
      if (!fs.existsSync(entryPointPath)) {
        appendToOutput(`エントリーポイントファイルが見つかりません: ${projectConfig.entryPoint}\n`);
        return;
      }
      
      // 実行コマンドを実行
      ipcRenderer.invoke('run-opal-file', entryPointPath)
        .then(result => {
          if (result.success) {
            appendToOutput('実行結果:\n');
            appendToOutput(result.output);
          } else {
            appendToOutput('実行に失敗しました\n');
            appendToOutput(result.error);
          }
        })
        .catch(error => {
          appendToOutput(`実行中にエラーが発生しました: ${error.message}\n`);
        });
    } else {
      appendToOutput('エントリーポイントが設定されていません\n');
    }
  } catch (error) {
    appendToOutput(`プロジェクト設定の読み込みに失敗しました: ${error.message}\n`);
  }
}

// プロジェクトをデバッグ
function debugProject() {
  if (!currentProject) {
    appendToOutput('デバッグするプロジェクトが開かれていません\n');
    return;
  }
  
  // 現在のファイルを保存
  if (currentFile) {
    saveCurrentFile();
  }
  
  appendToOutput(`プロジェクト "${currentProject.name}" をデバッグしています...\n`);
  appendToOutput('デバッグ機能は現在開発中です\n');
  
  // デバッグパネルを表示
  document.querySelectorAll('.panel-tab').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.panel-view').forEach(view => view.classList.remove('active'));
  
  document.querySelector('.panel-tab[data-panel="debug"]').classList.add('active');
  document.getElementById('debug-panel').classList.add('active');
}

// 設定を保存
function saveSettings() {
  // フォームから設定を取得
  config.theme = document.getElementById('theme').value;
  config.fontSize = parseInt(document.getElementById('font-size').value, 10);
  config.tabSize = parseInt(document.getElementById('tab-size').value, 10);
  config.wordWrap = document.getElementById('word-wrap').value;
  config.autoSave = document.getElementById('auto-save').checked;
  config.opalPath = document.getElementById('opal-path').value;
  config.opalArgs = document.getElementById('opal-args').value;
  
  // 設定を保存
  ipcRenderer.send('save-config', config);
  
  // UIに設定を適用
  applyConfig();
  
  // モーダルを閉じる
  document.getElementById('settings-modal').style.display = 'none';
  
  appendToOutput('設定を保存しました\n');
}

// 出力パネルにテキストを追加
function appendToOutput(text) {
  const outputContent = document.getElementById('output-content');
  outputContent.textContent += text;
  outputContent.scrollTop = outputContent.scrollHeight;
  
  // パネルが非表示なら表示
  document.getElementById('panel').style.display = 'flex';
  
  // 出力タブをアクティブに
  document.querySelectorAll('.panel-tab').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.panel-view').forEach(view => view.classList.remove('active'));
  
  document.querySelector('.panel-tab[data-panel="output"]').classList.add('active');
  document.getElementById('output-panel').classList.add('active');
}

// モーダルを表示
function showModal(modalId) {
  document.getElementById(modalId).style.display = 'flex';
}

// ウェルカムスクリーンを表示
function showWelcomeScreen() {
  document.getElementById('welcome-screen').style.display = 'flex';
}

// ウェルカムスクリーンを非表示
function hideWelcomeScreen() {
  document.getElementById('welcome-screen').style.display = 'none';
}
