# OpalData ライブラリドキュメント

## 概要

OpalDataは、Python風のデータ処理と分析機能を提供するOpal言語用ライブラリです。このライブラリは、データフレーム操作、データ可視化、機械学習アルゴリズム、データI/O、前処理、時系列分析など、データサイエンスに必要な機能を提供します。

## モジュール構成

OpalDataライブラリは以下のサブモジュールで構成されています：

1. **DataFrame** - Pandas風のデータフレーム操作
2. **Visualization** - Matplotlib風のデータ可視化
3. **MachineLearning** - scikit-learn風の機械学習アルゴリズム
4. **IO** - データ入出力
5. **Preprocessing** - データ前処理
6. **TimeSeries** - 時系列データ分析

## インストール方法

OpalDataライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalData`ディレクトリとそのサブディレクトリをプロジェクトにコピーします
2. Opalプログラムの先頭で`OpalData`モジュールをインポートします

```opal
// OpalDataモジュールをインポート
import OpalData;

module MyApp then
    function first() -> Void then
        // OpalDataを初期化
        OpalData.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalData!") -> out;
    end
end
```

## API リファレンス

### コアモジュール

#### `OpalData.initialize() -> Boolean`

OpalDataライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalData.initialize();
```

#### `OpalData.VERSION -> String`

OpalDataライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.0.0"）

**使用例**:
```opal
OpalSystemCall.("OpalData version: " + OpalData.VERSION) -> out;
```

### DataFrame モジュール

#### `OpalData.DataFrame.createDataFrame(data: Map) -> DataFrame`

データからデータフレームを作成します。

**パラメータ**:
- `data`: 列名をキー、値の配列を値とするマップ

**戻り値**: 新しいデータフレーム

**使用例**:
```opal
nc data <- {
    "名前": ["田中", "佐藤", "鈴木", "高橋"],
    "年齢": [25, 30, 45, 22],
    "給与": [300000, 350000, 450000, 280000]
};

nc df <- OpalData.DataFrame.createDataFrame(data);
```

#### `OpalData.DataFrame.readCSV(filePath: String, options: Map = {}) -> DataFrame`

CSVファイルからデータフレームを作成します。

**パラメータ**:
- `filePath`: CSVファイルのパス
- `options`: 読み込みオプション（区切り文字、ヘッダーの有無など）

**戻り値**: 新しいデータフレーム

**使用例**:
```opal
nc df <- OpalData.DataFrame.readCSV("/path/to/data.csv", {
    "delimiter": ",",
    "header": true
});
```

#### `DataFrame.head(n: Integer = 5) -> DataFrame`

データフレームの先頭n行を取得します。

**パラメータ**:
- `n`: 取得する行数（デフォルト: 5）

**戻り値**: 先頭n行を含む新しいデータフレーム

**使用例**:
```opal
nc topRows <- df.head();
OpalSystemCall.(topRows.toString()) -> out;
```

#### `DataFrame.tail(n: Integer = 5) -> DataFrame`

データフレームの末尾n行を取得します。

**パラメータ**:
- `n`: 取得する行数（デフォルト: 5）

**戻り値**: 末尾n行を含む新しいデータフレーム

**使用例**:
```opal
nc bottomRows <- df.tail();
OpalSystemCall.(bottomRows.toString()) -> out;
```

#### `DataFrame.columns() -> Array`

データフレームの列名を取得します。

**戻り値**: 列名の配列

**使用例**:
```opal
nc columns <- df.columns();
OpalSystemCall.("列名: " + columns) -> out;
```

#### `DataFrame.rowCount() -> Integer`

データフレームの行数を取得します。

**戻り値**: 行数

**使用例**:
```opal
nc numRows <- df.rowCount();
OpalSystemCall.("行数: " + numRows) -> out;
```

#### `DataFrame.columnType(column: String) -> String`

指定された列のデータ型を取得します。

**パラメータ**:
- `column`: 列名

**戻り値**: データ型（"string"、"number"、"boolean"など）

**使用例**:
```opal
nc type <- df.columnType("年齢");
OpalSystemCall.("年齢列の型: " + type) -> out;
```

#### `DataFrame.get(row: Integer, column: String) -> Any`

指定された位置の値を取得します。

**パラメータ**:
- `row`: 行インデックス
- `column`: 列名

**戻り値**: セルの値

**使用例**:
```opal
nc value <- df.get(0, "名前");
OpalSystemCall.("最初の行の名前: " + value) -> out;
```

#### `DataFrame.set(row: Integer, column: String, value: Any) -> Void`

指定された位置に値を設定します。

**パラメータ**:
- `row`: 行インデックス
- `column`: 列名
- `value`: 設定する値

**使用例**:
```opal
df.set(0, "年齢", 26);
```

#### `DataFrame.select(columns: Array) -> DataFrame`

指定された列のみを含む新しいデータフレームを作成します。

**パラメータ**:
- `columns`: 選択する列名の配列

**戻り値**: 選択された列を含む新しいデータフレーム

**使用例**:
```opal
nc selectedDF <- df.select(["名前", "年齢"]);
```

#### `DataFrame.filter(condition: Function) -> DataFrame`

条件に一致する行のみを含む新しいデータフレームを作成します。

**パラメータ**:
- `condition`: 各行を評価する関数 `function(row: Map) -> Boolean`

**戻り値**: フィルタリングされた新しいデータフレーム

**使用例**:
```opal
nc filteredDF <- df.filter(function(row: Map) -> Boolean then
    return row.年齢 > 30;
end);
```

#### `DataFrame.sort(column: String, ascending: Boolean = true) -> DataFrame`

指定された列でデータフレームをソートします。

**パラメータ**:
- `column`: ソートする列名
- `ascending`: 昇順の場合は`true`、降順の場合は`false`（デフォルト: `true`）

**戻り値**: ソートされた新しいデータフレーム

**使用例**:
```opal
nc sortedDF <- df.sort("年齢", false);
```

#### `DataFrame.groupBy(column: String) -> Map`

指定された列でデータフレームをグループ化します。

**パラメータ**:
- `column`: グループ化する列名

**戻り値**: グループ値をキー、データフレームを値とするマップ

**使用例**:
```opal
nc grouped <- df.groupBy("部署");
```

#### `DataFrame.join(other: DataFrame, on: String, how: String = "inner") -> DataFrame`

他のデータフレームと結合します。

**パラメータ**:
- `other`: 結合する他のデータフレーム
- `on`: 結合キーとなる列名
- `how`: 結合タイプ（"inner"、"left"、"right"、"outer"）（デフォルト: "inner"）

**戻り値**: 結合された新しいデータフレーム

**使用例**:
```opal
nc joinedDF <- df1.join(df2, "ID", "left");
```

#### `DataFrame.describe() -> Map`

データフレームの統計情報を計算します。

**戻り値**: 各列の統計情報（平均、標準偏差、最小値、最大値など）を含むマップ

**使用例**:
```opal
nc stats <- df.describe();
OpalSystemCall.(stats.toString()) -> out;
```

#### `DataFrame.toCSV(filePath: String, options: Map = {}) -> Boolean`

データフレームをCSVファイルに保存します。

**パラメータ**:
- `filePath`: 保存先のファイルパス
- `options`: 保存オプション（区切り文字、ヘッダーの有無など）

**戻り値**: 保存が成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- df.toCSV("/path/to/output.csv", {
    "delimiter": ",",
    "header": true
});
```

#### `DataFrame.toString() -> String`

データフレームを文字列形式で表示します。

**戻り値**: データフレームの文字列表現

**使用例**:
```opal
OpalSystemCall.(df.toString()) -> out;
```

### Visualization モジュール

#### `OpalData.Visualization.linePlot(data: Map, options: Map = {}) -> Map`

線グラフを作成します。

**パラメータ**:
- `data`: プロットするデータ
- `options`: グラフオプション（タイトル、軸ラベル、色など）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- {
    "x": [1, 2, 3, 4, 5],
    "y": [2, 4, 1, 5, 3]
};

nc plot <- OpalData.Visualization.linePlot(data, {
    "title": "サンプル線グラフ",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "color": "blue"
});
```

#### `OpalData.Visualization.barPlot(data: Map, options: Map = {}) -> Map`

棒グラフを作成します。

**パラメータ**:
- `data`: プロットするデータ
- `options`: グラフオプション（タイトル、軸ラベル、色など）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- {
    "categories": ["A", "B", "C", "D", "E"],
    "values": [10, 25, 15, 30, 20]
};

nc plot <- OpalData.Visualization.barPlot(data, {
    "title": "サンプル棒グラフ",
    "xLabel": "カテゴリ",
    "yLabel": "値",
    "color": "green"
});
```

#### `OpalData.Visualization.scatterPlot(data: Map, options: Map = {}) -> Map`

散布図を作成します。

**パラメータ**:
- `data`: プロットするデータ
- `options`: グラフオプション（タイトル、軸ラベル、色など）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- {
    "x": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    "y": [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
};

nc plot <- OpalData.Visualization.scatterPlot(data, {
    "title": "サンプル散布図",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "color": "red"
});
```

#### `OpalData.Visualization.histogram(data: Array, options: Map = {}) -> Map`

ヒストグラムを作成します。

**パラメータ**:
- `data`: プロットするデータの配列
- `options`: グラフオプション（タイトル、軸ラベル、ビン数など）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 5];

nc plot <- OpalData.Visualization.histogram(data, {
    "title": "サンプルヒストグラム",
    "xLabel": "値",
    "yLabel": "頻度",
    "bins": 5,
    "color": "purple"
});
```

#### `OpalData.Visualization.pieChart(data: Map, options: Map = {}) -> Map`

円グラフを作成します。

**パラメータ**:
- `data`: プロットするデータ
- `options`: グラフオプション（タイトル、ラベルなど）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- {
    "labels": ["A", "B", "C", "D"],
    "values": [30, 20, 25, 25]
};

nc plot <- OpalData.Visualization.pieChart(data, {
    "title": "サンプル円グラフ"
});
```

#### `OpalData.Visualization.heatmap(data: Array, options: Map = {}) -> Map`

ヒートマップを作成します。

**パラメータ**:
- `data`: プロットする2次元配列データ
- `options`: グラフオプション（タイトル、軸ラベル、色スケールなど）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- [
    [1, 2, 3, 4],
    [2, 4, 6, 8],
    [3, 6, 9, 12],
    [4, 8, 12, 16]
];

nc plot <- OpalData.Visualization.heatmap(data, {
    "title": "サンプルヒートマップ",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "colorScale": "viridis"
});
```

#### `OpalData.Visualization.boxPlot(data: Array, options: Map = {}) -> Map`

箱ひげ図を作成します。

**パラメータ**:
- `data`: プロットするデータの配列
- `options`: グラフオプション（タイトル、軸ラベルなど）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc data <- [
    [1, 2, 3, 4, 5, 6, 7, 8],
    [2, 3, 5, 7, 11, 13, 17, 19],
    [10, 15, 12, 18, 20, 22, 25, 30]
];

nc plot <- OpalData.Visualization.boxPlot(data, {
    "title": "サンプル箱ひげ図",
    "xLabel": "グループ",
    "yLabel": "値",
    "labels": ["A", "B", "C"]
});
```

#### `OpalData.Visualization.save(plot: Map, filePath: String, options: Map = {}) -> Boolean`

可視化オブジェクトを画像ファイルとして保存します。

**パラメータ**:
- `plot`: 保存する可視化オブジェクト
- `filePath`: 保存先のファイルパス
- `options`: 保存オプション（解像度、サイズなど）

**戻り値**: 保存が成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalData.Visualization.save(plot, "/path/to/plot.png", {
    "dpi": 300,
    "width": 800,
    "height": 600
});
```

### MachineLearning モジュール

#### `OpalData.MachineLearning.LinearRegression(options: Map = {}) -> Map`

線形回帰モデルを作成します。

**パラメータ**:
- `options`: モデルオプション（正則化パラメータなど）

**戻り値**: 線形回帰モデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.MachineLearning.LinearRegression({
    "fitIntercept": true,
    "normalize": false
});

// モデルの学習
model.fit(X_train, y_train);

// 予測
nc predictions <- model.predict(X_test);
```

#### `OpalData.MachineLearning.LogisticRegression(options: Map = {}) -> Map`

ロジスティック回帰モデルを作成します。

**パラメータ**:
- `options`: モデルオプション（正則化パラメータ、最大反復回数など）

**戻り値**: ロジスティック回帰モデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.MachineLearning.LogisticRegression({
    "penalty": "l2",
    "C": 1.0,
    "maxIter": 100
});

// モデルの学習
model.fit(X_train, y_train);

// 予測
nc predictions <- model.predict(X_test);
```

#### `OpalData.MachineLearning.DecisionTree(options: Map = {}) -> Map`

決定木モデルを作成します。

**パラメータ**:
- `options`: モデルオプション（最大深さ、最小サンプル数など）

**戻り値**: 決定木モデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.MachineLearning.DecisionTree({
    "maxDepth": 5,
    "minSamplesSplit": 2,
    "criterion": "gini"
});

// モデルの学習
model.fit(X_train, y_train);

// 予測
nc predictions <- model.predict(X_test);
```

#### `OpalData.MachineLearning.RandomForest(options: Map = {}) -> Map`

ランダムフォレストモデルを作成します。

**パラメータ**:
- `options`: モデルオプション（木の数、最大深さなど）

**戻り値**: ランダムフォレストモデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.MachineLearning.RandomForest({
    "nEstimators": 100,
    "maxDepth": 10,
    "criterion": "gini"
});

// モデルの学習
model.fit(X_train, y_train);

// 予測
nc predictions <- model.predict(X_test);
```

#### `OpalData.MachineLearning.KMeans(options: Map = {}) -> Map`

K-meansクラスタリングモデルを作成します。

**パラメータ**:
- `options`: モデルオプション（クラスタ数、最大反復回数など）

**戻り値**: K-meansモデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.MachineLearning.KMeans({
    "nClusters": 3,
    "maxIter": 300,
    "nInit": 10
});

// モデルの学習
model.fit(X);

// クラスタの予測
nc clusters <- model.predict(X);
```

#### `OpalData.MachineLearning.trainTestSplit(X: Array, y: Array, testSize: Float = 0.2, randomState: Integer = null) -> Map`

データを訓練セットとテストセットに分割します。

**パラメータ**:
- `X`: 特徴量データ
- `y`: ターゲットデータ
- `testSize`: テストセットの割合（デフォルト: 0.2）
- `randomState`: 乱数シード（デフォルト: null）

**戻り値**: 分割されたデータセットを含むマップ

**使用例**:
```opal
nc split <- OpalData.MachineLearning.trainTestSplit(X, y, 0.3, 42);
nc X_train <- split.X_train;
nc X_test <- split.X_test;
nc y_train <- split.y_train;
nc y_test <- split.y_test;
```

#### `OpalData.MachineLearning.crossValidation(model: Map, X: Array, y: Array, nFolds: Integer = 5) -> Map`

交差検証を実行します。

**パラメータ**:
- `model`: 評価するモデル
- `X`: 特徴量データ
- `y`: ターゲットデータ
- `nFolds`: 分割数（デフォルト: 5）

**戻り値**: 評価スコアを含むマップ

**使用例**:
```opal
nc model <- OpalData.MachineLearning.LinearRegression();
nc scores <- OpalData.MachineLearning.crossValidation(model, X, y, 10);
OpalSystemCall.("交差検証スコア: " + scores.mean) -> out;
```

#### `OpalData.MachineLearning.evaluateRegression(yTrue: Array, yPred: Array) -> Map`

回帰モデルの評価指標を計算します。

**パラメータ**:
- `yTrue`: 真のターゲット値
- `yPred`: 予測値

**戻り値**: 評価指標（MSE、RMSE、MAE、R²）を含むマップ

**使用例**:
```opal
nc metrics <- OpalData.MachineLearning.evaluateRegression(y_test, predictions);
OpalSystemCall.("MSE: " + metrics.mse) -> out;
OpalSystemCall.("R²: " + metrics.r2) -> out;
```

#### `OpalData.MachineLearning.evaluateClassification(yTrue: Array, yPred: Array) -> Map`

分類モデルの評価指標を計算します。

**パラメータ**:
- `yTrue`: 真のクラスラベル
- `yPred`: 予測クラスラベル

**戻り値**: 評価指標（精度、適合率、再現率、F1スコア）を含むマップ

**使用例**:
```opal
nc metrics <- OpalData.MachineLearning.evaluateClassification(y_test, predictions);
OpalSystemCall.("精度: " + metrics.accuracy) -> out;
OpalSystemCall.("F1スコア: " + metrics.f1) -> out;
```

### IO モジュール

#### `OpalData.IO.readCSV(filePath: String, options: Map = {}) -> DataFrame`

CSVファイルを読み込みます。

**パラメータ**:
- `filePath`: CSVファイルのパス
- `options`: 読み込みオプション（区切り文字、ヘッダーの有無など）

**戻り値**: データフレーム

**使用例**:
```opal
nc df <- OpalData.IO.readCSV("/path/to/data.csv", {
    "delimiter": ",",
    "header": true,
    "skipRows": 0
});
```

#### `OpalData.IO.writeCSV(df: DataFrame, filePath: String, options: Map = {}) -> Boolean`

データフレームをCSVファイルに書き込みます。

**パラメータ**:
- `df`: 書き込むデータフレーム
- `filePath`: 保存先のファイルパス
- `options`: 書き込みオプション（区切り文字、ヘッダーの有無など）

**戻り値**: 書き込みが成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalData.IO.writeCSV(df, "/path/to/output.csv", {
    "delimiter": ",",
    "header": true,
    "index": false
});
```

#### `OpalData.IO.readJSON(filePath: String) -> Any`

JSONファイルを読み込みます。

**パラメータ**:
- `filePath`: JSONファイルのパス

**戻り値**: JSONデータ（オブジェクトまたは配列）

**使用例**:
```opal
nc data <- OpalData.IO.readJSON("/path/to/data.json");
```

#### `OpalData.IO.writeJSON(data: Any, filePath: String, options: Map = {}) -> Boolean`

データをJSONファイルに書き込みます。

**パラメータ**:
- `data`: 書き込むデータ
- `filePath`: 保存先のファイルパス
- `options`: 書き込みオプション（インデントなど）

**戻り値**: 書き込みが成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalData.IO.writeJSON(data, "/path/to/output.json", {
    "indent": 2
});
```

#### `OpalData.IO.readExcel(filePath: String, options: Map = {}) -> DataFrame`

Excelファイルを読み込みます。

**パラメータ**:
- `filePath`: Excelファイルのパス
- `options`: 読み込みオプション（シート名、ヘッダーの有無など）

**戻り値**: データフレーム

**使用例**:
```opal
nc df <- OpalData.IO.readExcel("/path/to/data.xlsx", {
    "sheet": "Sheet1",
    "header": true
});
```

#### `OpalData.IO.writeExcel(df: DataFrame, filePath: String, options: Map = {}) -> Boolean`

データフレームをExcelファイルに書き込みます。

**パラメータ**:
- `df`: 書き込むデータフレーム
- `filePath`: 保存先のファイルパス
- `options`: 書き込みオプション（シート名など）

**戻り値**: 書き込みが成功した場合は`true`、そうでない場合は`false`

**使用例**:
```opal
nc success <- OpalData.IO.writeExcel(df, "/path/to/output.xlsx", {
    "sheet": "Data",
    "index": false
});
```

#### `OpalData.IO.connectDatabase(config: Map) -> Map`

データベースに接続します。

**パラメータ**:
- `config`: 接続設定（ホスト、ポート、ユーザー名、パスワードなど）

**戻り値**: データベース接続オブジェクト

**使用例**:
```opal
nc connection <- OpalData.IO.connectDatabase({
    "type": "mysql",
    "host": "localhost",
    "port": 3306,
    "database": "mydb",
    "user": "username",
    "password": "password"
});
```

#### `OpalData.IO.queryDatabase(connection: Map, query: String) -> DataFrame`

SQLクエリを実行し、結果をデータフレームとして取得します。

**パラメータ**:
- `connection`: データベース接続オブジェクト
- `query`: SQLクエリ

**戻り値**: クエリ結果のデータフレーム

**使用例**:
```opal
nc df <- OpalData.IO.queryDatabase(connection, "SELECT * FROM users WHERE age > 30");
```

### Preprocessing モジュール

#### `OpalData.Preprocessing.standardScaler(data: Array) -> Map`

データを標準化します（平均0、標準偏差1）。

**パラメータ**:
- `data`: 標準化するデータ

**戻り値**: 標準化されたデータと変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.standardScaler(X);
nc X_scaled <- result.data;
nc scaler <- result.transformer;

// 新しいデータを変換
nc X_new_scaled <- scaler.transform(X_new);
```

#### `OpalData.Preprocessing.minMaxScaler(data: Array, range: Array = [0, 1]) -> Map`

データを指定された範囲に正規化します。

**パラメータ**:
- `data`: 正規化するデータ
- `range`: 正規化する範囲（デフォルト: [0, 1]）

**戻り値**: 正規化されたデータと変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.minMaxScaler(X, [0, 1]);
nc X_scaled <- result.data;
nc scaler <- result.transformer;

// 新しいデータを変換
nc X_new_scaled <- scaler.transform(X_new);
```

#### `OpalData.Preprocessing.oneHotEncoder(data: Array) -> Map`

カテゴリデータをワンホットエンコーディングします。

**パラメータ**:
- `data`: エンコードするカテゴリデータ

**戻り値**: エンコードされたデータと変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.oneHotEncoder(X_categorical);
nc X_encoded <- result.data;
nc encoder <- result.transformer;

// 新しいデータを変換
nc X_new_encoded <- encoder.transform(X_new_categorical);
```

#### `OpalData.Preprocessing.labelEncoder(data: Array) -> Map`

カテゴリラベルを数値にエンコードします。

**パラメータ**:
- `data`: エンコードするラベルデータ

**戻り値**: エンコードされたデータと変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.labelEncoder(y);
nc y_encoded <- result.data;
nc encoder <- result.transformer;

// 新しいデータを変換
nc y_new_encoded <- encoder.transform(y_new);
```

#### `OpalData.Preprocessing.imputeMissing(data: Array, strategy: String = "mean") -> Map`

欠損値を補完します。

**パラメータ**:
- `data`: 欠損値を含むデータ
- `strategy`: 補完戦略（"mean"、"median"、"mode"、"constant"）（デフォルト: "mean"）

**戻り値**: 補完されたデータと変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.imputeMissing(X, "median");
nc X_imputed <- result.data;
nc imputer <- result.transformer;

// 新しいデータを変換
nc X_new_imputed <- imputer.transform(X_new);
```

#### `OpalData.Preprocessing.polynomialFeatures(data: Array, degree: Integer = 2) -> Map`

多項式特徴量を生成します。

**パラメータ**:
- `data`: 元の特徴量データ
- `degree`: 多項式の次数（デフォルト: 2）

**戻り値**: 多項式特徴量と変換オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.polynomialFeatures(X, 3);
nc X_poly <- result.data;
nc transformer <- result.transformer;

// 新しいデータを変換
nc X_new_poly <- transformer.transform(X_new);
```

#### `OpalData.Preprocessing.featureSelection(X: Array, y: Array, nFeatures: Integer) -> Map`

特徴量選択を行います。

**パラメータ**:
- `X`: 特徴量データ
- `y`: ターゲットデータ
- `nFeatures`: 選択する特徴量の数

**戻り値**: 選択された特徴量と選択オブジェクトを含むマップ

**使用例**:
```opal
nc result <- OpalData.Preprocessing.featureSelection(X, y, 5);
nc X_selected <- result.data;
nc selector <- result.transformer;

// 新しいデータを変換
nc X_new_selected <- selector.transform(X_new);
```

### TimeSeries モジュール

#### `OpalData.TimeSeries.createTimeSeries(data: Array, dates: Array) -> Map`

時系列データを作成します。

**パラメータ**:
- `data`: 時系列値
- `dates`: 日付または時間の配列

**戻り値**: 時系列オブジェクト

**使用例**:
```opal
nc dates <- [
    "2023-01-01", "2023-01-02", "2023-01-03", "2023-01-04", "2023-01-05"
];
nc values <- [10, 12, 15, 14, 16];

nc ts <- OpalData.TimeSeries.createTimeSeries(values, dates);
```

#### `OpalData.TimeSeries.movingAverage(timeSeries: Map, window: Integer) -> Map`

移動平均を計算します。

**パラメータ**:
- `timeSeries`: 時系列オブジェクト
- `window`: ウィンドウサイズ

**戻り値**: 移動平均の時系列オブジェクト

**使用例**:
```opal
nc ma <- OpalData.TimeSeries.movingAverage(ts, 3);
```

#### `OpalData.TimeSeries.exponentialSmoothing(timeSeries: Map, alpha: Float) -> Map`

指数平滑化を適用します。

**パラメータ**:
- `timeSeries`: 時系列オブジェクト
- `alpha`: 平滑化パラメータ（0〜1）

**戻り値**: 平滑化された時系列オブジェクト

**使用例**:
```opal
nc smoothed <- OpalData.TimeSeries.exponentialSmoothing(ts, 0.3);
```

#### `OpalData.TimeSeries.decompose(timeSeries: Map, period: Integer) -> Map`

時系列を傾向、季節性、残差に分解します。

**パラメータ**:
- `timeSeries`: 時系列オブジェクト
- `period`: 季節性の周期

**戻り値**: 分解結果を含むマップ

**使用例**:
```opal
nc decomposition <- OpalData.TimeSeries.decompose(ts, 12);
nc trend <- decomposition.trend;
nc seasonal <- decomposition.seasonal;
nc residual <- decomposition.residual;
```

#### `OpalData.TimeSeries.ARIMA(p: Integer, d: Integer, q: Integer) -> Map`

ARIMAモデルを作成します。

**パラメータ**:
- `p`: 自己回帰次数
- `d`: 差分次数
- `q`: 移動平均次数

**戻り値**: ARIMAモデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.TimeSeries.ARIMA(1, 1, 1);

// モデルの学習
model.fit(ts);

// 予測
nc forecast <- model.forecast(5);
```

#### `OpalData.TimeSeries.SARIMA(p: Integer, d: Integer, q: Integer, P: Integer, D: Integer, Q: Integer, m: Integer) -> Map`

季節性ARIMAモデルを作成します。

**パラメータ**:
- `p`: 自己回帰次数
- `d`: 差分次数
- `q`: 移動平均次数
- `P`: 季節性自己回帰次数
- `D`: 季節性差分次数
- `Q`: 季節性移動平均次数
- `m`: 季節性周期

**戻り値**: SARIMAモデルオブジェクト

**使用例**:
```opal
nc model <- OpalData.TimeSeries.SARIMA(1, 1, 1, 1, 1, 1, 12);

// モデルの学習
model.fit(ts);

// 予測
nc forecast <- model.forecast(12);
```

#### `OpalData.TimeSeries.plotTimeSeries(timeSeries: Map, options: Map = {}) -> Map`

時系列データをプロットします。

**パラメータ**:
- `timeSeries`: 時系列オブジェクト
- `options`: プロットオプション（タイトル、軸ラベルなど）

**戻り値**: 可視化オブジェクト

**使用例**:
```opal
nc plot <- OpalData.TimeSeries.plotTimeSeries(ts, {
    "title": "時系列データ",
    "xLabel": "日付",
    "yLabel": "値",
    "color": "blue"
});
```

## 使用例

### データフレーム操作の例

```opal
module DataFrameExample then
    function first() -> Void then
        // OpalDataを初期化
        OpalData.initialize();
        
        // データフレームの作成
        nc data <- {
            "名前": ["田中", "佐藤", "鈴木", "高橋", "伊藤"],
            "年齢": [25, 30, 45, 22, 35],
            "給与": [300000, 350000, 450000, 280000, 400000],
            "部署": ["営業", "開発", "管理", "営業", "開発"]
        };
        
        nc df <- OpalData.DataFrame.createDataFrame(data);
        
        // データフレームの基本情報
        OpalSystemCall.("データフレーム:") -> out;
        OpalSystemCall.(df.toString()) -> out;
        
        OpalSystemCall.("列名: " + df.columns()) -> out;
        OpalSystemCall.("行数: " + df.rowCount()) -> out;
        
        // 先頭と末尾の行を表示
        OpalSystemCall.("先頭3行:") -> out;
        OpalSystemCall.(df.head(3).toString()) -> out;
        
        OpalSystemCall.("末尾2行:") -> out;
        OpalSystemCall.(df.tail(2).toString()) -> out;
        
        // 列の選択
        nc selectedDF <- df.select(["名前", "年齢"]);
        OpalSystemCall.("選択された列:") -> out;
        OpalSystemCall.(selectedDF.toString()) -> out;
        
        // フィルタリング
        nc filteredDF <- df.filter(function(row: Map) -> Boolean then
            return row.年齢 > 30 && row.給与 >= 400000;
        end);
        
        OpalSystemCall.("フィルタリング結果:") -> out;
        OpalSystemCall.(filteredDF.toString()) -> out;
        
        // ソート
        nc sortedDF <- df.sort("給与", false);
        OpalSystemCall.("給与で降順ソート:") -> out;
        OpalSystemCall.(sortedDF.toString()) -> out;
        
        // グループ化
        nc grouped <- df.groupBy("部署");
        
        for (nc dept in grouped) then
            OpalSystemCall.("部署: " + dept) -> out;
            OpalSystemCall.(grouped[dept].toString()) -> out;
        end
        
        // 統計情報
        nc stats <- df.describe();
        OpalSystemCall.("統計情報:") -> out;
        OpalSystemCall.(stats.toString()) -> out;
    end
end
```

### データ可視化の例

```opal
module VisualizationExample then
    function first() -> Void then
        // OpalDataを初期化
        OpalData.initialize();
        
        // 線グラフ
        nc lineData <- {
            "x": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "y": [2, 4, 1, 5, 3, 7, 6, 8, 9, 10]
        };
        
        nc linePlot <- OpalData.Visualization.linePlot(lineData, {
            "title": "サンプル線グラフ",
            "xLabel": "X軸",
            "yLabel": "Y軸",
            "color": "blue"
        });
        
        // 棒グラフ
        nc barData <- {
            "categories": ["A", "B", "C", "D", "E"],
            "values": [10, 25, 15, 30, 20]
        };
        
        nc barPlot <- OpalData.Visualization.barPlot(barData, {
            "title": "サンプル棒グラフ",
            "xLabel": "カテゴリ",
            "yLabel": "値",
            "color": "green"
        });
        
        // 散布図
        nc scatterData <- {
            "x": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "y": [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        };
        
        nc scatterPlot <- OpalData.Visualization.scatterPlot(scatterData, {
            "title": "サンプル散布図",
            "xLabel": "X軸",
            "yLabel": "Y軸",
            "color": "red"
        });
        
        // ヒストグラム
        nc histData <- [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 5];
        
        nc histogram <- OpalData.Visualization.histogram(histData, {
            "title": "サンプルヒストグラム",
            "xLabel": "値",
            "yLabel": "頻度",
            "bins": 5,
            "color": "purple"
        });
        
        // 円グラフ
        nc pieData <- {
            "labels": ["A", "B", "C", "D"],
            "values": [30, 20, 25, 25]
        };
        
        nc pieChart <- OpalData.Visualization.pieChart(pieData, {
            "title": "サンプル円グラフ"
        });
        
        // プロットの保存
        OpalData.Visualization.save(linePlot, "/path/to/line_plot.png");
        OpalData.Visualization.save(barPlot, "/path/to/bar_plot.png");
        OpalData.Visualization.save(scatterPlot, "/path/to/scatter_plot.png");
        OpalData.Visualization.save(histogram, "/path/to/histogram.png");
        OpalData.Visualization.save(pieChart, "/path/to/pie_chart.png");
    end
end
```

### 機械学習の例

```opal
module MachineLearningExample then
    function first() -> Void then
        // OpalDataを初期化
        OpalData.initialize();
        
        // サンプルデータの生成
        nc X <- [];
        nc y <- [];
        
        for (nc i <- 0; i < 100; i <- i + 1) then
            nc x1 <- OpalNumeric.random() * 10;
            nc x2 <- OpalNumeric.random() * 5;
            X.push([x1, x2]);
            
            // y = 2*x1 + 3*x2 + ノイズ
            y.push(2 * x1 + 3 * x2 + OpalNumeric.random() * 2 - 1);
        end
        
        // データの分割
        nc split <- OpalData.MachineLearning.trainTestSplit(X, y, 0.2, 42);
        nc X_train <- split.X_train;
        nc X_test <- split.X_test;
        nc y_train <- split.y_train;
        nc y_test <- split.y_test;
        
        OpalSystemCall.("訓練データサイズ: " + X_train.length()) -> out;
        OpalSystemCall.("テストデータサイズ: " + X_test.length()) -> out;
        
        // 線形回帰モデル
        nc linearModel <- OpalData.MachineLearning.LinearRegression();
        linearModel.fit(X_train, y_train);
        
        // 予測
        nc predictions <- linearModel.predict(X_test);
        
        // モデル評価
        nc metrics <- OpalData.MachineLearning.evaluateRegression(y_test, predictions);
        
        OpalSystemCall.("線形回帰モデルの評価:") -> out;
        OpalSystemCall.("  MSE: " + metrics.mse) -> out;
        OpalSystemCall.("  RMSE: " + metrics.rmse) -> out;
        OpalSystemCall.("  MAE: " + metrics.mae) -> out;
        OpalSystemCall.("  R²: " + metrics.r2) -> out;
        
        // 交差検証
        nc cvScores <- OpalData.MachineLearning.crossValidation(linearModel, X, y, 5);
        
        OpalSystemCall.("交差検証スコア:") -> out;
        OpalSystemCall.("  平均R²: " + cvScores.mean) -> out;
        OpalSystemCall.("  標準偏差: " + cvScores.std) -> out;
        
        // 決定木モデル
        nc treeModel <- OpalData.MachineLearning.DecisionTree({
            "maxDepth": 5
        });
        
        treeModel.fit(X_train, y_train);
        nc treePredictions <- treeModel.predict(X_test);
        nc treeMetrics <- OpalData.MachineLearning.evaluateRegression(y_test, treePredictions);
        
        OpalSystemCall.("決定木モデルの評価:") -> out;
        OpalSystemCall.("  MSE: " + treeMetrics.mse) -> out;
        OpalSystemCall.("  R²: " + treeMetrics.r2) -> out;
    end
end
```

### 時系列分析の例

```opal
module TimeSeriesExample then
    function first() -> Void then
        // OpalDataを初期化
        OpalData.initialize();
        
        // 時系列データの生成
        nc dates <- [];
        nc values <- [];
        
        for (nc i <- 0; i < 100; i <- i + 1) then
            nc date <- "2023-01-" + OpalCore.Text.padStart((i % 30) + 1, 2, "0");
            dates.push(date);
            
            // トレンド + 季節性 + ノイズ
            nc trend <- i * 0.1;
            nc seasonal <- OpalNumeric.sin(i * 0.1) * 5;
            nc noise <- (OpalNumeric.random() - 0.5) * 2;
            
            values.push(trend + seasonal + noise);
        end
        
        // 時系列オブジェクトの作成
        nc ts <- OpalData.TimeSeries.createTimeSeries(values, dates);
        
        // 移動平均
        nc ma <- OpalData.TimeSeries.movingAverage(ts, 7);
        
        OpalSystemCall.("移動平均の最初の5値:") -> out;
        for (nc i <- 0; i < 5; i <- i + 1) then
            OpalSystemCall.("  " + ma.dates[i] + ": " + ma.values[i]) -> out;
        end
        
        // 指数平滑化
        nc smoothed <- OpalData.TimeSeries.exponentialSmoothing(ts, 0.3);
        
        OpalSystemCall.("指数平滑化の最初の5値:") -> out;
        for (nc i <- 0; i < 5; i <- i + 1) then
            OpalSystemCall.("  " + smoothed.dates[i] + ": " + smoothed.values[i]) -> out;
        end
        
        // 時系列分解
        nc decomposition <- OpalData.TimeSeries.decompose(ts, 30);
        
        OpalSystemCall.("時系列分解:") -> out;
        OpalSystemCall.("  トレンドの最初の値: " + decomposition.trend.values[0]) -> out;
        OpalSystemCall.("  季節性の最初の値: " + decomposition.seasonal.values[0]) -> out;
        OpalSystemCall.("  残差の最初の値: " + decomposition.residual.values[0]) -> out;
        
        // ARIMAモデル
        nc arimaModel <- OpalData.TimeSeries.ARIMA(1, 1, 1);
        arimaModel.fit(ts);
        
        // 予測
        nc forecast <- arimaModel.forecast(10);
        
        OpalSystemCall.("ARIMA予測:") -> out;
        for (nc i <- 0; i < forecast.values.length(); i <- i + 1) then
            OpalSystemCall.("  " + forecast.dates[i] + ": " + forecast.values[i]) -> out;
        end
        
        // 時系列プロット
        nc tsPlot <- OpalData.TimeSeries.plotTimeSeries(ts, {
            "title": "時系列データ",
            "xLabel": "日付",
            "yLabel": "値",
            "color": "blue"
        });
        
        // 予測プロット
        nc forecastPlot <- OpalData.TimeSeries.plotTimeSeries(forecast, {
            "title": "ARIMA予測",
            "xLabel": "日付",
            "yLabel": "予測値",
            "color": "red"
        });
        
        // プロットの保存
        OpalData.Visualization.save(tsPlot, "/path/to/time_series.png");
        OpalData.Visualization.save(forecastPlot, "/path/to/forecast.png");
    end
end
```

## ライセンス

OpalDataライブラリはMITライセンスの下で提供されています。
