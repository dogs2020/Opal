# OpalCross ライブラリドキュメント

## 概要

OpalCrossは、Julia、Python、JavaScriptの各言語の強みを組み合わせた統合ライブラリです。このライブラリは、OpalNumeric（Julia風）、OpalData（Python風）、OpalUI（JavaScript風）の機能を連携させ、データ変換、統合機械学習、データ可視化とダッシュボード作成などの機能を提供します。OpalCrossを使用することで、各言語の強みを活かした統合アプリケーションを効率的に開発できます。

## 機能構成

OpalCrossライブラリは以下の主要機能で構成されています：

1. **データ変換ユーティリティ** - 異なるライブラリ間のデータ形式変換
2. **統合機械学習機能** - 複数のライブラリの機能を組み合わせた機械学習
3. **データ可視化とダッシュボード** - インタラクティブなデータ可視化とダッシュボード作成

## インストール方法

OpalCrossライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalCross`ディレクトリをプロジェクトにコピーします
2. 依存ライブラリ（OpalCore、OpalNumeric、OpalData、OpalUI）もプロジェクトに含めます
3. Opalプログラムの先頭で`OpalCross`モジュールをインポートします

```opal
// 必要なモジュールをインポート
import OpalCore;
import OpalNumeric;
import OpalData;
import OpalUI;
import OpalCross;

module MyApp then
    function first() -> Void then
        // 各ライブラリを初期化
        OpalCore.initialize();
        OpalNumeric.initialize();
        OpalData.initialize();
        OpalUI.initialize();
        OpalCross.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalCross!") -> out;
    end
end
```

## API リファレンス

### コアモジュール

#### `OpalCross.initialize() -> Boolean`

OpalCrossライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalCross.initialize();
```

#### `OpalCross.VERSION -> String`

OpalCrossライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.0.0"）

**使用例**:
```opal
OpalSystemCall.("OpalCross version: " + OpalCross.VERSION) -> out;
```

### データ変換ユーティリティ

#### `OpalCross.convertMatrixToDataFrame(matrix: Matrix) -> DataFrame`

OpalNumericの行列をOpalDataのデータフレームに変換します。

**パラメータ**:
- `matrix`: 変換する行列（OpalNumeric.LinearAlgebra.Matrix）

**戻り値**: 変換されたデータフレーム（OpalData.DataFrame）

**使用例**:
```opal
nc matrix <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]);

nc df <- OpalCross.convertMatrixToDataFrame(matrix);
OpalSystemCall.(df.toString()) -> out;
```

#### `OpalCross.convertDataFrameToMatrix(dataFrame: DataFrame, columns: Array = null) -> Matrix`

OpalDataのデータフレームをOpalNumericの行列に変換します。

**パラメータ**:
- `dataFrame`: 変換するデータフレーム（OpalData.DataFrame）
- `columns`: 変換に使用する列名の配列（指定しない場合は数値列のみ使用）

**戻り値**: 変換された行列（OpalNumeric.LinearAlgebra.Matrix）

**使用例**:
```opal
nc data <- {
    "A": [1, 4, 7],
    "B": [2, 5, 8],
    "C": [3, 6, 9]
};

nc df <- OpalData.DataFrame.createDataFrame(data);
nc matrix <- OpalCross.convertDataFrameToMatrix(df);

OpalSystemCall.("行列の次元: " + matrix.rows() + "x" + matrix.cols()) -> out;
```

#### `OpalCross.convertDataFrameToUITable(dataFrame: DataFrame, options: Map = {}) -> Component`

OpalDataのデータフレームをOpalUIのテーブルコンポーネントに変換します。

**パラメータ**:
- `dataFrame`: 変換するデータフレーム（OpalData.DataFrame）
- `options`: テーブルオプション（ページネーション、ソート、フィルタリングなど）

**戻り値**: テーブルコンポーネント（OpalUI.Component）

**使用例**:
```opal
nc data <- {
    "名前": ["田中", "佐藤", "鈴木", "高橋"],
    "年齢": [25, 30, 45, 22],
    "給与": [300000, 350000, 450000, 280000]
};

nc df <- OpalData.DataFrame.createDataFrame(data);
nc tableComponent <- OpalCross.convertDataFrameToUITable(df, {
    "pagination": true,
    "pageSize": 10,
    "sortable": true,
    "filterable": true
});

OpalUI.render(tableComponent, "#data-table");
```

#### `OpalCross.convertVisualizationToUIComponent(visualization: Map) -> Component`

OpalDataの可視化オブジェクトをOpalUIのコンポーネントに変換します。

**パラメータ**:
- `visualization`: 変換する可視化オブジェクト（OpalData.Visualization）

**戻り値**: UIコンポーネント（OpalUI.Component）

**使用例**:
```opal
nc data <- {
    "x": [1, 2, 3, 4, 5],
    "y": [2, 4, 1, 5, 3]
};

nc plot <- OpalData.Visualization.linePlot(data, {
    "title": "サンプル線グラフ",
    "xLabel": "X軸",
    "yLabel": "Y軸"
});

nc plotComponent <- OpalCross.convertVisualizationToUIComponent(plot);
OpalUI.render(plotComponent, "#chart-container");
```

### 統合機械学習機能

#### `OpalCross.LinearRegression(options: Map = {}) -> Map`

OpalNumericの行列演算とOpalDataの機械学習を組み合わせた線形回帰モデルを作成します。

**パラメータ**:
- `options`: モデルオプション（正則化パラメータ、最適化アルゴリズムなど）

**戻り値**: 線形回帰モデルオブジェクト

**使用例**:
```opal
// モデルの作成
nc model <- OpalCross.LinearRegression({
    "regularization": "l2",
    "alpha": 0.01,
    "optimizer": "gradient_descent"
});

// データの準備
nc X <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2],
    [2, 3],
    [3, 4],
    [4, 5]
]);

nc y <- [3, 5, 7, 9];

// モデルの学習
model.fit(X, y);

// 予測
nc X_new <- OpalNumeric.LinearAlgebra.createMatrix([
    [5, 6],
    [6, 7]
]);

nc predictions <- model.predict(X_new);
OpalSystemCall.("予測値: " + predictions) -> out;

// モデルパラメータの取得
nc params <- model.getParams();
OpalSystemCall.("係数: " + params.coefficients) -> out;
OpalSystemCall.("切片: " + params.intercept) -> out;
```

#### `OpalCross.Clustering(options: Map = {}) -> Map`

OpalNumericの最適化とOpalDataの前処理を組み合わせたクラスタリングモデルを作成します。

**パラメータ**:
- `options`: モデルオプション（アルゴリズム、クラスタ数など）

**戻り値**: クラスタリングモデルオブジェクト

**使用例**:
```opal
// モデルの作成
nc model <- OpalCross.Clustering({
    "algorithm": "kmeans",
    "nClusters": 3,
    "maxIterations": 100,
    "initialization": "kmeans++"
});

// データの準備
nc data <- OpalNumeric.LinearAlgebra.createMatrix([
    [1, 2],
    [1, 3],
    [2, 2],
    [8, 7],
    [8, 8],
    [9, 7],
    [15, 15],
    [16, 16],
    [15, 14]
]);

// データの前処理
nc preprocessed <- model.preprocess(data);

// モデルの学習
model.fit(preprocessed);

// クラスタの予測
nc clusters <- model.predict(preprocessed);
OpalSystemCall.("クラスタ: " + clusters) -> out;

// クラスタ中心の取得
nc centers <- model.getCenters();
OpalSystemCall.("クラスタ中心: " + centers) -> out;
```

#### `OpalCross.TimeSeriesForecasting(options: Map = {}) -> Map`

OpalNumericの微分方程式ソルバーとOpalDataの時系列分析を組み合わせた時系列予測モデルを作成します。

**パラメータ**:
- `options`: モデルオプション（アルゴリズム、パラメータなど）

**戻り値**: 時系列予測モデルオブジェクト

**使用例**:
```opal
// モデルの作成
nc model <- OpalCross.TimeSeriesForecasting({
    "algorithm": "hybrid",
    "components": ["arima", "exponential_smoothing", "neural_network"],
    "seasonality": 12
});

// データの準備
nc dates <- [];
nc values <- [];

for (nc i <- 0; i < 100; i <- i + 1) then
    dates.push("2023-01-" + OpalCore.Text.padStart((i % 30) + 1, 2, "0"));
    
    // トレンド + 季節性 + ノイズ
    nc trend <- i * 0.1;
    nc seasonal <- OpalNumeric.sin(i * 0.1) * 5;
    nc noise <- (OpalNumeric.random() - 0.5) * 2;
    
    values.push(trend + seasonal + noise);
end

nc timeSeries <- OpalData.TimeSeries.createTimeSeries(values, dates);

// モデルの学習
model.fit(timeSeries);

// 予測
nc forecast <- model.forecast(24); // 24期間先まで予測

// 予測結果の可視化
nc forecastPlot <- model.plotForecast({
    "title": "時系列予測",
    "xLabel": "日付",
    "yLabel": "値",
    "showConfidenceIntervals": true
});

// 可視化をUIコンポーネントに変換
nc forecastComponent <- OpalCross.convertVisualizationToUIComponent(forecastPlot);
OpalUI.render(forecastComponent, "#forecast-container");
```

### データ可視化とダッシュボード

#### `OpalCross.createDashboard(config: Map) -> Component`

インタラクティブなダッシュボードを作成します。

**パラメータ**:
- `config`: ダッシュボード設定（レイアウト、コンポーネント、データソースなど）

**戻り値**: ダッシュボードコンポーネント（OpalUI.Component）

**使用例**:
```opal
// データの準備
nc salesData <- OpalData.DataFrame.readCSV("/path/to/sales_data.csv");
nc revenueData <- {
    "labels": ["1月", "2月", "3月", "4月", "5月", "6月"],
    "values": [12000, 15000, 18000, 14000, 21000, 22000]
};
nc customerData <- OpalData.DataFrame.readCSV("/path/to/customer_data.csv");

// 可視化の作成
nc salesChart <- OpalData.Visualization.linePlot({
    "x": salesData.getColumn("date"),
    "y": salesData.getColumn("sales")
}, {
    "title": "月間売上",
    "xLabel": "日付",
    "yLabel": "売上"
});

nc revenueChart <- OpalData.Visualization.barPlot(revenueData, {
    "title": "四半期収益",
    "xLabel": "月",
    "yLabel": "収益"
});

nc customerTable <- OpalCross.convertDataFrameToUITable(customerData, {
    "pagination": true,
    "pageSize": 5
});

// ダッシュボードの作成
nc dashboard <- OpalCross.createDashboard({
    "title": "ビジネスダッシュボード",
    "layout": [
        { "id": "sales", "x": 0, "y": 0, "width": 6, "height": 4 },
        { "id": "revenue", "x": 6, "y": 0, "width": 6, "height": 4 },
        { "id": "customers", "x": 0, "y": 4, "width": 12, "height": 6 }
    ],
    "components": [
        {
            "id": "sales",
            "title": "売上トレンド",
            "type": "chart",
            "content": salesChart
        },
        {
            "id": "revenue",
            "title": "四半期収益",
            "type": "chart",
            "content": revenueChart
        },
        {
            "id": "customers",
            "title": "顧客データ",
            "type": "table",
            "content": customerTable
        }
    ],
    "theme": "light",
    "responsive": true,
    "refreshInterval": 60 // 60秒ごとに更新
});

// ダッシュボードのレンダリング
OpalUI.render(dashboard, "#dashboard-container");
```

#### `OpalCross.Chart(type: String, data: Any, options: Map = {}) -> Component`

様々なチャートタイプを作成するための統合コンポーネントを提供します。

**パラメータ**:
- `type`: チャートタイプ（"line"、"bar"、"scatter"、"pie"、"heatmap"など）
- `data`: チャートデータ
- `options`: チャートオプション（タイトル、軸ラベル、色など）

**戻り値**: チャートコンポーネント（OpalUI.Component）

**使用例**:
```opal
// 線グラフ
nc lineChart <- OpalCross.Chart("line", {
    "x": [1, 2, 3, 4, 5],
    "y": [2, 4, 1, 5, 3]
}, {
    "title": "サンプル線グラフ",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "color": "blue",
    "interactive": true
});

// 棒グラフ
nc barChart <- OpalCross.Chart("bar", {
    "categories": ["A", "B", "C", "D", "E"],
    "values": [10, 25, 15, 30, 20]
}, {
    "title": "サンプル棒グラフ",
    "xLabel": "カテゴリ",
    "yLabel": "値",
    "color": "green",
    "interactive": true
});

// 散布図
nc scatterChart <- OpalCross.Chart("scatter", {
    "x": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    "y": [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
}, {
    "title": "サンプル散布図",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "color": "red",
    "interactive": true
});

// 円グラフ
nc pieChart <- OpalCross.Chart("pie", {
    "labels": ["A", "B", "C", "D"],
    "values": [30, 20, 25, 25]
}, {
    "title": "サンプル円グラフ",
    "interactive": true
});

// ヒートマップ
nc heatmapChart <- OpalCross.Chart("heatmap", [
    [1, 2, 3, 4],
    [2, 4, 6, 8],
    [3, 6, 9, 12],
    [4, 8, 12, 16]
], {
    "title": "サンプルヒートマップ",
    "xLabel": "X軸",
    "yLabel": "Y軸",
    "colorScale": "viridis",
    "interactive": true
});

// チャートのレンダリング
OpalUI.render(lineChart, "#line-chart-container");
OpalUI.render(barChart, "#bar-chart-container");
OpalUI.render(scatterChart, "#scatter-chart-container");
OpalUI.render(pieChart, "#pie-chart-container");
OpalUI.render(heatmapChart, "#heatmap-chart-container");
```

#### `OpalCross.DataExplorer(data: DataFrame, options: Map = {}) -> Component`

データ探索と分析のためのインタラクティブなコンポーネントを提供します。

**パラメータ**:
- `data`: 探索するデータフレーム（OpalData.DataFrame）
- `options`: 探索オプション（表示する統計情報、可視化タイプなど）

**戻り値**: データ探索コンポーネント（OpalUI.Component）

**使用例**:
```opal
// データの準備
nc data <- OpalData.DataFrame.readCSV("/path/to/dataset.csv");

// データ探索コンポーネントの作成
nc explorer <- OpalCross.DataExplorer(data, {
    "showStatistics": true,
    "showHistograms": true,
    "showCorrelations": true,
    "showScatterMatrix": true,
    "showMissingValues": true,
    "interactive": true
});

// コンポーネントのレンダリング
OpalUI.render(explorer, "#data-explorer-container");
```

#### `OpalCross.ModelEvaluator(model: Any, testData: Any, options: Map = {}) -> Component`

機械学習モデルの評価と解釈のためのインタラクティブなコンポーネントを提供します。

**パラメータ**:
- `model`: 評価するモデル
- `testData`: テストデータ
- `options`: 評価オプション（評価指標、可視化タイプなど）

**戻り値**: モデル評価コンポーネント（OpalUI.Component）

**使用例**:
```opal
// モデルとテストデータの準備
nc model <- OpalCross.LinearRegression();
model.fit(X_train, y_train);

// モデル評価コンポーネントの作成
nc evaluator <- OpalCross.ModelEvaluator(model, {
    "X": X_test,
    "y": y_test
}, {
    "metrics": ["mse", "rmse", "mae", "r2"],
    "showPredictions": true,
    "showResiduals": true,
    "showFeatureImportance": true,
    "interactive": true
});

// コンポーネントのレンダリング
OpalUI.render(evaluator, "#model-evaluator-container");
```

## 使用例

### データ変換と統合の例

```opal
module DataIntegrationExample then
    function first() -> Void then
        // 必要なライブラリを初期化
        OpalCore.initialize();
        OpalNumeric.initialize();
        OpalData.initialize();
        OpalUI.initialize();
        OpalCross.initialize();
        
        // 行列データの作成（OpalNumeric）
        nc matrix <- OpalNumeric.LinearAlgebra.createMatrix([
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9],
            [10, 11, 12]
        ]);
        
        OpalSystemCall.("行列データ:") -> out;
        OpalSystemCall.(matrix.toString()) -> out;
        
        // 行列をデータフレームに変換
        nc df <- OpalCross.convertMatrixToDataFrame(matrix);
        
        OpalSystemCall.("データフレームに変換:") -> out;
        OpalSystemCall.(df.toString()) -> out;
        
        // データフレームに列名を設定
        df.setColumnNames(["A", "B", "C"]);
        
        // 新しい列を追加（OpalData機能）
        df.addColumn("D", [4, 7, 10, 13]);
        df.addColumn("E", function(row) -> Number then
            return row.A + row.C;
        end);
        
        OpalSystemCall.("列を追加したデータフレーム:") -> out;
        OpalSystemCall.(df.toString()) -> out;
        
        // データフレームを行列に戻す（数値列のみ）
        nc newMatrix <- OpalCross.convertDataFrameToMatrix(df);
        
        OpalSystemCall.("行列に戻したデータ:") -> out;
        OpalSystemCall.(newMatrix.toString()) -> out;
        
        // データフレームをUIテーブルに変換
        nc tableComponent <- OpalCross.convertDataFrameToUITable(df, {
            "sortable": true,
            "filterable": true,
            "pagination": true,
            "pageSize": 10
        });
        
        // 統計分析（OpalNumeric機能）
        nc columnC <- df.getColumn("C");
        nc mean <- OpalNumeric.Statistics.mean(columnC);
        nc std <- OpalNumeric.Statistics.standardDeviation(columnC);
        
        OpalSystemCall.("列Cの統計:") -> out;
        OpalSystemCall.("  平均: " + mean) -> out;
        OpalSystemCall.("  標準偏差: " + std) -> out;
        
        // 可視化（OpalData機能）
        nc plot <- OpalData.Visualization.scatterPlot({
            "x": df.getColumn("A"),
            "y": df.getColumn("E")
        }, {
            "title": "AとEの散布図",
            "xLabel": "A",
            "yLabel": "E",
            "color": "blue"
        });
        
        // 可視化をUIコンポーネントに変換
        nc plotComponent <- OpalCross.convertVisualizationToUIComponent(plot);
        
        // UIコンポーネントをレンダリング（実際のアプリケーションでは）
        // OpalUI.render(tableComponent, "#table-container");
        // OpalUI.render(plotComponent, "#plot-container");
    end
end
```

### 統合機械学習の例

```opal
module IntegratedMLExample then
    function first() -> Void then
        // 必要なライブラリを初期化
        OpalCore.initialize();
        OpalNumeric.initialize();
        OpalData.initialize();
        OpalUI.initialize();
        OpalCross.initialize();
        
        // サンプルデータの生成
        nc X_data <- [];
        nc y_data <- [];
        
        for (nc i <- 0; i < 100; i <- i + 1) then
            nc x1 <- OpalNumeric.random() * 10;
            nc x2 <- OpalNumeric.random() * 5;
            X_data.push([x1, x2]);
            
            // y = 2*x1 + 3*x2 + ノイズ
            y_data.push(2 * x1 + 3 * x2 + OpalNumeric.random() * 2 - 1);
        end
        
        // データをOpalNumeric行列に変換
        nc X <- OpalNumeric.LinearAlgebra.createMatrix(X_data);
        nc y <- y_data;
        
        // データの分割
        nc split <- OpalData.MachineLearning.trainTestSplit(X_data, y_data, 0.2, 42);
        nc X_train_data <- split.X_train;
        nc X_test_data <- split.X_test;
        nc y_train <- split.y_train;
        nc y_test <- split.y_test;
        
        // 訓練データを行列に変換
        nc X_train <- OpalNumeric.LinearAlgebra.createMatrix(X_train_data);
        
        // 統合線形回帰モデルの作成
        nc model <- OpalCross.LinearRegression({
            "regularization": "l2",
            "alpha": 0.01,
            "optimizer": "gradient_descent"
        });
        
        // モデルの学習
        model.fit(X_train, y_train);
        
        // テストデータを行列に変換
        nc X_test <- OpalNumeric.LinearAlgebra.createMatrix(X_test_data);
        
        // 予測
        nc predictions <- model.predict(X_test);
        
        // モデルパラメータの取得
        nc params <- model.getParams();
        OpalSystemCall.("モデルパラメータ:") -> out;
        OpalSystemCall.("  係数: " + params.coefficients) -> out;
        OpalSystemCall.("  切片: " + params.intercept) -> out;
        
        // モデル評価
        nc metrics <- OpalData.MachineLearning.evaluateRegression(y_test, predictions);
        OpalSystemCall.("モデル評価:") -> out;
        OpalSystemCall.("  MSE: " + metrics.mse) -> out;
        OpalSystemCall.("  RMSE: " + metrics.rmse) -> out;
        OpalSystemCall.("  MAE: " + metrics.mae) -> out;
        OpalSystemCall.("  R²: " + metrics.r2) -> out;
        
        // 予測と実際の値の比較
        nc results <- {
            "actual": y_test,
            "predicted": predictions
        };
        
        nc resultsDF <- OpalData.DataFrame.createDataFrame(results);
        
        // 予測結果の可視化
        nc plot <- OpalData.Visualization.scatterPlot({
            "x": resultsDF.getColumn("actual"),
            "y": resultsDF.getColumn("predicted")
        }, {
            "title": "実際の値 vs 予測値",
            "xLabel": "実際の値",
            "yLabel": "予測値",
            "color": "blue"
        });
        
        // 可視化をUIコンポーネントに変換
        nc plotComponent <- OpalCross.convertVisualizationToUIComponent(plot);
        
        // モデル評価コンポーネントの作成
        nc evaluator <- OpalCross.ModelEvaluator(model, {
            "X": X_test,
            "y": y_test
        }, {
            "metrics": ["mse", "rmse", "mae", "r2"],
            "showPredictions": true,
            "showResiduals": true,
            "showFeatureImportance": true,
            "interactive": true
        });
        
        // UIコンポーネントをレンダリング（実際のアプリケーションでは）
        // OpalUI.render(plotComponent, "#plot-container");
        // OpalUI.render(evaluator, "#evaluator-container");
    end
end
```

### ダッシュボード作成の例

```opal
module DashboardExample then
    function first() -> Void then
        // 必要なライブラリを初期化
        OpalCore.initialize();
        OpalNumeric.initialize();
        OpalData.initialize();
        OpalUI.initialize();
        OpalCross.initialize();
        
        // サンプルデータの生成
        
        // 売上データ
        nc salesDates <- [];
        nc salesValues <- [];
        
        for (nc i <- 0; i < 30; i <- i + 1) then
            salesDates.push("2023-06-" + OpalCore.Text.padStart(i + 1, 2, "0"));
            
            // 基本トレンド + 週末効果 + ランダム変動
            nc base <- 100 + i * 2;
            nc weekend <- (i % 7 == 5 || i % 7 == 6) ? 30 : 0;
            nc random <- OpalNumeric.random() * 20 - 10;
            
            salesValues.push(base + weekend + random);
        end
        
        nc salesData <- {
            "date": salesDates,
            "sales": salesValues
        };
        
        nc salesDF <- OpalData.DataFrame.createDataFrame(salesData);
        
        // 製品カテゴリ別収益
        nc categoryData <- {
            "category": ["電子機器", "衣類", "食品", "家具", "書籍"],
            "revenue": [45000, 28000, 35000, 18000, 12000]
        };
        
        nc categoryDF <- OpalData.DataFrame.createDataFrame(categoryData);
        
        // 顧客データ
        nc customerData <- {
            "id": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "name": ["田中太郎", "佐藤花子", "鈴木一郎", "高橋雅子", "伊藤健太",
                    "渡辺美咲", "山本裕子", "中村大輔", "小林誠", "加藤梨花"],
            "age": [34, 28, 45, 22, 39, 31, 27, 42, 36, 29],
            "purchases": [5, 8, 3, 10, 7, 4, 6, 2, 9, 5],
            "totalSpent": [25000, 42000, 15000, 55000, 38000, 22000, 31000, 12000, 47000, 28000]
        };
        
        nc customerDF <- OpalData.DataFrame.createDataFrame(customerData);
        
        // 地域別売上
        nc regionData <- [
            [12000, 15000, 9000, 18000],
            [14000, 8000, 11000, 13000],
            [9000, 12000, 8000, 7000],
            [11000, 10000, 13000, 9000]
        ];
        
        nc regionLabels <- ["北", "東", "西", "南"];
        nc quarterLabels <- ["Q1", "Q2", "Q3", "Q4"];
        
        // 可視化の作成
        
        // 日次売上トレンド
        nc salesChart <- OpalData.Visualization.linePlot({
            "x": salesDF.getColumn("date"),
            "y": salesDF.getColumn("sales")
        }, {
            "title": "日次売上トレンド",
            "xLabel": "日付",
            "yLabel": "売上",
            "color": "blue"
        });
        
        // カテゴリ別収益
        nc categoryChart <- OpalData.Visualization.barPlot({
            "categories": categoryDF.getColumn("category"),
            "values": categoryDF.getColumn("revenue")
        }, {
            "title": "カテゴリ別収益",
            "xLabel": "カテゴリ",
            "yLabel": "収益",
            "color": "green"
        });
        
        // 顧客テーブル
        nc customerTable <- OpalCross.convertDataFrameToUITable(customerDF, {
            "pagination": true,
            "pageSize": 5,
            "sortable": true,
            "filterable": true
        });
        
        // 地域別売上ヒートマップ
        nc regionChart <- OpalData.Visualization.heatmap(regionData, {
            "title": "地域別四半期売上",
            "xLabel": "四半期",
            "yLabel": "地域",
            "xTickLabels": quarterLabels,
            "yTickLabels": regionLabels,
            "colorScale": "viridis"
        });
        
        // 顧客年齢分布
        nc ageChart <- OpalData.Visualization.histogram(customerDF.getColumn("age"), {
            "title": "顧客年齢分布",
            "xLabel": "年齢",
            "yLabel": "顧客数",
            "bins": 5,
            "color": "purple"
        });
        
        // 可視化をUIコンポーネントに変換
        nc salesChartComponent <- OpalCross.convertVisualizationToUIComponent(salesChart);
        nc categoryChartComponent <- OpalCross.convertVisualizationToUIComponent(categoryChart);
        nc regionChartComponent <- OpalCross.convertVisualizationToUIComponent(regionChart);
        nc ageChartComponent <- OpalCross.convertVisualizationToUIComponent(ageChart);
        
        // ダッシュボードの作成
        nc dashboard <- OpalCross.createDashboard({
            "title": "ビジネスパフォーマンスダッシュボード",
            "layout": [
                { "id": "sales", "x": 0, "y": 0, "width": 8, "height": 4 },
                { "id": "category", "x": 8, "y": 0, "width": 4, "height": 4 },
                { "id": "customers", "x": 0, "y": 4, "width": 12, "height": 6 },
                { "id": "region", "x": 0, "y": 10, "width": 8, "height": 5 },
                { "id": "age", "x": 8, "y": 10, "width": 4, "height": 5 }
            ],
            "components": [
                {
                    "id": "sales",
                    "title": "日次売上トレンド",
                    "type": "chart",
                    "content": salesChartComponent
                },
                {
                    "id": "category",
                    "title": "カテゴリ別収益",
                    "type": "chart",
                    "content": categoryChartComponent
                },
                {
                    "id": "customers",
                    "title": "顧客データ",
                    "type": "table",
                    "content": customerTable
                },
                {
                    "id": "region",
                    "title": "地域別四半期売上",
                    "type": "chart",
                    "content": regionChartComponent
                },
                {
                    "id": "age",
                    "title": "顧客年齢分布",
                    "type": "chart",
                    "content": ageChartComponent
                }
            ],
            "theme": "light",
            "responsive": true,
            "refreshInterval": 60 // 60秒ごとに更新
        });
        
        // ダッシュボードのレンダリング（実際のアプリケーションでは）
        // OpalUI.render(dashboard, "#dashboard-container");
    end
end
```

## ライセンス

OpalCrossライブラリはMITライセンスの下で提供されています。
