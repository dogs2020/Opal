# OpalUI ライブラリドキュメント

## 概要

OpalUIは、JavaScript風のUI構築と Web フレームワーク機能を提供する Opal 言語用ライブラリです。このライブラリは、React 風のコンポーネントベースのアーキテクチャ、仮想 DOM、状態管理、イベント処理、スタイリング、アニメーション、ルーティングなど、モダンな Web アプリケーション開発に必要な機能を提供します。

## モジュール構成

OpalUIライブラリは以下のサブモジュールで構成されています：

1. **Component** - React 風のコンポーネントシステム
2. **VirtualDOM** - 効率的な DOM 更新システム
3. **State** - 状態管理システム
4. **Event** - イベント処理システム
5. **Styling** - スタイリングシステム
6. **Animation** - アニメーションシステム
7. **Router** - ルーティングシステム

## インストール方法

OpalUIライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalUI`ディレクトリとそのサブディレクトリをプロジェクトにコピーします
2. Opalプログラムの先頭で`OpalUI`モジュールをインポートします

```opal
// OpalUIモジュールをインポート
import OpalUI;

module MyApp then
    function first() -> Void then
        // OpalUIを初期化
        OpalUI.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalUI!") -> out;
    end
end
```

## API リファレンス

### コアモジュール

#### `OpalUI.initialize() -> Boolean`

OpalUIライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalUI.initialize();
```

#### `OpalUI.VERSION -> String`

OpalUIライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.0.0"）

**使用例**:
```opal
OpalSystemCall.("OpalUI version: " + OpalUI.VERSION) -> out;
```

#### `OpalUI.render(component: Component, container: String) -> Void`

コンポーネントをDOMコンテナにレンダリングします。

**パラメータ**:
- `component`: レンダリングするコンポーネント
- `container`: コンテナのセレクタ（例: "#app"）

**使用例**:
```opal
nc app <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement("div", { "className": "app" }, "Hello, World!");
    end
});

OpalUI.render(app, "#root");
```

### Component モジュール

#### `OpalUI.Component.create(config: Map) -> Component`

新しいコンポーネントを作成します。

**パラメータ**:
- `config`: コンポーネント設定（render、state、lifecycle methodsなど）

**戻り値**: 新しいコンポーネント

**使用例**:
```opal
nc counter <- OpalUI.Component.create({
    "initialState": {
        "count": 0
    },
    "render": function() -> Any then
        return OpalUI.createElement("div", null, [
            OpalUI.createElement("h1", null, "カウント: " + this.state.count),
            OpalUI.createElement("button", {
                "onClick": this.increment
            }, "増加")
        ]);
    end,
    "increment": function() -> Void then
        this.setState({
            "count": this.state.count + 1
        });
    end
});
```

#### `OpalUI.createElement(type: String | Component, props: Map = null, children: Any = null) -> VirtualNode`

仮想DOMノードを作成します。

**パラメータ**:
- `type`: HTML要素名またはコンポーネント
- `props`: プロパティ（属性、イベントハンドラなど）
- `children`: 子要素（文字列、数値、または他の仮想ノード）

**戻り値**: 仮想DOMノード

**使用例**:
```opal
nc element <- OpalUI.createElement("div", {
    "className": "container",
    "id": "main"
}, [
    OpalUI.createElement("h1", null, "タイトル"),
    OpalUI.createElement("p", null, "テキスト内容")
]);
```

#### `OpalUI.Component.Fragment(children: Array) -> VirtualNode`

複数の要素をラップするためのフラグメントを作成します。

**パラメータ**:
- `children`: 子要素の配列

**戻り値**: フラグメントノード

**使用例**:
```opal
nc fragment <- OpalUI.Component.Fragment([
    OpalUI.createElement("h1", null, "タイトル"),
    OpalUI.createElement("p", null, "段落1"),
    OpalUI.createElement("p", null, "段落2")
]);
```

#### `Component.setState(newState: Map) -> Void`

コンポーネントの状態を更新します。

**パラメータ**:
- `newState`: 新しい状態のマップ

**使用例**:
```opal
this.setState({
    "count": this.state.count + 1,
    "lastUpdated": Date.now()
});
```

#### `Component.forceUpdate() -> Void`

コンポーネントの再レンダリングを強制します。

**使用例**:
```opal
this.forceUpdate();
```

#### `OpalUI.Component.memo(component: Component) -> Component`

コンポーネントをメモ化して、不要な再レンダリングを防ぎます。

**パラメータ**:
- `component`: メモ化するコンポーネント

**戻り値**: メモ化されたコンポーネント

**使用例**:
```opal
nc MemoizedComponent <- OpalUI.Component.memo(MyComponent);
```

#### `OpalUI.Component.Context.create(defaultValue: Any = null) -> Map`

新しいコンテキストを作成します。

**パラメータ**:
- `defaultValue`: コンテキストのデフォルト値

**戻り値**: Providerコンポーネントとコンシューマーを含むマップ

**使用例**:
```opal
nc ThemeContext <- OpalUI.Component.Context.create({
    "theme": "light",
    "toggleTheme": function() -> Void then end
});

// プロバイダーの使用
nc app <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement(ThemeContext.Provider, {
            "value": {
                "theme": "dark",
                "toggleTheme": this.toggleTheme
            }
        }, [
            OpalUI.createElement(ThemedButton, null, null)
        ]);
    end,
    "toggleTheme": function() -> Void then
        // テーマ切り替えロジック
    end
});

// コンシューマーの使用
nc ThemedButton <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement(ThemeContext.Consumer, null, function(context) -> Any then
            return OpalUI.createElement("button", {
                "className": context.theme
            }, "テーマ切り替え");
        end);
    end
});
```

### VirtualDOM モジュール

#### `OpalUI.VirtualDOM.diff(oldNode: VirtualNode, newNode: VirtualNode) -> Array`

2つの仮想DOMツリー間の差分を計算します。

**パラメータ**:
- `oldNode`: 古い仮想DOMノード
- `newNode`: 新しい仮想DOMノード

**戻り値**: パッチ操作の配列

**使用例**:
```opal
nc patches <- OpalUI.VirtualDOM.diff(oldTree, newTree);
```

#### `OpalUI.VirtualDOM.patch(domNode: Any, patches: Array) -> Any`

実際のDOMに差分を適用します。

**パラメータ**:
- `domNode`: 更新するDOM要素
- `patches`: 適用するパッチ操作

**戻り値**: 更新されたDOM要素

**使用例**:
```opal
nc updatedDOM <- OpalUI.VirtualDOM.patch(document.getElementById("app"), patches);
```

#### `OpalUI.VirtualDOM.create(vNode: VirtualNode) -> Any`

仮想DOMノードから実際のDOM要素を作成します。

**パラメータ**:
- `vNode`: 仮想DOMノード

**戻り値**: 実際のDOM要素

**使用例**:
```opal
nc domElement <- OpalUI.VirtualDOM.create(vNode);
```

### State モジュール

#### `OpalUI.State.useState(initialValue: Any) -> Array`

関数コンポーネント内で状態を使用するためのフックを提供します。

**パラメータ**:
- `initialValue`: 状態の初期値

**戻り値**: 現在の状態値と状態更新関数を含む配列

**使用例**:
```opal
nc CounterComponent <- function() -> Any then
    nc state <- OpalUI.State.useState(0);
    nc count <- state[0];
    nc setCount <- state[1];
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("p", null, "カウント: " + count),
        OpalUI.createElement("button", {
            "onClick": function() -> Void then
                setCount(count + 1);
            end
        }, "増加")
    ]);
end;
```

#### `OpalUI.State.useEffect(effect: Function, dependencies: Array = null) -> Void`

副作用を実行するためのフックを提供します。

**パラメータ**:
- `effect`: 実行する副作用関数
- `dependencies`: 依存配列（変更時に副作用を再実行するための値）

**使用例**:
```opal
nc DataFetchingComponent <- function() -> Any then
    nc state <- OpalUI.State.useState(null);
    nc data <- state[0];
    nc setData <- state[1];
    
    OpalUI.State.useEffect(function() -> Function then
        // データ取得
        OpalUI.fetch("/api/data")
            .then(function(response) -> Any then
                return response.json();
            end)
            .then(function(json) -> Void then
                setData(json);
            end);
        
        // クリーンアップ関数
        return function() -> Void then
            // リソースの解放など
        end;
    end, []); // 空の依存配列は、マウント時にのみ実行することを意味します
    
    if (data == null) then
        return OpalUI.createElement("div", null, "読み込み中...");
    end
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("h1", null, data.title),
        OpalUI.createElement("p", null, data.description)
    ]);
end;
```

#### `OpalUI.State.useReducer(reducer: Function, initialState: Any) -> Array`

複雑な状態ロジックを管理するためのフックを提供します。

**パラメータ**:
- `reducer`: 状態更新ロジックを含む関数 `function(state, action) -> newState`
- `initialState`: 状態の初期値

**戻り値**: 現在の状態と状態更新のためのディスパッチ関数を含む配列

**使用例**:
```opal
// リデューサー関数
nc counterReducer <- function(state: Map, action: Map) -> Map then
    if (action.type == "increment") then
        return { "count": state.count + 1 };
    end else if (action.type == "decrement") then
        return { "count": state.count - 1 };
    end else if (action.type == "reset") then
        return { "count": 0 };
    end
    
    return state;
end;

nc CounterWithReducer <- function() -> Any then
    nc state <- OpalUI.State.useReducer(counterReducer, { "count": 0 });
    nc count <- state[0].count;
    nc dispatch <- state[1];
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("p", null, "カウント: " + count),
        OpalUI.createElement("button", {
            "onClick": function() -> Void then
                dispatch({ "type": "increment" });
            end
        }, "増加"),
        OpalUI.createElement("button", {
            "onClick": function() -> Void then
                dispatch({ "type": "decrement" });
            end
        }, "減少"),
        OpalUI.createElement("button", {
            "onClick": function() -> Void then
                dispatch({ "type": "reset" });
            end
        }, "リセット")
    ]);
end;
```

#### `OpalUI.State.createStore(reducer: Function, initialState: Any) -> Map`

グローバル状態管理のためのストアを作成します。

**パラメータ**:
- `reducer`: 状態更新ロジックを含む関数
- `initialState`: 状態の初期値

**戻り値**: ストアオブジェクト（getState、dispatch、subscribeメソッドを含む）

**使用例**:
```opal
// リデューサー関数
nc appReducer <- function(state: Map, action: Map) -> Map then
    if (action.type == "SET_USER") then
        return {
            "user": action.payload,
            "theme": state.theme
        };
    end else if (action.type == "TOGGLE_THEME") then
        return {
            "user": state.user,
            "theme": state.theme == "light" ? "dark" : "light"
        };
    end
    
    return state;
end;

// ストアの作成
nc store <- OpalUI.State.createStore(appReducer, {
    "user": null,
    "theme": "light"
});

// 状態の取得
nc state <- store.getState();
OpalSystemCall.("現在のテーマ: " + state.theme) -> out;

// アクションのディスパッチ
store.dispatch({
    "type": "SET_USER",
    "payload": { "name": "田中", "id": 123 }
});

// 変更の購読
store.subscribe(function() -> Void then
    nc newState <- store.getState();
    OpalSystemCall.("ユーザー名: " + newState.user.name) -> out;
end);
```

### Event モジュール

#### `OpalUI.Event.addListener(element: Any, eventType: String, handler: Function) -> Void`

DOM要素にイベントリスナーを追加します。

**パラメータ**:
- `element`: イベントリスナーを追加するDOM要素
- `eventType`: イベントタイプ（"click"、"change"など）
- `handler`: イベントハンドラ関数

**使用例**:
```opal
OpalUI.Event.addListener(document.getElementById("myButton"), "click", function(event) -> Void then
    OpalSystemCall.("ボタンがクリックされました") -> out;
end);
```

#### `OpalUI.Event.removeListener(element: Any, eventType: String, handler: Function) -> Void`

DOM要素からイベントリスナーを削除します。

**パラメータ**:
- `element`: イベントリスナーを削除するDOM要素
- `eventType`: イベントタイプ
- `handler`: 削除するイベントハンドラ関数

**使用例**:
```opal
OpalUI.Event.removeListener(document.getElementById("myButton"), "click", myHandler);
```

#### `OpalUI.Event.createCustomEvent(name: String, detail: Any = null) -> Any`

カスタムイベントを作成します。

**パラメータ**:
- `name`: カスタムイベント名
- `detail`: イベントに関連付けるデータ

**戻り値**: カスタムイベントオブジェクト

**使用例**:
```opal
nc event <- OpalUI.Event.createCustomEvent("userLoggedIn", {
    "userId": 123,
    "username": "tanaka"
});

document.dispatchEvent(event);
```

#### `OpalUI.Event.EventBus.create() -> Map`

イベントバスを作成します。

**戻り値**: イベントバスオブジェクト（on、off、emitメソッドを含む）

**使用例**:
```opal
nc eventBus <- OpalUI.Event.EventBus.create();

// イベントリスナーの登録
eventBus.on("userUpdated", function(data) -> Void then
    OpalSystemCall.("ユーザー更新: " + data.name) -> out;
end);

// イベントの発行
eventBus.emit("userUpdated", { "name": "鈴木", "id": 456 });

// リスナーの削除
eventBus.off("userUpdated", myHandler);
```

### Styling モジュール

#### `OpalUI.Styling.createStyleSheet(styles: Map) -> Map`

スタイルシートを作成します。

**パラメータ**:
- `styles`: スタイル定義のマップ

**戻り値**: クラス名とスタイルを含むマップ

**使用例**:
```opal
nc styles <- OpalUI.Styling.createStyleSheet({
    "container": {
        "display": "flex",
        "flexDirection": "column",
        "padding": "20px",
        "backgroundColor": "#f5f5f5"
    },
    "title": {
        "fontSize": "24px",
        "fontWeight": "bold",
        "color": "#333",
        "marginBottom": "16px"
    },
    "button": {
        "backgroundColor": "#007bff",
        "color": "white",
        "padding": "8px 16px",
        "border": "none",
        "borderRadius": "4px",
        "cursor": "pointer",
        "transition": "background-color 0.3s"
    },
    "button:hover": {
        "backgroundColor": "#0056b3"
    }
});

// スタイルの使用
nc StyledComponent <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement("div", { "className": styles.container }, [
            OpalUI.createElement("h1", { "className": styles.title }, "スタイル付きコンポーネント"),
            OpalUI.createElement("button", { "className": styles.button }, "クリック")
        ]);
    end
});
```

#### `OpalUI.Styling.createTheme(theme: Map) -> Map`

テーマを作成します。

**パラメータ**:
- `theme`: テーマ定義のマップ

**戻り値**: テーマオブジェクト

**使用例**:
```opal
nc theme <- OpalUI.Styling.createTheme({
    "palette": {
        "primary": "#007bff",
        "secondary": "#6c757d",
        "success": "#28a745",
        "error": "#dc3545",
        "warning": "#ffc107",
        "info": "#17a2b8",
        "background": "#ffffff",
        "text": "#212529"
    },
    "typography": {
        "fontFamily": "'Helvetica Neue', Arial, sans-serif",
        "fontSize": "16px",
        "h1": {
            "fontSize": "2.5rem",
            "fontWeight": "500"
        },
        "h2": {
            "fontSize": "2rem",
            "fontWeight": "500"
        },
        "body": {
            "fontSize": "1rem",
            "lineHeight": "1.5"
        }
    },
    "spacing": {
        "unit": "8px",
        "small": "8px",
        "medium": "16px",
        "large": "24px"
    },
    "breakpoints": {
        "small": "576px",
        "medium": "768px",
        "large": "992px",
        "xlarge": "1200px"
    }
});

// テーマの使用
nc ThemeProvider <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement(OpalUI.Styling.ThemeContext.Provider, {
            "value": theme
        }, this.props.children);
    end
});
```

#### `OpalUI.Styling.useTheme() -> Map`

現在のテーマを取得するためのフックを提供します。

**戻り値**: 現在のテーマオブジェクト

**使用例**:
```opal
nc ThemedButton <- function() -> Any then
    nc theme <- OpalUI.Styling.useTheme();
    
    return OpalUI.createElement("button", {
        "style": {
            "backgroundColor": theme.palette.primary,
            "color": "white",
            "padding": theme.spacing.medium,
            "border": "none",
            "borderRadius": "4px",
            "fontFamily": theme.typography.fontFamily,
            "fontSize": theme.typography.body.fontSize
        }
    }, "テーマ付きボタン");
end;
```

#### `OpalUI.Styling.createResponsiveStyles(styles: Map) -> Function`

レスポンシブスタイルを作成します。

**パラメータ**:
- `styles`: ブレークポイントごとのスタイル定義

**戻り値**: 現在のビューポートに基づいてスタイルを返す関数

**使用例**:
```opal
nc responsiveStyles <- OpalUI.Styling.createResponsiveStyles({
    "base": {
        "display": "flex",
        "flexDirection": "column",
        "padding": "10px"
    },
    "small": {
        "flexDirection": "row",
        "padding": "15px"
    },
    "medium": {
        "padding": "20px",
        "maxWidth": "800px",
        "margin": "0 auto"
    },
    "large": {
        "padding": "30px",
        "maxWidth": "1200px"
    }
});

nc ResponsiveComponent <- OpalUI.Component.create({
    "render": function() -> Any then
        nc styles <- responsiveStyles();
        
        return OpalUI.createElement("div", { "style": styles }, [
            OpalUI.createElement("h1", null, "レスポンシブコンポーネント"),
            OpalUI.createElement("p", null, "ビューポートサイズに応じてスタイルが変わります")
        ]);
    end
});
```

### Animation モジュール

#### `OpalUI.Animation.createAnimation(keyframes: Array, options: Map = {}) -> Map`

キーフレームアニメーションを作成します。

**パラメータ**:
- `keyframes`: アニメーションのキーフレーム
- `options`: アニメーションオプション（持続時間、イージング関数など）

**戻り値**: アニメーションオブジェクト

**使用例**:
```opal
nc fadeInAnimation <- OpalUI.Animation.createAnimation([
    { "opacity": 0 },
    { "opacity": 1 }
], {
    "duration": 500,
    "easing": "ease-in-out",
    "fillMode": "forwards"
});

nc AnimatedComponent <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement("div", {
            "style": {
                "animation": fadeInAnimation
            }
        }, "フェードインするテキスト");
    end
});
```

#### `OpalUI.Animation.transition(element: Any, properties: Map, options: Map = {}) -> Map`

要素にトランジションを適用します。

**パラメータ**:
- `element`: トランジションを適用するDOM要素
- `properties`: 変更するプロパティとその値
- `options`: トランジションオプション（持続時間、イージング関数など）

**戻り値**: トランジションオブジェクト（cancel、finishメソッドを含む）

**使用例**:
```opal
nc element <- document.getElementById("myElement");
nc transition <- OpalUI.Animation.transition(element, {
    "opacity": 0,
    "transform": "translateY(20px)"
}, {
    "duration": 300,
    "easing": "ease-out"
});

// トランジションのキャンセル
// transition.cancel();

// トランジションの即時完了
// transition.finish();
```

#### `OpalUI.Animation.useAnimation(animation: Map, dependencies: Array = []) -> Map`

アニメーションを使用するためのフックを提供します。

**パラメータ**:
- `animation`: 使用するアニメーション
- `dependencies`: アニメーションを再実行するための依存配列

**戻り値**: アニメーション制御オブジェクト（play、pause、resetメソッドを含む）

**使用例**:
```opal
nc AnimatedCounter <- function(props) -> Any then
    nc animation <- OpalUI.Animation.useAnimation({
        "from": { "count": 0 },
        "to": { "count": props.target },
        "duration": 1000,
        "easing": "ease-out"
    }, [props.target]);
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("h2", null, "カウンター: " + Math.round(animation.values.count)),
        OpalUI.createElement("button", {
            "onClick": animation.play
        }, "再生"),
        OpalUI.createElement("button", {
            "onClick": animation.pause
        }, "一時停止"),
        OpalUI.createElement("button", {
            "onClick": animation.reset
        }, "リセット")
    ]);
end;
```

#### `OpalUI.Animation.createTimeline(animations: Array, options: Map = {}) -> Map`

複数のアニメーションを含むタイムラインを作成します。

**パラメータ**:
- `animations`: タイムラインに含めるアニメーションの配列
- `options`: タイムラインオプション

**戻り値**: タイムラインオブジェクト（play、pause、seekメソッドを含む）

**使用例**:
```opal
nc timeline <- OpalUI.Animation.createTimeline([
    {
        "animation": fadeInAnimation,
        "target": document.getElementById("element1"),
        "offset": 0
    },
    {
        "animation": slideInAnimation,
        "target": document.getElementById("element2"),
        "offset": 0.5 // 50%の時点で開始
    },
    {
        "animation": scaleAnimation,
        "target": document.getElementById("element3"),
        "offset": 0.8 // 80%の時点で開始
    }
], {
    "duration": 2000,
    "easing": "ease-in-out"
});

// タイムラインの再生
timeline.play();

// 特定の時点にシーク
// timeline.seek(0.5); // 50%の位置にシーク
```

### Router モジュール

#### `OpalUI.Router.createRouter(routes: Array, options: Map = {}) -> Map`

アプリケーションルーターを作成します。

**パラメータ**:
- `routes`: ルート定義の配列
- `options`: ルーターオプション（モード、ベースパスなど）

**戻り値**: ルーターオブジェクト

**使用例**:
```opal
nc router <- OpalUI.Router.createRouter([
    {
        "path": "/",
        "component": HomeComponent
    },
    {
        "path": "/about",
        "component": AboutComponent
    },
    {
        "path": "/users/:id",
        "component": UserComponent
    },
    {
        "path": "*",
        "component": NotFoundComponent
    }
], {
    "mode": "history", // "history" または "hash"
    "basePath": ""
});

// ルーターの初期化
router.init();
```

#### `OpalUI.Router.Link(props: Map) -> Component`

ルーター対応のリンクコンポーネントを作成します。

**パラメータ**:
- `props`: リンクプロパティ（to、className、styleなど）

**戻り値**: リンクコンポーネント

**使用例**:
```opal
nc NavBar <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement("nav", null, [
            OpalUI.createElement(OpalUI.Router.Link, {
                "to": "/",
                "className": "nav-link"
            }, "ホーム"),
            OpalUI.createElement(OpalUI.Router.Link, {
                "to": "/about",
                "className": "nav-link"
            }, "概要"),
            OpalUI.createElement(OpalUI.Router.Link, {
                "to": "/users/123",
                "className": "nav-link"
            }, "ユーザープロフィール")
        ]);
    end
});
```

#### `OpalUI.Router.Route(props: Map) -> Component`

ルートコンポーネントを作成します。

**パラメータ**:
- `props`: ルートプロパティ（path、component、exactなど）

**戻り値**: ルートコンポーネント

**使用例**:
```opal
nc App <- OpalUI.Component.create({
    "render": function() -> Any then
        return OpalUI.createElement("div", { "className": "app" }, [
            OpalUI.createElement(NavBar, null, null),
            OpalUI.createElement("div", { "className": "content" }, [
                OpalUI.createElement(OpalUI.Router.Route, {
                    "path": "/",
                    "component": HomeComponent,
                    "exact": true
                }, null),
                OpalUI.createElement(OpalUI.Router.Route, {
                    "path": "/about",
                    "component": AboutComponent
                }, null),
                OpalUI.createElement(OpalUI.Router.Route, {
                    "path": "/users/:id",
                    "component": UserComponent
                }, null),
                OpalUI.createElement(OpalUI.Router.Route, {
                    "path": "*",
                    "component": NotFoundComponent
                }, null)
            ])
        ]);
    end
});
```

#### `OpalUI.Router.useParams() -> Map`

現在のルートパラメータを取得するためのフックを提供します。

**戻り値**: ルートパラメータのマップ

**使用例**:
```opal
nc UserComponent <- function() -> Any then
    nc params <- OpalUI.Router.useParams();
    nc userId <- params.id;
    
    nc state <- OpalUI.State.useState(null);
    nc user <- state[0];
    nc setUser <- state[1];
    
    OpalUI.State.useEffect(function() -> Function then
        // ユーザーデータの取得
        OpalUI.fetch("/api/users/" + userId)
            .then(function(response) -> Any then
                return response.json();
            end)
            .then(function(data) -> Void then
                setUser(data);
            end);
        
        return null;
    end, [userId]);
    
    if (user == null) then
        return OpalUI.createElement("div", null, "読み込み中...");
    end
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("h1", null, "ユーザープロフィール"),
        OpalUI.createElement("p", null, "ID: " + userId),
        OpalUI.createElement("p", null, "名前: " + user.name),
        OpalUI.createElement("p", null, "メール: " + user.email)
    ]);
end;
```

#### `OpalUI.Router.useNavigate() -> Function`

プログラムによるナビゲーションのためのフックを提供します。

**戻り値**: ナビゲーション関数

**使用例**:
```opal
nc LoginComponent <- function() -> Any then
    nc navigate <- OpalUI.Router.useNavigate();
    
    nc handleLogin <- function() -> Void then
        // ログイン処理
        // ...
        
        // ログイン成功後にリダイレクト
        navigate("/dashboard");
    end;
    
    return OpalUI.createElement("div", null, [
        OpalUI.createElement("h1", null, "ログイン"),
        // フォーム要素
        OpalUI.createElement("button", {
            "onClick": handleLogin
        }, "ログイン")
    ]);
end;
```

## 使用例

### 基本的なコンポーネントの例

```opal
module BasicComponentExample then
    function first() -> Void then
        // OpalUIを初期化
        OpalUI.initialize();
        
        // シンプルなカウンターコンポーネント
        nc Counter <- OpalUI.Component.create({
            "initialState": {
                "count": 0
            },
            "render": function() -> Any then
                return OpalUI.createElement("div", { "className": "counter" }, [
                    OpalUI.createElement("h2", null, "カウンター"),
                    OpalUI.createElement("p", null, "現在のカウント: " + this.state.count),
                    OpalUI.createElement("button", {
                        "onClick": this.increment
                    }, "増加"),
                    OpalUI.createElement("button", {
                        "onClick": this.decrement
                    }, "減少"),
                    OpalUI.createElement("button", {
                        "onClick": this.reset
                    }, "リセット")
                ]);
            end,
            "increment": function() -> Void then
                this.setState({
                    "count": this.state.count + 1
                });
            end,
            "decrement": function() -> Void then
                this.setState({
                    "count": this.state.count - 1
                });
            end,
            "reset": function() -> Void then
                this.setState({
                    "count": 0
                });
            end
        });
        
        // アプリケーションコンポーネント
        nc App <- OpalUI.Component.create({
            "render": function() -> Any then
                return OpalUI.createElement("div", { "className": "app" }, [
                    OpalUI.createElement("h1", null, "OpalUI デモ"),
                    OpalUI.createElement(Counter, null, null)
                ]);
            end
        });
        
        // アプリケーションのレンダリング
        OpalUI.render(App, "#root");
    end
end
```

### フックを使用した関数コンポーネントの例

```opal
module HooksExample then
    function first() -> Void then
        // OpalUIを初期化
        OpalUI.initialize();
        
        // useState と useEffect を使用した関数コンポーネント
        nc TodoApp <- function() -> Any then
            // 状態の定義
            nc todoState <- OpalUI.State.useState("");
            nc todoInput <- todoState[0];
            nc setTodoInput <- todoState[1];
            
            nc todosState <- OpalUI.State.useState([]);
            nc todos <- todosState[0];
            nc setTodos <- todosState[1];
            
            // 入力変更ハンドラ
            nc handleInputChange <- function(event) -> Void then
                setTodoInput(event.target.value);
            end;
            
            // Todo追加ハンドラ
            nc handleAddTodo <- function() -> Void then
                if (todoInput.trim() == "") then
                    return;
                end
                
                setTodos([...todos, {
                    "id": Date.now(),
                    "text": todoInput,
                    "completed": false
                }]);
                setTodoInput("");
            end;
            
            // Todo完了トグルハンドラ
            nc handleToggleTodo <- function(id) -> Void then
                nc updatedTodos <- todos.map(function(todo) -> Map then
                    if (todo.id == id) then
                        return {
                            "id": todo.id,
                            "text": todo.text,
                            "completed": !todo.completed
                        };
                    end
                    return todo;
                end);
                
                setTodos(updatedTodos);
            end;
            
            // Todo削除ハンドラ
            nc handleDeleteTodo <- function(id) -> Void then
                nc updatedTodos <- todos.filter(function(todo) -> Boolean then
                    return todo.id != id;
                end);
                
                setTodos(updatedTodos);
            end;
            
            // 副作用: ローカルストレージからTodosを読み込む
            OpalUI.State.useEffect(function() -> Function then
                nc storedTodos <- localStorage.getItem("todos");
                if (storedTodos) then
                    setTodos(JSON.parse(storedTodos));
                end
                
                return null;
            end, []);
            
            // 副作用: Todosの変更をローカルストレージに保存
            OpalUI.State.useEffect(function() -> Function then
                localStorage.setItem("todos", JSON.stringify(todos));
                
                return null;
            end, [todos]);
            
            // UIのレンダリング
            return OpalUI.createElement("div", { "className": "todo-app" }, [
                OpalUI.createElement("h1", null, "Todoリスト"),
                
                // 入力フォーム
                OpalUI.createElement("div", { "className": "todo-form" }, [
                    OpalUI.createElement("input", {
                        "type": "text",
                        "value": todoInput,
                        "onChange": handleInputChange,
                        "placeholder": "新しいタスクを入力..."
                    }, null),
                    OpalUI.createElement("button", {
                        "onClick": handleAddTodo
                    }, "追加")
                ]),
                
                // Todoリスト
                OpalUI.createElement("ul", { "className": "todo-list" }, 
                    todos.map(function(todo) -> Any then
                        return OpalUI.createElement("li", {
                            "key": todo.id,
                            "className": todo.completed ? "completed" : ""
                        }, [
                            OpalUI.createElement("span", {
                                "onClick": function() -> Void then
                                    handleToggleTodo(todo.id);
                                end
                            }, todo.text),
                            OpalUI.createElement("button", {
                                "onClick": function() -> Void then
                                    handleDeleteTodo(todo.id);
                                end
                            }, "削除")
                        ]);
                    end)
                ),
                
                // 統計情報
                OpalUI.createElement("div", { "className": "todo-stats" }, [
                    OpalUI.createElement("p", null, "合計: " + todos.length + " タスク"),
                    OpalUI.createElement("p", null, "完了: " + 
                        todos.filter(function(todo) -> Boolean then
                            return todo.completed;
                        end).length + 
                        " タスク"
                    )
                ])
            ]);
        end;
        
        // アプリケーションのレンダリング
        OpalUI.render(TodoApp, "#root");
    end
end
```

### スタイリングとアニメーションの例

```opal
module StylingAndAnimationExample then
    function first() -> Void then
        // OpalUIを初期化
        OpalUI.initialize();
        
        // スタイルの定義
        nc styles <- OpalUI.Styling.createStyleSheet({
            "container": {
                "maxWidth": "800px",
                "margin": "0 auto",
                "padding": "20px",
                "fontFamily": "'Helvetica Neue', Arial, sans-serif"
            },
            "header": {
                "textAlign": "center",
                "marginBottom": "30px"
            },
            "title": {
                "fontSize": "36px",
                "color": "#333",
                "marginBottom": "10px"
            },
            "subtitle": {
                "fontSize": "18px",
                "color": "#666"
            },
            "card": {
                "backgroundColor": "white",
                "borderRadius": "8px",
                "boxShadow": "0 4px 8px rgba(0, 0, 0, 0.1)",
                "padding": "20px",
                "marginBottom": "20px",
                "transition": "transform 0.3s, box-shadow 0.3s"
            },
            "card:hover": {
                "transform": "translateY(-5px)",
                "boxShadow": "0 8px 16px rgba(0, 0, 0, 0.2)"
            },
            "button": {
                "backgroundColor": "#007bff",
                "color": "white",
                "border": "none",
                "borderRadius": "4px",
                "padding": "10px 20px",
                "fontSize": "16px",
                "cursor": "pointer",
                "transition": "background-color 0.3s"
            },
            "button:hover": {
                "backgroundColor": "#0056b3"
            }
        });
        
        // アニメーションの定義
        nc fadeInAnimation <- OpalUI.Animation.createAnimation([
            { "opacity": 0, "transform": "translateY(20px)" },
            { "opacity": 1, "transform": "translateY(0)" }
        ], {
            "duration": 500,
            "easing": "ease-out",
            "fillMode": "forwards"
        });
        
        // カードコンポーネント
        nc Card <- function(props) -> Any then
            nc animation <- OpalUI.Animation.useAnimation(fadeInAnimation, []);
            
            OpalUI.State.useEffect(function() -> Function then
                animation.play();
                return null;
            end, []);
            
            return OpalUI.createElement("div", {
                "className": styles.card,
                "style": {
                    "animation": animation.current
                }
            }, [
                OpalUI.createElement("h2", null, props.title),
                OpalUI.createElement("p", null, props.content),
                OpalUI.createElement("button", {
                    "className": styles.button,
                    "onClick": props.onClick
                }, props.buttonText || "詳細を見る")
            ]);
        end;
        
        // アプリケーションコンポーネント
        nc App <- function() -> Any then
            nc cards <- [
                {
                    "id": 1,
                    "title": "カード 1",
                    "content": "これはカード1の内容です。スタイリングとアニメーションのデモを示しています。"
                },
                {
                    "id": 2,
                    "title": "カード 2",
                    "content": "これはカード2の内容です。各カードはフェードインアニメーションで表示されます。"
                },
                {
                    "id": 3,
                    "title": "カード 3",
                    "content": "これはカード3の内容です。ホバー時にカードが浮き上がるエフェクトがあります。"
                }
            ];
            
            nc handleCardClick <- function(id) -> Void then
                OpalSystemCall.("カード " + id + " がクリックされました") -> out;
            end;
            
            return OpalUI.createElement("div", { "className": styles.container }, [
                OpalUI.createElement("header", { "className": styles.header }, [
                    OpalUI.createElement("h1", { "className": styles.title }, "スタイリングとアニメーションのデモ"),
                    OpalUI.createElement("p", { "className": styles.subtitle }, "OpalUIを使用したスタイリングとアニメーションの例")
                ]),
                
                cards.map(function(card) -> Any then
                    return OpalUI.createElement(Card, {
                        "key": card.id,
                        "title": card.title,
                        "content": card.content,
                        "onClick": function() -> Void then
                            handleCardClick(card.id);
                        end
                    }, null);
                end)
            ]);
        end;
        
        // アプリケーションのレンダリング
        OpalUI.render(App, "#root");
    end
end
```

### ルーティングの例

```opal
module RoutingExample then
    function first() -> Void then
        // OpalUIを初期化
        OpalUI.initialize();
        
        // ホームページコンポーネント
        nc HomePage <- function() -> Any then
            return OpalUI.createElement("div", null, [
                OpalUI.createElement("h1", null, "ホームページ"),
                OpalUI.createElement("p", null, "これはOpalUIルーターを使用したSPAのホームページです。")
            ]);
        end;
        
        // 概要ページコンポーネント
        nc AboutPage <- function() -> Any then
            return OpalUI.createElement("div", null, [
                OpalUI.createElement("h1", null, "概要ページ"),
                OpalUI.createElement("p", null, "OpalUIは、Opal言語用のモダンなUIライブラリです。"),
                OpalUI.createElement("p", null, "React風のコンポーネントベースのアーキテクチャを採用しています。")
            ]);
        end;
        
        // ユーザーページコンポーネント
        nc UserPage <- function() -> Any then
            nc params <- OpalUI.Router.useParams();
            nc userId <- params.id;
            
            nc state <- OpalUI.State.useState({
                "loading": true,
                "user": null,
                "error": null
            });
            nc loading <- state[0].loading;
            nc user <- state[0].user;
            nc error <- state[0].error;
            nc setState <- state[1];
            
            OpalUI.State.useEffect(function() -> Function then
                // ユーザーデータの取得をシミュレート
                setTimeout(function() -> Void then
                    if (userId == "123") then
                        setState({
                            "loading": false,
                            "user": {
                                "id": 123,
                                "name": "田中太郎",
                                "email": "tanaka@example.com",
                                "role": "管理者"
                            },
                            "error": null
                        });
                    end else if (userId == "456") then
                        setState({
                            "loading": false,
                            "user": {
                                "id": 456,
                                "name": "佐藤花子",
                                "email": "sato@example.com",
                                "role": "ユーザー"
                            },
                            "error": null
                        });
                    end else then
                        setState({
                            "loading": false,
                            "user": null,
                            "error": "ユーザーが見つかりません"
                        });
                    end
                end, 1000);
                
                return null;
            end, [userId]);
            
            if (loading) then
                return OpalUI.createElement("div", null, "読み込み中...");
            end
            
            if (error) then
                return OpalUI.createElement("div", null, [
                    OpalUI.createElement("h1", null, "エラー"),
                    OpalUI.createElement("p", null, error)
                ]);
            end
            
            return OpalUI.createElement("div", null, [
                OpalUI.createElement("h1", null, "ユーザープロフィール"),
                OpalUI.createElement("p", null, "ID: " + user.id),
                OpalUI.createElement("p", null, "名前: " + user.name),
                OpalUI.createElement("p", null, "メール: " + user.email),
                OpalUI.createElement("p", null, "役割: " + user.role)
            ]);
        end;
        
        // 404ページコンポーネント
        nc NotFoundPage <- function() -> Any then
            return OpalUI.createElement("div", null, [
                OpalUI.createElement("h1", null, "404 - ページが見つかりません"),
                OpalUI.createElement("p", null, "お探しのページは存在しないか、移動した可能性があります。")
            ]);
        end;
        
        // ナビゲーションコンポーネント
        nc Navigation <- function() -> Any then
            nc styles <- {
                "nav": {
                    "backgroundColor": "#333",
                    "padding": "10px"
                },
                "navList": {
                    "display": "flex",
                    "listStyle": "none",
                    "margin": 0,
                    "padding": 0
                },
                "navItem": {
                    "marginRight": "20px"
                },
                "navLink": {
                    "color": "white",
                    "textDecoration": "none",
                    "padding": "5px 10px"
                },
                "activeLink": {
                    "backgroundColor": "#555",
                    "borderRadius": "4px"
                }
            };
            
            nc currentPath <- window.location.pathname;
            
            nc isActive <- function(path) -> Boolean then
                if (path == "/") then
                    return currentPath == path;
                end
                return currentPath.startsWith(path);
            end;
            
            return OpalUI.createElement("nav", { "style": styles.nav }, 
                OpalUI.createElement("ul", { "style": styles.navList }, [
                    OpalUI.createElement("li", { "style": styles.navItem }, 
                        OpalUI.createElement(OpalUI.Router.Link, {
                            "to": "/",
                            "style": {
                                ...styles.navLink,
                                ...(isActive("/") ? styles.activeLink : {})
                            }
                        }, "ホーム")
                    ),
                    OpalUI.createElement("li", { "style": styles.navItem }, 
                        OpalUI.createElement(OpalUI.Router.Link, {
                            "to": "/about",
                            "style": {
                                ...styles.navLink,
                                ...(isActive("/about") ? styles.activeLink : {})
                            }
                        }, "概要")
                    ),
                    OpalUI.createElement("li", { "style": styles.navItem }, 
                        OpalUI.createElement(OpalUI.Router.Link, {
                            "to": "/users/123",
                            "style": {
                                ...styles.navLink,
                                ...(isActive("/users") ? styles.activeLink : {})
                            }
                        }, "ユーザー")
                    )
                ])
            );
        end;
        
        // アプリケーションコンポーネント
        nc App <- function() -> Any then
            return OpalUI.createElement("div", { "className": "app" }, [
                OpalUI.createElement(Navigation, null, null),
                OpalUI.createElement("div", { "style": { "padding": "20px" } }, [
                    OpalUI.createElement(OpalUI.Router.Route, {
                        "path": "/",
                        "component": HomePage,
                        "exact": true
                    }, null),
                    OpalUI.createElement(OpalUI.Router.Route, {
                        "path": "/about",
                        "component": AboutPage
                    }, null),
                    OpalUI.createElement(OpalUI.Router.Route, {
                        "path": "/users/:id",
                        "component": UserPage
                    }, null),
                    OpalUI.createElement(OpalUI.Router.Route, {
                        "path": "*",
                        "component": NotFoundPage
                    }, null)
                ])
            ]);
        end;
        
        // ルーターの作成
        nc router <- OpalUI.Router.createRouter([
            {
                "path": "/",
                "component": HomePage,
                "exact": true
            },
            {
                "path": "/about",
                "component": AboutPage
            },
            {
                "path": "/users/:id",
                "component": UserPage
            },
            {
                "path": "*",
                "component": NotFoundPage
            }
        ], {
            "mode": "history"
        });
        
        // ルーターの初期化とアプリケーションのレンダリング
        router.init();
        OpalUI.render(App, "#root");
    end
end
```

## ライセンス

OpalUIライブラリはMITライセンスの下で提供されています。
