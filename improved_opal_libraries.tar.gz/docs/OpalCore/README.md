# OpalCore ライブラリドキュメント v1.1.0

## 概要

OpalCoreは、Opal言語の基本機能と共通ユーティリティを提供するライブラリです。このライブラリは、コレクション操作、テキスト処理、日付時間処理、ファイルシステム操作、並行処理、ネットワーク通信、関数型プログラミングユーティリティなど、アプリケーション開発に必要な基本的な機能を提供します。

バージョン1.1.0では、型チェック関数の完全実装、イミュータブルデータ構造、Promise APIの追加など、多くの機能強化が行われました。

## モジュール構成

OpalCoreライブラリは以下のサブモジュールで構成されています：

1. **Collections** - 拡張配列、マップ、セットなどのコレクション操作
2. **Text** - 文字列操作、検索、置換、分割、結合など
3. **DateTime** - 日付と時間の処理、期間計算など
4. **FileSystem** - ファイルとディレクトリの操作
5. **OVM** - Opal Virtual Machine（バイトコードインタプリタとコンパイラ）
6. **Concurrency** - 並行処理、Future、Promise、Mutexなど
7. **Network** - HTTP、WebSocket、TCP、UDP通信
8. **Functional** - 関数型プログラミングユーティリティ

## インストール方法

OpalCoreライブラリをプロジェクトに追加するには、以下の手順に従ってください：

1. `OpalCore`ディレクトリとそのサブディレクトリをプロジェクトにコピーします
2. Opalプログラムの先頭で`OpalCore`モジュールをインポートします

```opal
// OpalCoreモジュールをインポート
import OpalCore;

module MyApp then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // ここにコードを記述
        OpalSystemCall.("Hello, OpalCore!") -> out;
    end
end
```

## 新機能（v1.1.0）

### 型チェック関数の完全実装

型チェック関数が完全に実装され、より堅牢な型チェックが可能になりました。

```opal
// 型チェック関数の使用例
if OpalCore.is_integer(value) then
    // 整数の処理
end

if OpalCore.is_string(value) then
    // 文字列の処理
end

// 型を文字列で取得
nc type <- OpalCore.typeof(value); // "Integer", "String", "Array" など
```

### イミュータブルデータ構造

不変（イミュータブル）なデータ構造が追加され、関数型プログラミングスタイルのコードが書きやすくなりました。

```opal
// イミュータブルマップの使用例
nc map <- OpalCore.ImmutableMap.from({
    "name": "Opal",
    "version": "1.1.0"
});

// 元のマップは変更されず、新しいマップが返される
nc new_map <- map.set("author", "OpalTeam");

OpalSystemCall.(map.get("name")) -> out; // "Opal"
OpalSystemCall.(new_map.get("author")) -> out; // "OpalTeam"

// イミュータブル配列の使用例
nc array <- OpalCore.ImmutableArray.from([1, 2, 3]);
nc new_array <- array.push(4).push(5);

OpalSystemCall.(array.length()) -> out; // 3
OpalSystemCall.(new_array.length()) -> out; // 5
```

### Promise API

非同期処理を扱うためのPromise APIが追加されました。

```opal
// Promise APIの使用例
nc promise <- new OpalCore.Promise();

// 非同期処理をシミュレート
OpalCore.Concurrency.setTimeout(function() -> Void then
    promise._resolve("成功!");
end, 1000);

// 結果の処理
promise.then(function(result: String) -> Void then
    OpalSystemCall.(result) -> out; // "成功!"
end).catch(function(error: Any) -> Void then
    OpalSystemCall.("エラー: " + error) -> out;
end);

// Promise.all の使用例
nc promises <- [
    OpalCore.Promise.resolve(1),
    OpalCore.Promise.resolve(2),
    OpalCore.Promise.resolve(3)
];

OpalCore.Promise.all(promises).then(function(results: Array) -> Void then
    OpalSystemCall.(results) -> out; // [1, 2, 3]
end);
```

### オプション型

値の存在/不在を安全に扱うためのオプション型が追加されました。

```opal
// オプション型の使用例
function find_user(id: String) -> OpalCore.Option then
    if id == "1" then
        return OpalCore.Option.some({ "id": "1", "name": "Opal" });
    end
    
    return OpalCore.Option.none();
end

nc user_option <- find_user("1");

if user_option.is_some() then
    nc user <- user_option.get_value();
    OpalSystemCall.("ユーザー名: " + user.name) -> out;
end

// メソッドチェーンの使用例
find_user("2")
    .map(function(user: Map) -> String then
        return user.name;
    end)
    .or_else("不明なユーザー");
```

### 拡張されたエラー処理

エラー処理機能が強化され、より詳細なエラー情報が利用可能になりました。

```opal
// 型付きエラーの使用例
try then
    throw new OpalCore.TypeError("無効な型です");
catch e then
    OpalSystemCall.(e.get_code()) -> out; // "TypeError"
    OpalSystemCall.(e.get_message()) -> out; // "無効な型です"
    OpalSystemCall.(e.get_stack()) -> out; // スタックトレース
end

// Result型の拡張メソッドの使用例
nc result <- OpalCore.Result.success(42);

nc mapped <- result
    .map(function(value: Integer) -> Integer then
        return value * 2;
    end)
    .and_then(function(value: Integer) -> OpalCore.Result then
        return OpalCore.Result.success(value + 1);
    end);

OpalSystemCall.(mapped.get_value()) -> out; // 85
```

### 数学ユーティリティ

基本的な数学関数を提供する`Math`クラスが追加されました。

```opal
// 数学ユーティリティの使用例
nc pi <- OpalCore.Math.PI;
nc e <- OpalCore.Math.E;

nc power <- OpalCore.Math.pow(2, 8); // 256
nc log_value <- OpalCore.Math.log(10); // 自然対数
nc exp_value <- OpalCore.Math.exp(2); // e^2

nc rounded <- OpalCore.Math.round(3.7); // 4
nc floor <- OpalCore.Math.floor(3.7); // 3
nc ceil <- OpalCore.Math.ceil(3.2); // 4
```

## API リファレンス

### コアモジュール

#### `OpalCore.initialize() -> Boolean`

OpalCoreライブラリを初期化します。

**戻り値**: 初期化が成功した場合は`true`、すでに初期化されている場合は`false`

**使用例**:
```opal
OpalCore.initialize();
```

#### `OpalCore.isInitialized() -> Boolean`

OpalCoreライブラリが初期化されているかどうかを確認します。

**戻り値**: 初期化されている場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if (!OpalCore.isInitialized()) then
    OpalCore.initialize();
end
```

#### `OpalCore.VERSION -> String`

OpalCoreライブラリのバージョン情報を取得します。

**戻り値**: バージョン文字列（例: "1.1.0"）

**使用例**:
```opal
OpalSystemCall.("OpalCore version: " + OpalCore.VERSION) -> out;
```

### 型チェック関数

#### `OpalCore.is_integer(value: Any) -> Boolean`

値が整数型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 整数型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_integer(42) then
    // 整数の処理
end
```

#### `OpalCore.is_float(value: Any) -> Boolean`

値が浮動小数点型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 浮動小数点型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_float(3.14) then
    // 浮動小数点数の処理
end
```

#### `OpalCore.is_string(value: Any) -> Boolean`

値が文字列型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 文字列型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_string("hello") then
    // 文字列の処理
end
```

#### `OpalCore.is_array(value: Any) -> Boolean`

値が配列型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 配列型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_array([1, 2, 3]) then
    // 配列の処理
end
```

#### `OpalCore.is_map(value: Any) -> Boolean`

値がマップ型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: マップ型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_map({a: 1, b: 2}) then
    // マップの処理
end
```

#### `OpalCore.is_function(value: Any) -> Boolean`

値が関数型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 関数型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_function(function() -> Void then end) then
    // 関数の処理
end
```

#### `OpalCore.is_boolean(value: Any) -> Boolean`

値が真偽値型かどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: 真偽値型の場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_boolean(true) then
    // 真偽値の処理
end
```

#### `OpalCore.is_null(value: Any) -> Boolean`

値がnullかどうかをチェックします。

**パラメータ**:
- `value`: チェックする値

**戻り値**: nullの場合は`true`、そうでない場合は`false`

**使用例**:
```opal
if OpalCore.is_null(value) then
    // nullの処理
end
```

#### `OpalCore.typeof(value: Any) -> String`

値の型を文字列で返します。

**パラメータ**:
- `value`: 型を取得する値

**戻り値**: 型を表す文字列（"Integer", "Float", "String", "Boolean", "Array", "Map", "Function", "Null", "Unknown"など）

**使用例**:
```opal
nc type <- OpalCore.typeof(value);
OpalSystemCall.("値の型: " + type) -> out;
```

### 変換関数

#### `OpalCore.to_string(value: Any) -> String`

値を文字列に変換します。

**パラメータ**:
- `value`: 変換する値

**戻り値**: 文字列表現

**使用例**:
```opal
nc str <- OpalCore.to_string([1, 2, 3]);
OpalSystemCall.(str) -> out; // "[1, 2, 3]"
```

#### `OpalCore.parse_int(str: String) -> Integer`

文字列を整数に変換します。

**パラメータ**:
- `str`: 変換する文字列

**戻り値**: 整数値

**使用例**:
```opal
nc num <- OpalCore.parse_int("42");
OpalSystemCall.(num) -> out; // 42
```

#### `OpalCore.parse_float(str: String) -> Float`

文字列を浮動小数点数に変換します。

**パラメータ**:
- `str`: 変換する文字列

**戻り値**: 浮動小数点数値

**使用例**:
```opal
nc num <- OpalCore.parse_float("3.14");
OpalSystemCall.(num) -> out; // 3.14
```

### 数学ユーティリティ

#### `OpalCore.Math.PI -> Float`

円周率の値を取得します。

**戻り値**: 円周率（π）の値

**使用例**:
```opal
nc area <- OpalCore.Math.PI * radius * radius;
```

#### `OpalCore.Math.E -> Float`

自然対数の底（ネイピア数）の値を取得します。

**戻り値**: 自然対数の底（e）の値

**使用例**:
```opal
nc value <- OpalCore.Math.pow(OpalCore.Math.E, x);
```

#### `OpalCore.Math.pow(base: Number, exponent: Number) -> Number`

べき乗を計算します。

**パラメータ**:
- `base`: 底
- `exponent`: 指数

**戻り値**: べき乗の結果

**使用例**:
```opal
nc squared <- OpalCore.Math.pow(2, 3);
// 8
```

#### `OpalCore.Math.exp(x: Number) -> Number`

指数関数（e^x）を計算します。

**パラメータ**:
- `x`: 指数

**戻り値**: e^x

**使用例**:
```opal
nc result <- OpalCore.Math.exp(2);
// e^2 ≈ 7.389
```

#### `OpalCore.Math.log(x: Number) -> Number`

自然対数（底eの対数）を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 自然対数

**使用例**:
```opal
nc result <- OpalCore.Math.log(10);
// ln(10) ≈ 2.303
```

#### `OpalCore.Math.abs(x: Number) -> Number`

絶対値を計算します。

**パラメータ**:
- `x`: 数値

**戻り値**: 絶対値

**使用例**:
```opal
nc absValue <- OpalCore.Math.abs(-5);
// 5
```

#### `OpalCore.Math.round(x: Number) -> Integer`

数値を最も近い整数に丸めます。

**パラメータ**:
- `x`: 数値

**戻り値**: 丸められた整数

**使用例**:
```opal
nc rounded <- OpalCore.Math.round(3.7);
// 4
```

#### `OpalCore.Math.floor(x: Number) -> Integer`

数値を切り捨てます。

**パラメータ**:
- `x`: 数値

**戻り値**: 切り捨てられた整数

**使用例**:
```opal
nc floored <- OpalCore.Math.floor(3.7);
// 3
```

#### `OpalCore.Math.ceil(x: Number) -> Integer`

数値を切り上げます。

**パラメータ**:
- `x`: 数値

**戻り値**: 切り上げられた整数

**使用例**:
```opal
nc ceiled <- OpalCore.Math.ceil(3.2);
// 4
```

### エラー処理

#### `OpalCore.Error`

基本的なエラークラスです。

**コンストラクタ**:
- `new Error(message: String, code: String = "")`

**メソッド**:
- `get_message() -> String`: エラーメッセージを取得します
- `get_code() -> String`: エラーコードを取得します
- `get_stack() -> String`: スタックトレースを取得します
- `to_string() -> String`: エラーの文字列表現を取得します

**使用例**:
```opal
nc error <- new OpalCore.Error("エラーが発生しました", "E001");
OpalSystemCall.(error.get_message()) -> out;
OpalSystemCall.(error.get_code()) -> out;
```

#### `OpalCore.TypeError`

型エラーを表すクラスです。

**コンストラクタ**:
- `new TypeError(message: String)`

**使用例**:
```opal
throw new OpalCore.TypeError("無効な型です");
```

#### `OpalCore.ValueError`

値エラーを表すクラスです。

**コンストラクタ**:
- `new ValueError(message: String)`

**使用例**:
```opal
throw new OpalCore.ValueError("無効な値です");
```

#### `OpalCore.RangeError`

範囲エラーを表すクラスです。

**コンストラクタ**:
- `new RangeError(message: String)`

**使用例**:
```opal
throw new OpalCore.RangeError("インデックスが範囲外です");
```

#### `OpalCore.Result`

成功または失敗を表現する結果型です。

**静的メソッド**:
- `success(value: Any) -> Result`: 成功結果を作成します
- `failure(error: Error) -> Result`: 失敗結果を作成します

**インスタンスメソッド**:
- `is_ok() -> Boolean`: 成功かどうかを確認します
- `is_err() -> Boolean`: 失敗かどうかを確認します
- `get_value() -> Any`: 値を取得します
- `get_error() -> Error`: エラーを取得します
- `map(mapper: Function) -> Result`: 値を変換します
- `and_then(mapper: Function) -> Result`: 値を変換し、新しい結果を返します
- `or_else(handler: Function) -> Result`: エラーを処理します
- `unwrap_or(default_value: Any) -> Any`: 値またはデフォルト値を取得します
- `to_string() -> String`: 文字列表現を取得します

**使用例**:
```opal
function divide(a: Number, b: Number) -> OpalCore.Result then
    if b == 0 then
        return OpalCore.Result.failure(new OpalCore.Error("ゼロ除算"));
    end
    
    return OpalCore.Result.success(a / b);
end

nc result <- divide(10, 2);

if result.is_ok() then
    OpalSystemCall.("結果: " + result.get_value()) -> out;
else then
    OpalSystemCall.("エラー: " + result.get_error().get_message()) -> out;
end

// メソッドチェーンの使用例
divide(10, 2)
    .map(function(value: Number) -> Number then
        return value * 2;
    end)
    .and_then(function(value: Number) -> OpalCore.Result then
        return OpalCore.Result.success(value + 1);
    end)
    .unwrap_or(0);
```

### オプション型

#### `OpalCore.Option`

値の存在または不在を表現するオプション型です。

**静的メソッド**:
- `some(value: Any) -> Option`: 値を持つオプションを作成します
- `none() -> Option`: 値を持たないオプションを作成します

**インスタンスメソッド**:
- `is_some() -> Boolean`: 値があるかどうかを確認します
- `is_none() -> Boolean`: 値がないかどうかを確認します
- `get_value() -> Any`: 値を取得します
- `map(mapper: Function) -> Option`: 値を変換します
- `and_then(mapper: Function) -> Option`: 値を変換し、新しいオプションを返します
- `or_else(default_value: Any) -> Any`: 値またはデフォルト値を取得します
- `to_string() -> String`: 文字列表現を取得します

**使用例**:
```opal
function find_user(id: String) -> OpalCore.Option then
    if id == "1" then
        return OpalCore.Option.some({ "id": "1", "name": "Opal" });
    end
    
    return OpalCore.Option.none();
end

nc user_option <- find_user("1");

if user_option.is_some() then
    nc user <- user_option.get_value();
    OpalSystemCall.("ユーザー名: " + user.name) -> out;
end

// メソッドチェーンの使用例
find_user("2")
    .map(function(user: Map) -> String then
        return user.name;
    end)
    .or_else("不明なユーザー");
```

### イミュータブルデータ構造

#### `OpalCore.ImmutableMap`

不変なマップデータ構造です。

**静的メソッド**:
- `from(data: Map) -> ImmutableMap`: 通常のマップからイミュータブルマップを作成します

**インスタンスメソッド**:
- `get(key: String) -> Any`: キーに対応する値を取得します
- `has(key: String) -> Boolean`: キーが存在するかどうかを確認します
- `keys() -> Array`: すべてのキーの配列を取得します
- `values() -> Array`: すべての値の配列を取得します
- `entries() -> Array`: すべてのキーと値のペアの配列を取得します
- `set(key: String, value: Any) -> ImmutableMap`: 新しいキーと値のペアを持つ新しいマップを返します
- `delete(key: String) -> ImmutableMap`: キーを削除した新しいマップを返します
- `merge(other: ImmutableMap) -> ImmutableMap`: 2つのマップをマージした新しいマップを返します
- `to_mutable() -> Map`: 通常のマップに変換します
- `to_string() -> String`: 文字列表現を取得します

**使用例**:
```opal
nc map <- OpalCore.ImmutableMap.from({
    "name": "Opal",
    "version": "1.1.0"
});

// 元のマップは変更されず、新しいマップが返される
nc new_map <- map.set("author", "OpalTeam");

OpalSystemCall.(map.get("name")) -> out; // "Opal"
OpalSystemCall.(new_map.get("author")) -> out; // "OpalTeam"

// マップのマージ
nc merged <- map.merge(OpalCore.ImmutableMap.from({
    "license": "MIT"
}));
```

#### `OpalCore.ImmutableArray`

不変な配列データ構造です。

**静的メソッド**:
- `from(data: Array) -> ImmutableArray`: 通常の配列からイミュータブル配列を作成します

**インスタンスメソッド**:
- `get(index: Integer) -> Any`: インデックスに対応する値を取得します
- `length() -> Integer`: 配列の長さを取得します
- `push(value: Any) -> ImmutableArray`: 値を追加した新しい配列を返します
- `pop() -> ImmutableArray`: 最後の要素を削除した新しい配列を返します
- `concat(other: ImmutableArray) -> ImmutableArray`: 2つの配列を連結した新しい配列を返します
- `map(mapper: Function) -> ImmutableArray`: 各要素を変換した新しい配列を返します
- `filter(predicate: Function) -> ImmutableArray`: 条件に一致する要素のみを含む新しい配列を返します
- `reduce(reducer: Function, initial_value: Any) -> Any`: 配列の要素を集約します
- `to_mutable() -> Array`: 通常の配列に変換します
- `to_string() -> String`: 文字列表現を取得します

**使用例**:
```opal
nc array <- OpalCore.ImmutableArray.from([1, 2, 3]);
nc new_array <- array.push(4).push(5);

OpalSystemCall.(array.length()) -> out; // 3
OpalSystemCall.(new_array.length()) -> out; // 5

// 関数型メソッドの使用例
nc doubled <- array.map(function(x: Integer) -> Integer then
    return x * 2;
end);

nc even_numbers <- array.filter(function(x: Integer) -> Boolean then
    return x % 2 == 0;
end);

nc sum <- array.reduce(function(acc: Integer, x: Integer) -> Integer then
    return acc + x;
end, 0);
```

### 非同期処理

#### `OpalCore.Promise`

非同期処理を扱うためのPromiseクラスです。

**コンストラクタ**:
- `new Promise()`

**静的メソッド**:
- `resolve(value: Any) -> Promise`: 指定された値で解決されるPromiseを作成します
- `reject(reason: Any) -> Promise`: 指定された理由で拒否されるPromiseを作成します
- `all(promises: Array) -> Promise`: すべてのPromiseが解決されたときに解決されるPromiseを作成します
- `race(promises: Array) -> Promise`: いずれかのPromiseが解決または拒否されたときに解決または拒否されるPromiseを作成します

**インスタンスメソッド**:
- `then(on_fulfilled: Function) -> Promise`: Promiseが解決されたときに呼び出される関数を登録します
- `catch(on_rejected: Function) -> Promise`: Promiseが拒否されたときに呼び出される関数を登録します
- `finally(on_finally: Function) -> Promise`: Promiseが解決または拒否されたときに呼び出される関数を登録します
- `_resolve(value: Any) -> Void`: Promiseを解決します（内部メソッド）
- `_reject(reason: Any) -> Void`: Promiseを拒否します（内部メソッド）

**使用例**:
```opal
// Promise APIの使用例
nc promise <- new OpalCore.Promise();

// 非同期処理をシミュレート
OpalCore.Concurrency.setTimeout(function() -> Void then
    promise._resolve("成功!");
end, 1000);

// 結果の処理
promise.then(function(result: String) -> Void then
    OpalSystemCall.(result) -> out; // "成功!"
end).catch(function(error: Any) -> Void then
    OpalSystemCall.("エラー: " + error) -> out;
end);

// Promise.all の使用例
nc promises <- [
    OpalCore.Promise.resolve(1),
    OpalCore.Promise.resolve(2),
    OpalCore.Promise.resolve(3)
];

OpalCore.Promise.all(promises).then(function(results: Array) -> Void then
    OpalSystemCall.(results) -> out; // [1, 2, 3]
end);
```

## 使用例

### 基本的な使用例

```opal
module MyApp then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // 型チェック
        nc value <- 42;
        
        if OpalCore.is_integer(value) then
            OpalSystemCall.("値は整数です: " + value) -> out;
        end
        
        // イミュータブルデータ構造
        nc map <- OpalCore.ImmutableMap.from({
            "name": "Opal",
            "version": "1.1.0"
        });
        
        nc new_map <- map.set("author", "OpalTeam");
        
        OpalSystemCall.("ライブラリ名: " + map.get("name")) -> out;
        OpalSystemCall.("作者: " + new_map.get("author")) -> out;
        
        // 結果型
        function divide(a: Number, b: Number) -> OpalCore.Result then
            if b == 0 then
                return OpalCore.Result.failure(new OpalCore.Error("ゼロ除算"));
            end
            
            return OpalCore.Result.success(a / b);
        end
        
        nc result <- divide(10, 2);
        
        if result.is_ok() then
            OpalSystemCall.("結果: " + result.get_value()) -> out;
        else then
            OpalSystemCall.("エラー: " + result.get_error().get_message()) -> out;
        end
    end
end
```

### 非同期処理の例

```opal
module AsyncExample then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        OpalSystemCall.("非同期処理を開始します...") -> out;
        
        // Promiseを使用した非同期処理
        nc promise <- new OpalCore.Promise();
        
        // 非同期タスクをシミュレート
        OpalCore.Concurrency.setTimeout(function() -> Void then
            promise._resolve("非同期処理が完了しました！");
        end, 2000);
        
        // 結果の処理
        promise.then(function(result: String) -> Void then
            OpalSystemCall.(result) -> out;
            
            // HTTPリクエストを送信
            return OpalCore.Network.httpRequest({
                "url": "https://jsonplaceholder.typicode.com/todos/1",
                "method": "GET"
            });
        end).then(function(response: Map) -> Void then
            OpalSystemCall.("APIレスポンス: " + response.data) -> out;
        end).catch(function(error: Any) -> Void then
            OpalSystemCall.("エラーが発生しました: " + error) -> out;
        end);
        
        OpalSystemCall.("非同期処理を開始しました。結果を待っています...") -> out;
    end
end
```

### 関数型プログラミングの例

```opal
module FunctionalExample then
    function first() -> Void then
        // OpalCoreを初期化
        OpalCore.initialize();
        
        // イミュータブル配列
        nc array <- OpalCore.ImmutableArray.from([1, 2, 3, 4, 5]);
        
        // 関数型メソッドの使用例
        nc doubled <- array.map(function(x: Integer) -> Integer then
            return x * 2;
        end);
        
        nc even_numbers <- array.filter(function(x: Integer) -> Boolean then
            return x % 2 == 0;
        end);
        
        nc sum <- array.reduce(function(acc: Integer, x: Integer) -> Integer then
            return acc + x;
        end, 0);
        
        OpalSystemCall.("元の配列: " + array.to_string()) -> out;
        OpalSystemCall.("2倍の配列: " + doubled.to_string()) -> out;
        OpalSystemCall.("偶数のみ: " + even_numbers.to_string()) -> out;
        OpalSystemCall.("合計: " + sum) -> out;
        
        // オプション型
        function find_user(id: String) -> OpalCore.Option then
            if id == "1" then
                return OpalCore.Option.some({ "id": "1", "name": "Opal" });
            end
            
            return OpalCore.Option.none();
        end
        
        // メソッドチェーン
        nc user_name <- find_user("1")
            .map(function(user: Map) -> String then
                return user.name;
            end)
            .or_else("不明なユーザー");
        
        OpalSystemCall.("ユーザー名: " + user_name) -> out;
        
        nc unknown_user <- find_user("999")
            .map(function(user: Map) -> String then
                return user.name;
            end)
            .or_else("不明なユーザー");
        
        OpalSystemCall.("不明なユーザー: " + unknown_user) -> out;
    end
end
```

## ライセンス

OpalCoreライブラリはMITライセンスの下で提供されています。

## 変更履歴

### v1.1.0
- 型チェック関数の完全実装
- イミュータブルデータ構造（ImmutableMap、ImmutableArray）の追加
- Promise APIの追加
- オプション型の追加
- 拡張されたエラー処理
- 数学ユーティリティの追加

### v1.0.0
- 初期リリース
