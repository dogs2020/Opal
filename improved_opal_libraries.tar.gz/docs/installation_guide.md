# Opal言語インストールガイド

このガイドでは、Opal言語の開発環境のセットアップと使用方法について説明します。

## システム要件

- Linux、macOS、またはWindows 10/11
- 最小4GBのRAM（8GB以上推奨）
- 2GBの空きディスク容量
- C++コンパイラ（GCC 9+、Clang 10+、またはMSVC 19.2+）

## インストール方法

### 方法1: バイナリパッケージを使用する（推奨）

#### Linux

```bash
# パッケージをダウンロード
wget https://opal-lang.org/downloads/opal-latest-linux-x86_64.tar.gz

# 展開
tar -xzf opal-latest-linux-x86_64.tar.gz

# インストール
cd opal-latest
sudo ./install.sh

# パスを設定
echo 'export PATH=$PATH:/usr/local/opal/bin' >> ~/.bashrc
source ~/.bashrc
```

#### macOS

```bash
# Homebrewを使用してインストール
brew tap opal-lang/opal
brew install opal

# または手動でインストール
curl -O https://opal-lang.org/downloads/opal-latest-macos.pkg
sudo installer -pkg opal-latest-macos.pkg -target /
```

#### Windows

1. [Opal言語のダウンロードページ](https://opal-lang.org/downloads)からWindows用インストーラーをダウンロード
2. ダウンロードしたインストーラー（opal-latest-windows.exe）を実行
3. インストールウィザードの指示に従ってインストール
4. インストール時に「PATHに追加」オプションを選択

### 方法2: ソースからビルドする

```bash
# リポジトリをクローン
git clone https://github.com/opal-lang/opal.git
cd opal

# ビルドディレクトリを作成
mkdir build
cd build

# CMakeを使用してビルド
cmake ..
make -j$(nproc)

# インストール
sudo make install
```

## インストールの確認

インストールが成功したことを確認するには、以下のコマンドを実行します：

```bash
opal --version
```

以下のような出力が表示されるはずです：

```
Opal Compiler version 1.0.0
Copyright (C) 2025 Opal Language Team
```

## 最初のOpalプログラム

1. テキストエディタで `hello.opal` という名前のファイルを作成し、以下のコードを入力します：

```opal
function first() -> Integer then
    Console.println("Hello, Opal World!");
    return 0;
end
```

2. プログラムをコンパイルして実行します：

```bash
opal run hello.opal
```

3. 以下の出力が表示されるはずです：

```
Hello, Opal World!
```

## 開発環境のセットアップ

### VSCode拡張機能

1. VSCodeを開き、拡張機能タブを選択
2. 「Opal Language」を検索してインストール
3. `.opal`ファイルを開くと、シンタックスハイライト、コード補完、リアルタイムエラーチェックが有効になります

### Vim/Neovimプラグイン

```bash
# Vimプラグインマネージャー（例：vim-plug）を使用してインストール
# .vimrcまたはinit.vimに以下を追加
Plug 'opal-lang/vim-opal'

# プラグインをインストール
:PlugInstall
```

### Emacsモード

```elisp
;; MELPAからインストール
(require 'package)
(add-to-list 'package-archives '("melpa" . "https://melpa.org/packages/") t)
(package-initialize)
(package-refresh-contents)
(package-install 'opal-mode)

;; 設定
(require 'opal-mode)
(add-to-list 'auto-mode-alist '("\\.opal\\'" . opal-mode))
```

## プロジェクト構造

Opalプロジェクトの標準的な構造は以下の通りです：

```
my_project/
├── src/
│   ├── main.opal      # エントリーポイント
│   └── lib/           # プロジェクト固有のライブラリ
├── tests/             # テストファイル
├── build/             # ビルド成果物
└── opal.toml          # プロジェクト設定ファイル
```

プロジェクトを初期化するには：

```bash
opal init my_project
cd my_project
```

## ビルドと実行

### 単一ファイルの実行

```bash
# インタプリタモード（開発中に便利）
opal run src/main.opal

# コンパイルして実行
opal compile src/main.opal -o build/main
./build/main
```

### プロジェクトのビルド

```bash
# プロジェクトディレクトリ内で
opal build

# 最適化レベルを指定
opal build --optimize=3

# 特定のターゲットプラットフォーム向けにビルド
opal build --target=wasm
```

## デバッグ

```bash
# デバッグ情報付きでコンパイル
opal compile src/main.opal -g -o build/main_debug

# デバッガを使用
opal debug build/main_debug
```

## パッケージ管理

```bash
# パッケージをインストール
opal package add numeric-lib

# プロジェクトの依存関係をインストール
opal package install

# 利用可能なパッケージを検索
opal package search matrix
```

## トラブルシューティング

### 一般的な問題

1. **「opalコマンドが見つかりません」エラー**
   - PATHが正しく設定されているか確認してください
   - インストールスクリプトを再実行してみてください

2. **コンパイルエラー**
   - エラーメッセージを確認し、構文の問題を修正してください
   - 最新バージョンのOpalを使用しているか確認してください

3. **ライブラリが見つからない**
   - `OPAL_LIB_PATH`環境変数が正しく設定されているか確認してください
   - 必要なパッケージがインストールされているか確認してください

### サポートを受ける

- [公式フォーラム](https://forum.opal-lang.org)
- [GitHubイシュートラッカー](https://github.com/opal-lang/opal/issues)
- [Discordコミュニティ](https://discord.gg/opal-lang)

## 次のステップ

- [公式ドキュメント](https://docs.opal-lang.org)で言語機能の詳細を学ぶ
- [チュートリアル](https://tutorials.opal-lang.org)で実践的な例を試す
- [サンプルプロジェクト](https://github.com/opal-lang/examples)を探索する

Opal言語の世界へようこそ！
